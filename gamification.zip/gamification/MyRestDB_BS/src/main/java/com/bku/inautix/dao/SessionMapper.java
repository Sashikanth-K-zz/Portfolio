package com.bku.inautix.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.common.bean.SessionBean;

public class SessionMapper implements RowMapper<SessionBean> {
	public SessionBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		SessionBean sessionBean=new SessionBean();		
		sessionBean.setId(rs.getString("usrname"));
		sessionBean.setType(rs.getString("type"));
		sessionBean.setName(rs.getString("name"));
		return sessionBean;
	}

}