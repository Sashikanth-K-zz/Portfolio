package com.bku.inautix.broker.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="advice")
public class AdviceBean {
	private String advice;
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdvice() {
		return advice;
	}

	public void setAdvice(String advice) {
		this.advice = advice;
	}
}
