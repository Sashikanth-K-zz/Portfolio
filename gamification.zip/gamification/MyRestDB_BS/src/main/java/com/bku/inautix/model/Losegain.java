package com.bku.inautix.model;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="losegain")
 

public class Losegain {
	public Losegain()
	{
		
	}
	private String stk_name;
	private Float difference;
	public String getStk_name() {
		return stk_name;
	}
	public void setStk_name(String stk_name) {
		this.stk_name = stk_name;
	}
	public Float getDifference() {
		return difference;
	}
	public void setDifference(Float difference) {
		this.difference = difference;
	}
}
