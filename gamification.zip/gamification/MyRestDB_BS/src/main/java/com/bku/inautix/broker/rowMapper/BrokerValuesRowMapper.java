package com.bku.inautix.broker.rowMapper;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.bku.inautix.broker.bean.BrokerValuesBean;
public class BrokerValuesRowMapper implements RowMapper<BrokerValuesBean> {
                public BrokerValuesBean mapRow(ResultSet rs, int rowNum) throws SQLException {
                                BrokerValuesBean obj = new BrokerValuesBean();                          
	         
                                obj.setBrokerId(rs.getString("broker_id"));
                                obj.setFutures(rs.getFloat("futures_rate"));
                                obj.setMf(rs.getFloat("mf_rate"));
                                obj.setEquities(rs.getFloat("equities_rate"));
                                obj.setFx(rs.getFloat("fx_rate"));
                                obj.setBond(rs.getFloat("bonds_rate"));
                                obj.setMarginRatio(rs.getString("margin_fund_ratio"));
                                obj.setMarginRate(rs.getString("margin_fund_rate"));
                                obj.setTimestamp(rs.getString("time_stamp"));
                                obj.setStatus(rs.getString("status"));


			return obj;
		}

	}

