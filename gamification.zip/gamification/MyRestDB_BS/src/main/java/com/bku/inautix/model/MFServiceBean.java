package com.bku.inautix.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="MF")
public class MFServiceBean {
	
	private String MF_name;
	private String Ticker_symbol;
	private String CUSIP;
	private Float price;
	private String date;
	
	public String getMF_name() {
		return MF_name;
	}
	public void setMF_name(String mF_name) {
		MF_name = mF_name;
	}
	public String getTicker_symbol() {
		return Ticker_symbol;
	}
	public void setTicker_symbol(String ticker_symbol) {
		Ticker_symbol = ticker_symbol;
	}
	public String getCUSIP() {
		return CUSIP;
	}
	public void setCUSIP(String cUSIP) {
		CUSIP = cUSIP;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	

}
