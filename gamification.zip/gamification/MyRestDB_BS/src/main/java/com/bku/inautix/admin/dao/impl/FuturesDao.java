package com.bku.inautix.admin.dao.impl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.FuturesBean;
import com.bku.inautix.admin.dao.IFuturesDao;
import com.bku.inautix.admin.utility.InsertUtility;
import com.bku.inautix.model.ExcelFilePathBean;

public class FuturesDao implements IFuturesDao{

	public void  insertFutures(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean)
	{
		log.info("\nEntered insertfutures service");
			ArrayList<FuturesBean> futuresBeanList = new ArrayList<FuturesBean>();
			InsertUtility.insertFutures(futuresBeanList,excelFilePathBean.getExcelFilePath(),log);

			

			
				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
						Types.VARCHAR, Types.FLOAT, Types.DATE };
				jdbcTemplate.update("delete from futures");
				for (FuturesBean futuresBean : futuresBeanList) {

					 jdbcTemplate.update(
							"insert into futures values(?,?,?,?,?)", new Object[] {
									futuresBean.getName(), futuresBean.getSymbol(),
									futuresBean.getCusip(), futuresBean.getPrice(),
									new Date() }, types);
					log.info("\nInserted futures values");
				}

			

			
			log.info("\nReturning after inserting futures");
		
			
			
		}
		

}
