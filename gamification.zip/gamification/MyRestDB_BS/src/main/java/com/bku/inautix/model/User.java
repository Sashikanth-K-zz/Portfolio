package com.bku.inautix.model;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="userhomescreen")

public class User {
	
	public User(){}
	
	public User(String id, int rank, float portfoliovalue, double glpercentage,
			float equity, float bond, float mutualfund, float balance) {
		super();
		this.id = id;
		this.rank = rank;
		this.portfoliovalue = portfoliovalue;
		this.glpercentage = glpercentage;
		this.equity = equity;
		this.bond = bond;
		this.mutualfund = mutualfund;
		this.balance = balance;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public float getPortfoliovalue() {
		return portfoliovalue;
	}
	public void setPortfoliovalue(float portfoliovalue) {
		this.portfoliovalue = portfoliovalue;
	}
	public double getGlpercentage() {
		return glpercentage;
	}
	public void setGlpercentage(double glpercentage) {
		this.glpercentage = glpercentage;
	}
	public float getEquity() {
		return equity;
	}
	public void setEquity(float equity) {
		this.equity = equity;
	}
	public float getBond() {
		return bond;
	}
	public void setBond(float bond) {
		this.bond = bond;
	}
	public float getMutualfund() {
		return mutualfund;
	}
	public void setMutualfund(float mutualfund) {
		this.mutualfund = mutualfund;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	private String id;
	private int rank;
	private float portfoliovalue;
	private double glpercentage;
	private float equity;
	private float bond;
	private float mutualfund;
	private float balance;

}