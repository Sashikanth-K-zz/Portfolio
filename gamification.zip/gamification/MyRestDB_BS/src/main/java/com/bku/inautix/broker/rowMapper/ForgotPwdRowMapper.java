/**
 * DONE BY XBBLWC8 EMP ID : 13490
 */
package com.bku.inautix.broker.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.broker.bean.ForgotPwdBean;




public class ForgotPwdRowMapper implements RowMapper<ForgotPwdBean>
{
	public ForgotPwdBean mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		ForgotPwdBean obj = new ForgotPwdBean();
		obj.setEmail_id(rs.getString("email_id"));
		obj.setPassword(rs.getString("passwd"));
		return obj;
	}
}
