package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="mosttraded")
public class Mosttraded 
{

	public Mosttraded()
	{}
	public Mosttraded(String name,float price,int count)
	
	{
		this.count=count;
		this.name=name;
		this.price=price;
	}
	private String name;
	public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	private int count;
	private float price;
	public float getPrice() 
	{
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
}
