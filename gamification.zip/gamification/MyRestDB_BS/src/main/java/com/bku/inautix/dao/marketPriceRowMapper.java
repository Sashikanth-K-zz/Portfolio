package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.marketPrice;


public class marketPriceRowMapper implements RowMapper<marketPrice> {
	public marketPrice mapRow(ResultSet rs, int rowNum) throws SQLException {
		marketPrice obj = new marketPrice();		
		obj.setSymbol(rs.getString("equ_symbl"));
		obj.setName(rs.getString("equ_name"));
		obj.setPrice(rs.getFloat("price"));
		obj.setBeta(rs.getInt("beta"));
		return obj;
	}
}
