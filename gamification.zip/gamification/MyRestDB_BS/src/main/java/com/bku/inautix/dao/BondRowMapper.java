package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.BondServiceBean;

public class BondRowMapper implements RowMapper<BondServiceBean> {
	
public BondServiceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BondServiceBean obj = new BondServiceBean();		
	
		obj.setBond_name(rs.getString(1));
		obj.setBond_symbol(rs.getString(2));
		obj.setCUSIP(rs.getString(3));
		obj.setPrice(rs.getFloat(4));
		obj.setDate(rs.getString(5));
		obj.setMarketInterest(rs.getFloat(6));
		
		
		return obj; 
	}

}