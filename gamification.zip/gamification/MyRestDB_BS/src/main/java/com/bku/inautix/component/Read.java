package com.bku.inautix.component;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bku.inautix.model.Bond;
import com.bku.inautix.model.FX;
import com.bku.inautix.model.JavaNews;
import com.bku.inautix.model.MF;
import com.bku.inautix.model.Stock;



public class Read {
	
	//model objects declaration
			Stock stockobj = new Stock();
			Bond bondobj = new Bond();
			MF MFobj = new MF();
			FX FXobj = new FX();
			JavaNews Newsobj = new JavaNews();
		
		    CalculateRow cr = new CalculateRow();
			int[] s;
			int doneReadFlag=0;
			Date date= new Date();
			String sdate=date.toString();
			
			int rowNum;
			
			//Stock variables
			List<String> stk_name = new ArrayList<String>();
			List<String> stk_symbl = new ArrayList<String>();
			List<String> stk_cusip = new ArrayList<String>();
			List<Float> stk_price = new ArrayList<Float>();
			List<Integer> stk_beta = new ArrayList<Integer>();
			
			//bond variables
			List<String> bond_name = new ArrayList<String>();
			List<String> bond_symbl = new ArrayList<String>();
			List<String> bond_cusip = new ArrayList<String>();
			List<Float> bond_price = new ArrayList<Float>();
			
			//MF variables
			List<String> MF_name = new ArrayList<String>();
			List<String> MF_symbl = new ArrayList<String>();
			List<String> MF_cusip = new ArrayList<String>();
			List<Float> MF_price = new ArrayList<Float>();
			
			//FX variables
			List<String> FX_name = new ArrayList<String>();
			List<String> FX_symbl = new ArrayList<String>();
			List<Float> FX_price = new ArrayList<Float>();
			
			//News variables
			List<String> News = new ArrayList<String>();
			List<String> News_date = new ArrayList<String>();
			
	
	
	public Stock ReadStock(){
		
		
		
    try {
    	
    		System.out.println("Called the read method");
    	
			FileInputStream fileInputStream = new FileInputStream("H:\\Excel\\Pricing.xlsx");
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(0);
			
			Iterator<Row> rowIterator = worksheet.iterator();
			Iterator<Row> rowIterator1 = worksheet.iterator();
			
			s= cr.getSize(rowIterator1);    //### Calls a function that 
			
			System.out.println("The row spaces are in");
			System.out.println("stock starts at :"+s[0]);
			System.out.println("stock ends at :"+s[1]);
			System.out.println("Bond starts at :"+s[2]);
			System.out.println("bond ends at :"+s[3]);
			System.out.println("MF starts at :"+s[4]);
			System.out.println("MF ends at :"+s[5]);
			System.out.println("FX starts at :"+s[6]);
			System.out.println("FX ends at :"+s[7]);
			
		
			
            while (rowIterator.hasNext())
            {
            
                Row row = rowIterator.next();
                //For each row, iterate through all the columns
                Iterator<Cell> cellIterator = row.cellIterator();
                
                //TempCell iterator for identifying the separation between the excel sheet
               
               if(row.getRowNum() == s[0])
               {
            	   sdate=row.getCell(6).toString();
            	   System.out.println("Date is : "+sdate);
               }
               
                rowNum=row.getRowNum();
                while (cellIterator.hasNext())
                {   
                	
                	if(doneReadFlag==1)
                		break;
                	
                    Cell cell = cellIterator.next();
                    
                    //code to check into different beans
                  
                    
                    //from s[0]+1 to s[1] insert into stock bean
                    
                    //from s[2]+1 to s[3] insert into bond bean
                    
                    //from s[4]+1 to s[5] insert into MF bean
                    
                    //from s[6]+1 to s[7] insert into FX bean
                    
        			
                  //from s[8]+1 to s[9] insert into news	
                     
         
                    if(cell.getRowIndex()>s[9])
                    {  
                    	doneReadFlag=1;
                    	System.out.println("done reading the excel file for values...");
                    	System.out.println(" terminating the reader");
                    	break;
                    }
                         
                    //Check the cell type and format accordingly
                    switch (cell.getCellType())
                    {
                    
                    	  case Cell.CELL_TYPE_NUMERIC:
                        	
                    		  
                    		   // ### stock handler
                    		  	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
                        			{
                        			
                        			//if column is 2, it is cusip ##converting it into string
                        			if (cell.getColumnIndex() == 2)
                        				{
                        				BigDecimal bd = new BigDecimal(cell.getNumericCellValue());
                        				//System.out.println(bd);
                        				//System.out.println(bd.toString());
                        				stk_cusip.add(bd.toString());
                        				}
                        			
                        			// if it's not cusip, its price ...  so we're adding it 
                        			if (cell.getColumnIndex() == 3)
                    				{
                    				Float f = new Float (cell.getNumericCellValue());
                    				//System.out.println(bd);
                    				//System.out.println(bd.toString());
                    				stk_price.add(f);
                    				}
                        			
                        			// if it's not price, its beta ...  so we're adding it 
                        			if (cell.getColumnIndex() == 4)
                    				{
                    				Integer beta = new Integer ((int) cell.getNumericCellValue());
                    				//System.out.println(bd);
                    				//System.out.println(bd.toString());
                    				stk_beta.add(beta);
                    				}
                        			
                        			}
                        		
                        	//## bond handler
                    			if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
                    			{
                    			
                    			if (cell.getColumnIndex() == 3)
                				{
                				Float f = new Float (cell.getNumericCellValue());
                				
                				bond_price.add(f);
                				}
                    			
                    			}
                    		
                    		  	
                    		//## MF handler
                    			if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
                    			{
                    			
                    			if (cell.getColumnIndex() == 3)
                				{
                				Float f = new Float (cell.getNumericCellValue());
                				
                				MF_price.add(f);
                				}
                    			
                    			}
                    		  	
                    		//## FX handler
                    			if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
                    			{
                    			//System.out.println("getting into FX handler's price");
                    			if (cell.getColumnIndex() == 3)
                				{
                				Float f = new Float (cell.getNumericCellValue());
                				System.out.println(" FX price :"+rowNum+" :"+f);
                				FX_price.add(f);
                				}
                    			
                    			}
                        	
                        
                            break;
                            
                            
                        case Cell.CELL_TYPE_STRING:

                        	//## stock handler
                        	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
                			{
                			
                			//if column is 0, it is Stock name
                			if (cell.getColumnIndex() == 0)
                				{
                				stk_name.add(cell.getStringCellValue());
                				}
                			
                			//if column is 1, it is Stock symbol
                			if (cell.getColumnIndex() == 1)
                				{
                				stk_symbl.add(cell.getStringCellValue());
                				}
                			
                			}
                        		
                        	//## bond handler
                        	if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
                			{
                			
                			//if column is 0, it is Bond name
                			if (cell.getColumnIndex() == 0)
                				{
                				bond_name.add(cell.getStringCellValue());
                				}
                			
                			//if column is 1, it is Bond symbol
                			if (cell.getColumnIndex() == 1)
                				{
                				bond_symbl.add(cell.getStringCellValue());
                				}
                			
                			//if column is 2, it is Bond CUSIP
                			if (cell.getColumnIndex() == 2)
                				{
                				bond_cusip.add(cell.getStringCellValue());
                				}
                			
                			}
                		  	
                    		//## MF handler
                        	if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
                			{
                			
                			//if column is 0, it is MF name
                			if (cell.getColumnIndex() == 0)
                				{
                				MF_name.add(cell.getStringCellValue());
                				}
                			
                			//if column is 1, it is MF symbol
                			if (cell.getColumnIndex() == 1)
                				{
                				MF_symbl.add(cell.getStringCellValue());
                				}
                			
                			//if column is 2, it is MF CUSIP
                			if (cell.getColumnIndex() == 2)
                				{
                				MF_cusip.add(cell.getStringCellValue());
                				}
                			
                			}
                    		  	
                    		//## FX handler
                        	if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
                			{
                			
                			//if column is 0, it is FX name
                			if (cell.getColumnIndex() == 0)
                				{
                				System.out.println("The name here is"+cell.getStringCellValue());
                				FX_name.add(cell.getStringCellValue());
                				}
                			
                			//if column is 1, it is Ticker symbol
                			if (cell.getColumnIndex() == 1)
                				{
                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
                				FX_symbl.add(cell.getStringCellValue());
                				}
                			
                			}
                        	
                        	// ## News Handler ( cell column index 1,2)
                        	if((rowNum <= s[9]) && (rowNum > s[8])) //range is within News
                			{
                			
                			//if column is 1, it is News
                			if (cell.getColumnIndex() == 1)
                				{
                				//System.out.println("The name here is"+cell.getStringCellValue());
                				News.add(cell.getStringCellValue());
                				}
                			
                			//if column is 2, it is News Date
                			if (cell.getColumnIndex() == 2)
                				{
                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
                				News_date.add(cell.getStringCellValue());
                				}
                			
                			}
                        	
                        	
                        	
                        	break;
                        	
                        case Cell.CELL_TYPE_BLANK:
                        	//System.out.println(cell.getRowIndex()+":"+cell.getColumnIndex()+"\t <bc>\t");
                        	break;
                        	
                        
                        	
                        
                    }
                    
                  
                    
                }
           
              
             
            }
			
            //printing stock names
            for (int i=0 ; i<stk_name.size() ; i++)
            	System.out.println(stk_name.get(i)+" : "+stk_symbl.get(i)+" : "+stk_cusip.get(i)+" : "+stk_price.get(i)+" : "+ stk_beta.get(i));
           
            //printing bond names
            for (int i=0 ; i<bond_name.size() ; i++)
            	System.out.println(bond_name.get(i)+" : "+bond_symbl.get(i)+" : "+bond_cusip.get(i)+" : "+bond_price.get(i));
           
          //printing MF names
            for (int i=0 ; i<MF_name.size() ; i++)
            	System.out.println(MF_name.get(i)+" : "+MF_symbl.get(i)+" : "+MF_cusip.get(i)+" : "+MF_price.get(i));
           
	        //printing FX names
            System.out.println("printing FX names\n size is");
            System.out.println(FX_name.size());
	        for (int i=0 ; i<FX_name.size() ; i++)
	        	System.out.println(FX_name.get(i)+" : "+FX_symbl.get(i)+" : "+FX_price.get(i));
	      //printing news
	        for (int i=0 ; i<News.size() ; i++)
	        System.out.println(News.get(i)+" : "+News_date.get(i));

            
          //adding stock objects
	        stockobj.setStock_name(stk_name);
	        stockobj.setStock_symbol(stk_symbl);
	        stockobj.setCUSIP(stk_cusip);
	        stockobj.setPrice(stk_price);
	        stockobj.setBeta(stk_beta);
	        stockobj.setDate(sdate);
	        
	      //adding bond objects
	        bondobj.setBond_name(bond_name);
	        bondobj.setBond_symbol(bond_symbl);
	        bondobj.setCUSIP(bond_cusip);
	        bondobj.setPrice(bond_price);
	        bondobj.setDate(sdate);
	        
	        //adding MF objects
	        MFobj.setMF_name(MF_name);
	        MFobj.setPrice(MF_price);
	        MFobj.setCUSIP(MF_cusip);
	        MFobj.setTicker_symbol(MF_symbl);
	        MFobj.setDate(sdate);
	       
	        
	        //adding FX objects
	        FXobj.setFX_name(FX_name);
	        FXobj.setTicker_symbol(FX_symbl);
	        FXobj.setPrice(FX_price);
	        FXobj.setDate(sdate);
	        

	      //adding news objects
	      	        Newsobj.setNews(News);
	      	        Newsobj.setNews_date(News_date);
	      			
	        
	        
	        System.out.println("date is again : "+sdate);
            
          
            
		} 
		
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    
    	return stockobj;
		
	}
	
	public Bond ReadBond(){
		
	    try {
	    	
	    		System.out.println("Called the read method");
	    	
				FileInputStream fileInputStream = new FileInputStream("H:\\Excel\\Pricing.xlsx");
				XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
				XSSFSheet worksheet = workbook.getSheetAt(0);
				
				Iterator<Row> rowIterator = worksheet.iterator();
				Iterator<Row> rowIterator1 = worksheet.iterator();
				
				s= cr.getSize(rowIterator1);    //### Calls a function that 
				
				System.out.println("The row spaces are in");
				System.out.println("stock starts at :"+s[0]);
				System.out.println("stock ends at :"+s[1]);
				System.out.println("Bond starts at :"+s[2]);
				System.out.println("bond ends at :"+s[3]);
				System.out.println("MF starts at :"+s[4]);
				System.out.println("MF ends at :"+s[5]);
				System.out.println("FX starts at :"+s[6]);
				System.out.println("FX ends at :"+s[7]);
				
			
				
	            while (rowIterator.hasNext())
	            {
	            
	                Row row = rowIterator.next();
	                //For each row, iterate through all the columns
	                Iterator<Cell> cellIterator = row.cellIterator();
	                
	                //TempCell iterator for identifying the separation between the excel sheet
	               
	               if(row.getRowNum() == s[0])
	               {
	            	   sdate=row.getCell(5).toString();
	            	   System.out.println("Date is : "+sdate);
	               }
	               
	                rowNum=row.getRowNum();
	                while (cellIterator.hasNext())
	                {   
	                	
	                	if(doneReadFlag==1)
	                		break;
	                	
	                    Cell cell = cellIterator.next();
	                    
	                    //code to check into different beans
	                  
	                    
	                    //from s[0]+1 to s[1] insert into stock bean
	                    
	                    //from s[2]+1 to s[3] insert into bond bean
	                    
	                    //from s[4]+1 to s[5] insert into MF bean
	                    
	                    //from s[6]+1 to s[7] insert into FX bean
	                    
	        			
	                  //from s[8]+1 to s[9] insert into news	
	                     
	         
	                    if(cell.getRowIndex()>s[9])
	                    {  
	                    	doneReadFlag=1;
	                    	System.out.println("done reading the excel file for values...");
	                    	System.out.println(" terminating the reader");
	                    	break;
	                    }
	                         
	                    //Check the cell type and format accordingly
	                    switch (cell.getCellType())
	                    {
	                    
	                    	  case Cell.CELL_TYPE_NUMERIC:
	                        	
	                    		  
	                    		   // ### stock handler
	                    		  	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
	                        			{
	                        			
	                        			//if column is 2, it is cusip ##converting it into string
	                        			if (cell.getColumnIndex() == 2)
	                        				{
	                        				BigDecimal bd = new BigDecimal(cell.getNumericCellValue());
	                        				//System.out.println(bd);
	                        				//System.out.println(bd.toString());
	                        				stk_cusip.add(bd.toString());
	                        				}
	                        			
	                        			// if it's not cusip, its price ...  so we're adding it 
	                        			if (cell.getColumnIndex() == 3)
	                    				{
	                    				Float f = new Float (cell.getNumericCellValue());
	                    				//System.out.println(bd);
	                    				//System.out.println(bd.toString());
	                    				stk_price.add(f);
	                    				}
	                        			
	                        			}
	                        		
	                        	//## bond handler
	                    			if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
	                    			{
	                    			
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				
	                				bond_price.add(f);
	                				}
	                    			
	                    			}
	                    		
	                    		  	
	                    		//## MF handler
	                    			if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
	                    			{
	                    			
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				
	                				MF_price.add(f);
	                				}
	                    			
	                    			}
	                    		  	
	                    		//## FX handler
	                    			if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
	                    			{
	                    			//System.out.println("getting into FX handler's price");
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				System.out.println(" FX price :"+rowNum+" :"+f);
	                				FX_price.add(f);
	                				}
	                    			
	                    			}
	                        	
	                        
	                            break;
	                            
	                            
	                        case Cell.CELL_TYPE_STRING:

	                        	//## stock handler
	                        	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
	                			{
	                			
	                			//if column is 0, it is Stock name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				stk_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Stock symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				stk_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        		
	                        	//## bond handler
	                        	if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
	                			{
	                			
	                			//if column is 0, it is Bond name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				bond_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Bond symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				bond_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is Bond CUSIP
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				bond_cusip.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                		  	
	                    		//## MF handler
	                        	if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
	                			{
	                			
	                			//if column is 0, it is MF name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				MF_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is MF symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				MF_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is MF CUSIP
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				MF_cusip.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                    		  	
	                    		//## FX handler
	                        	if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
	                			{
	                			
	                			//if column is 0, it is FX name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				System.out.println("The name here is"+cell.getStringCellValue());
	                				FX_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Ticker symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
	                				FX_symbl.add(cell.getStringCellValue());
	}
	
	                			}
	                        	
	                        	// ## News Handler ( cell column index 1,2)
	                        	if((rowNum <= s[9]) && (rowNum > s[8])) //range is within News
	                			{
	                			
	                			//if column is 1, it is News
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				//System.out.println("The name here is"+cell.getStringCellValue());
	                				News.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is News Date
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
	                				News_date.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        	
	                        	
	                        	
	                        	break;
	                        	
	                        case Cell.CELL_TYPE_BLANK:
	                        	//System.out.println(cell.getRowIndex()+":"+cell.getColumnIndex()+"\t <bc>\t");
	                        	break;
	                        	
	                        
	                        	
	                        
	                    }
	                    
	                  
	                    
	                }
	           
	              
	             
	            }
				
	            //printing stock names
	            for (int i=0 ; i<stk_name.size() ; i++)
	            	System.out.println(stk_name.get(i)+" : "+stk_symbl.get(i)+" : "+stk_cusip.get(i)+" : "+stk_price.get(i));
	           
	            //printing bond names
	            for (int i=0 ; i<bond_name.size() ; i++)
	            	System.out.println(bond_name.get(i)+" : "+bond_symbl.get(i)+" : "+bond_cusip.get(i)+" : "+bond_price.get(i));
	           
	          //printing MF names
	            for (int i=0 ; i<MF_name.size() ; i++)
	            	System.out.println(MF_name.get(i)+" : "+MF_symbl.get(i)+" : "+MF_cusip.get(i)+" : "+MF_price.get(i));
	           
		        //printing FX names
	            System.out.println("printing FX names\n size is");
	            System.out.println(FX_name.size());
		        for (int i=0 ; i<FX_name.size() ; i++)
		        	System.out.println(FX_name.get(i)+" : "+FX_symbl.get(i)+" : "+FX_price.get(i));
		      //printing news
		        for (int i=0 ; i<News.size() ; i++)
		        System.out.println(News.get(i)+" : "+News_date.get(i));

	            
	       
		      //adding bond objects
		        bondobj.setBond_name(bond_name);
		        bondobj.setBond_symbol(bond_symbl);
		        bondobj.setCUSIP(bond_cusip);
		        bondobj.setPrice(bond_price);
		        bondobj.setDate(sdate);
		        
		      

		    
		      			
		        
		        
		        System.out.println("date is again : "+sdate);
	            
	          
	            
			} 
			
			catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		return bondobj;
	}
	
	public MF ReadMF(){
		  try {
		    	
	    		System.out.println("Called the read method");
	    	
				FileInputStream fileInputStream = new FileInputStream("H:\\Excel\\Pricing.xlsx");
				XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
				XSSFSheet worksheet = workbook.getSheetAt(0);
				
				Iterator<Row> rowIterator = worksheet.iterator();
				Iterator<Row> rowIterator1 = worksheet.iterator();
				
				s= cr.getSize(rowIterator1);    //### Calls a function that 
				
				System.out.println("The row spaces are in");
				System.out.println("stock starts at :"+s[0]);
				System.out.println("stock ends at :"+s[1]);
				System.out.println("Bond starts at :"+s[2]);
				System.out.println("bond ends at :"+s[3]);
				System.out.println("MF starts at :"+s[4]);
				System.out.println("MF ends at :"+s[5]);
				System.out.println("FX starts at :"+s[6]);
				System.out.println("FX ends at :"+s[7]);
				
			
				
	            while (rowIterator.hasNext())
	            {
	            
	                Row row = rowIterator.next();
	                //For each row, iterate through all the columns
	                Iterator<Cell> cellIterator = row.cellIterator();
	                
	                //TempCell iterator for identifying the separation between the excel sheet
	               
	               if(row.getRowNum() == s[0])
	               {
	            	   sdate=row.getCell(5).toString();
	            	   System.out.println("Date is : "+sdate);
	               }
	               
	                rowNum=row.getRowNum();
	                while (cellIterator.hasNext())
	                {   
	                	
	                	if(doneReadFlag==1)
	                		break;
	                	
	                    Cell cell = cellIterator.next();
	                    
	                    //code to check into different beans
	                  
	                    
	                    //from s[0]+1 to s[1] insert into stock bean
	                    
	                    //from s[2]+1 to s[3] insert into bond bean
	                    
	                    //from s[4]+1 to s[5] insert into MF bean
	                    
	                    //from s[6]+1 to s[7] insert into FX bean
	                    
	        			
	                  //from s[8]+1 to s[9] insert into news	
	                     
	         
	                    if(cell.getRowIndex()>s[9])
	                    {  
	                    	doneReadFlag=1;
	                    	System.out.println("done reading the excel file for values...");
	                    	System.out.println(" terminating the reader");
	                    	break;
	                    }
	                         
	                    //Check the cell type and format accordingly
	                    switch (cell.getCellType())
	                    {
	                    
	                    	  case Cell.CELL_TYPE_NUMERIC:
	                        	
	                    		  
	                    		   // ### stock handler
	                    		  	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
	                        			{
	                        			
	                        			//if column is 2, it is cusip ##converting it into string
	                        			if (cell.getColumnIndex() == 2)
	                        				{
	                        				BigDecimal bd = new BigDecimal(cell.getNumericCellValue());
	                        				//System.out.println(bd);
	                        				//System.out.println(bd.toString());
	                        				stk_cusip.add(bd.toString());
	                        				}
	                        			
	                        			// if it's not cusip, its price ...  so we're adding it 
	                        			if (cell.getColumnIndex() == 3)
	                    				{
	                    				Float f = new Float (cell.getNumericCellValue());
	                    				//System.out.println(bd);
	                    				//System.out.println(bd.toString());
	                    				stk_price.add(f);
	                    				}
	                        			
	                        			}
	                        		
	                        	//## bond handler
	                    			if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
	                    			{
	                    			
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				
	                				bond_price.add(f);
	                				}
	                    			
	                    			}
	                    		
	                    		  	
	                    		//## MF handler
	                    			if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
	                    			{
	                    			
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				
	                				MF_price.add(f);
	                				}
	                    			
	                    			}
	                    		  	
	                    		//## FX handler
	                    			if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
	                    			{
	                    			//System.out.println("getting into FX handler's price");
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				System.out.println(" FX price :"+rowNum+" :"+f);
	                				FX_price.add(f);
	                				}
	                    			
	                    			}
	                        	
	                        
	                            break;
	                            
	                            
	                        case Cell.CELL_TYPE_STRING:

	                        	//## stock handler
	                        	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
	                			{
	                			
	                			//if column is 0, it is Stock name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				stk_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Stock symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				stk_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        		
	                        	//## bond handler
	                        	if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
	                			{
	                			
	                			//if column is 0, it is Bond name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				bond_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Bond symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				bond_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is Bond CUSIP
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				bond_cusip.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                		  	
	                    		//## MF handler
	                        	if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
	                			{
	                			
	                			//if column is 0, it is MF name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				MF_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is MF symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				MF_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is MF CUSIP
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				MF_cusip.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                    		  	
	                    		//## FX handler
	                        	if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
	                			{
	                			
	                			//if column is 0, it is FX name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				System.out.println("The name here is"+cell.getStringCellValue());
	                				FX_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Ticker symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
	                				FX_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        	
	                        	// ## News Handler ( cell column index 1,2)
	                        	if((rowNum <= s[9]) && (rowNum > s[8])) //range is within News
	                			{
	                			
	                			//if column is 1, it is News
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				//System.out.println("The name here is"+cell.getStringCellValue());
	                				News.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is News Date
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
	                				News_date.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        	
	                        	
	                        	
	                        	break;
	                        	
	                        case Cell.CELL_TYPE_BLANK:
	                        	//System.out.println(cell.getRowIndex()+":"+cell.getColumnIndex()+"\t <bc>\t");
	                        	break;
	                        	
	                        
	                        	
	                        
	                    }
	                    
	                  
	                    
	                }
	           
	              
	             
	            }
				
	            //printing stock names
	            for (int i=0 ; i<stk_name.size() ; i++)
	            	System.out.println(stk_name.get(i)+" : "+stk_symbl.get(i)+" : "+stk_cusip.get(i)+" : "+stk_price.get(i));
	           
	            //printing bond names
	            for (int i=0 ; i<bond_name.size() ; i++)
	            	System.out.println(bond_name.get(i)+" : "+bond_symbl.get(i)+" : "+bond_cusip.get(i)+" : "+bond_price.get(i));
	           
	          //printing MF names
	            for (int i=0 ; i<MF_name.size() ; i++)
	            	System.out.println(MF_name.get(i)+" : "+MF_symbl.get(i)+" : "+MF_cusip.get(i)+" : "+MF_price.get(i));
	           
		        //printing FX names
	            System.out.println("printing FX names\n size is");
	            System.out.println(FX_name.size());
		        for (int i=0 ; i<FX_name.size() ; i++)
		        	System.out.println(FX_name.get(i)+" : "+FX_symbl.get(i)+" : "+FX_price.get(i));
		      //printing news
		        for (int i=0 ; i<News.size() ; i++)
		        System.out.println(News.get(i)+" : "+News_date.get(i));

	            
	         
		        //adding MF objects
		        MFobj.setMF_name(MF_name);
		        MFobj.setPrice(MF_price);
		        MFobj.setCUSIP(MF_cusip);
		        MFobj.setTicker_symbol(MF_symbl);
		        MFobj.setDate(sdate);
		       
		        
		     
		        
		        
		        System.out.println("date is again : "+sdate);
	            
	          
	            
			} 
			
			catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    
	 
		return MFobj;
	}
	
	public FX ReadFX(){
		  try {
		    	
	    		System.out.println("Called the read method");
	    	
				FileInputStream fileInputStream = new FileInputStream("H:\\Excel\\Pricing.xlsx");
				XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
				XSSFSheet worksheet = workbook.getSheetAt(0);
				
				Iterator<Row> rowIterator = worksheet.iterator();
				Iterator<Row> rowIterator1 = worksheet.iterator();
				
				s= cr.getSize(rowIterator1);    //### Calls a function that 
				
				System.out.println("The row spaces are in");
				System.out.println("stock starts at :"+s[0]);
				System.out.println("stock ends at :"+s[1]);
				System.out.println("Bond starts at :"+s[2]);
				System.out.println("bond ends at :"+s[3]);
				System.out.println("MF starts at :"+s[4]);
				System.out.println("MF ends at :"+s[5]);
				System.out.println("FX starts at :"+s[6]);
				System.out.println("FX ends at :"+s[7]);
				
			
				
	            while (rowIterator.hasNext())
	            {
	            
	                Row row = rowIterator.next();
	                //For each row, iterate through all the columns
	                Iterator<Cell> cellIterator = row.cellIterator();
	                
	                //TempCell iterator for identifying the separation between the excel sheet
	               
	               if(row.getRowNum() == s[0])
	               {
	            	   sdate=row.getCell(5).toString();
	            	   System.out.println("Date is : "+sdate);
	               }
	               
	                rowNum=row.getRowNum();
	                while (cellIterator.hasNext())
	                {   
	                	
	                	if(doneReadFlag==1)
	                		break;
	                	
	                    Cell cell = cellIterator.next();
	                    
	                    //code to check into different beans
	                  
	                    
	                    //from s[0]+1 to s[1] insert into stock bean
	                    
	                    //from s[2]+1 to s[3] insert into bond bean
	                    
	                    //from s[4]+1 to s[5] insert into MF bean
	                    
	                    //from s[6]+1 to s[7] insert into FX bean
	                    
	        			
	                  //from s[8]+1 to s[9] insert into news	
	                     
	         
	                    if(cell.getRowIndex()>s[9])
	                    {  
	                    	doneReadFlag=1;
	                    	System.out.println("done reading the excel file for values...");
	                    	System.out.println(" terminating the reader");
	                    	break;
	                    }
	                         
	                    //Check the cell type and format accordingly
	                    switch (cell.getCellType())
	                    {
	                    
	                    	  case Cell.CELL_TYPE_NUMERIC:
	                        	
	                    		  
	                    		   // ### stock handler
	                    		  	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
	                        			{
	                        			
	                        			//if column is 2, it is cusip ##converting it into string
	                        			if (cell.getColumnIndex() == 2)
	                        				{
	                        				BigDecimal bd = new BigDecimal(cell.getNumericCellValue());
	                        				//System.out.println(bd);
	                        				//System.out.println(bd.toString());
	                        				stk_cusip.add(bd.toString());
	                        				}
	                        			
	                        			// if it's not cusip, its price ...  so we're adding it 
	                        			if (cell.getColumnIndex() == 3)
	                    				{
	                    				Float f = new Float (cell.getNumericCellValue());
	                    				//System.out.println(bd);
	                    				//System.out.println(bd.toString());
	                    				stk_price.add(f);
	                    				}
	                        			
	                        			}
	                        		
	                        	//## bond handler
	                    			if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
	                    			{
	                    			
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				
	                				bond_price.add(f);
	                				}
	                    			
	                    			}
	                    		
	                    		  	
	                    		//## MF handler
	                    			if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
	                    			{
	                    			
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				
	                				MF_price.add(f);
	                				}
	                    			
	                    			}
	                    		  	
	                    		//## FX handler
	                    			if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
	                    			{
	                    			//System.out.println("getting into FX handler's price");
	                    			if (cell.getColumnIndex() == 3)
	                				{
	                				Float f = new Float (cell.getNumericCellValue());
	                				System.out.println(" FX price :"+rowNum+" :"+f);
	                				FX_price.add(f);
	                				}
	                    			
	                    			}
	                        	
	                        
	                            break;
	                            
	                            
	                        case Cell.CELL_TYPE_STRING:

	                        	//## stock handler
	                        	if((rowNum <= s[1]) && (rowNum > s[0])) //range is within stock
	                			{
	                			
	                			//if column is 0, it is Stock name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				stk_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Stock symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				stk_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        		
	                        	//## bond handler
	                        	if((rowNum <= s[3]) && (rowNum > s[2])) //range is within bond
	                			{
	                			
	                			//if column is 0, it is Bond name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				bond_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Bond symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				bond_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is Bond CUSIP
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				bond_cusip.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                		  	
	                    		//## MF handler
	                        	if((rowNum <= s[5]) && (rowNum > s[4])) //range is within MF
	                			{
	                			
	                			//if column is 0, it is MF name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				MF_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is MF symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				MF_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is MF CUSIP
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				MF_cusip.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                    		  	
	                    		//## FX handler
	                        	if((rowNum <= s[7]) && (rowNum > s[6])) //range is within FX
	                			{
	                			
	                			//if column is 0, it is FX name
	                			if (cell.getColumnIndex() == 0)
	                				{
	                				System.out.println("The name here is"+cell.getStringCellValue());
	                				FX_name.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 1, it is Ticker symbol
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
	                				FX_symbl.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        	
	                        	// ## News Handler ( cell column index 1,2)
	                        	if((rowNum <= s[9]) && (rowNum > s[8])) //range is within News
	                			{
	                			
	                			//if column is 1, it is News
	                			if (cell.getColumnIndex() == 1)
	                				{
	                				//System.out.println("The name here is"+cell.getStringCellValue());
	                				News.add(cell.getStringCellValue());
	                				}
	                			
	                			//if column is 2, it is News Date
	                			if (cell.getColumnIndex() == 2)
	                				{
	                				System.out.println("The ticker symbol here is"+cell.getStringCellValue());
	                				News_date.add(cell.getStringCellValue());
	                				}
	                			
	                			}
	                        	
	                        	
	                        	
	                        	break;
	                        	
	                        case Cell.CELL_TYPE_BLANK:
	                        	//System.out.println(cell.getRowIndex()+":"+cell.getColumnIndex()+"\t <bc>\t");
	                        	break;
	                        	
	                        
	                        	
	                        
	                    }
	                    
	                  
	                    
	                }
	           
	              
	             
	            }
				
	            //printing stock names
	            for (int i=0 ; i<stk_name.size() ; i++)
	            	System.out.println(stk_name.get(i)+" : "+stk_symbl.get(i)+" : "+stk_cusip.get(i)+" : "+stk_price.get(i));
	           
	            //printing bond names
	            for (int i=0 ; i<bond_name.size() ; i++)
	            	System.out.println(bond_name.get(i)+" : "+bond_symbl.get(i)+" : "+bond_cusip.get(i)+" : "+bond_price.get(i));
	           
	          //printing MF names
	            for (int i=0 ; i<MF_name.size() ; i++)
	            	System.out.println(MF_name.get(i)+" : "+MF_symbl.get(i)+" : "+MF_cusip.get(i)+" : "+MF_price.get(i));
	           
		        //printing FX names
	            System.out.println("printing FX names\n size is");
	            System.out.println(FX_name.size());
		        for (int i=0 ; i<FX_name.size() ; i++)
		        	System.out.println(FX_name.get(i)+" : "+FX_symbl.get(i)+" : "+FX_price.get(i));
		      //printing news
		        for (int i=0 ; i<News.size() ; i++)
		        System.out.println(News.get(i)+" : "+News_date.get(i));

	            
	        
		       
		        
		        //adding FX objects
		        FXobj.setFX_name(FX_name);
		        FXobj.setTicker_symbol(FX_symbl);
		        FXobj.setPrice(FX_price);
		        FXobj.setDate(sdate);
		        

		        
		        
		        System.out.println("date is again : "+sdate);
	            
	          
	            
			} 
			
			catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	    
		return FXobj;
	}
	
	public JavaNews ReadNews(){
		return Newsobj;
	}

	
}
