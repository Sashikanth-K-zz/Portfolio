package com.bku.inautix.model;

import java.util.ArrayList;
import java.util.List;

public class JavaNews {
	
	List<String> News = new ArrayList<String>();
	List<String> News_date = new ArrayList<String>();
	public List<String> getNews() {
		return News;
	}
	public void setNews(List<String> news) {
		News = news;
	}
	public List<String> getNews_date() {
		return News_date;
	}
	public void setNews_date(List<String> news_date) {
		News_date = news_date;
	}
	
	
	

}