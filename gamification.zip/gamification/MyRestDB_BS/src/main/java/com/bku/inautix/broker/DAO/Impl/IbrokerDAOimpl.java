package com.bku.inautix.broker.DAO.Impl;
import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.BrokerDetailsBean;
import com.bku.inautix.admin.rowmapper.BrokerRowMapper;
import com.bku.inautix.broker.DAO.IbrokerDAO;
import com.bku.inautix.broker.bean.BrokerValuesBean;
import com.bku.inautix.broker.bean.StatusBean;
import com.bku.inautix.broker.rowMapper.BrokerValuesRowMapper;

public class IbrokerDAOimpl implements IbrokerDAO
{
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void saveBroke(String broker_id,String broker_name,float futures, float mf,float equity,float fx,float bond,String mf_ratio,String mf_rate,JdbcTemplate jdbcTemplate)
	{
		
		try {
			String futures1=String.format("%.2f", futures);
			String mf1=String.format("%.2f", mf);
			String equity1=String.format("%.2f", equity);
			String fx1=String.format("%.2f", fx);
			String bond1=String.format("%.3f",bond);
			int[] types = new int[] {Types.VARCHAR,Types.VARCHAR,Types.FLOAT,Types.FLOAT, Types.FLOAT, Types.FLOAT,Types.FLOAT, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR};
			System.out.println("try started");
			mf_ratio=mf_ratio.replace("colon", ":");
			jdbcTemplate.update(
					"insert into T_BROKER_DET(broker_id,broker_name,futures_rate,mf_rate,equities_rate,fx_rate,bonds_rate,margin_fund_ratio,margin_fund_rate,status) values(?,?,?,?,?,?,?,?,?,?)",
					 new Object[]{broker_id,broker_name,futures1,mf1,equity1,fx1,bond1,mf_ratio,mf_rate+"%","bs"},types);


			System.out.println("update successful BBB");
		} catch (Exception e) {
			System.out.println("Update Error");
			e.printStackTrace();
			
		}
		
		
		//if we return null here, it sends back a 404.  Good.
		//return obj;
		
	 }
	
	public StatusBean publishBroker(int broker_id,JdbcTemplate jdbcTemplate)
	{
		 StatusBean statusBean=new StatusBean();
			try {
				System.out.println("try started");
				int count=jdbcTemplate.update(
						"update t_broker_det set status='s' where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=? and status='bs')",

						 new Object[]{broker_id,broker_id});
			if(count==0)
				statusBean.setStatus(null);
			else
				statusBean.setStatus("true");
			} catch (Exception e) {
				System.out.println("Update Error");
				e.printStackTrace();	
			}	
			return statusBean;
	}
	
	public List<BrokerValuesBean> ViewAllBrokers(int broker_id,JdbcTemplate jdbcTemplate)
	{
		List<BrokerValuesBean> list = null;
		System.out.println("Inside Viewallbrokers");
        try {
               list = jdbcTemplate.query("select * from t_broker_det where broker_id=?",
                new Object[]{broker_id}, //in parameters
                new BrokerValuesRowMapper());
               System.out.println(list);
               
        } catch (Throwable fault) {
               System.out.println("Getting broker homescreen data");
               fault.printStackTrace();
               
        }
        
        
        return list;
		
	}
	
	public List<BrokerValuesBean> ViewBrokers(int broker_id,String status,JdbcTemplate jdbcTemplate)
	{
		
		List<BrokerValuesBean> list = null;
        try {
               list = jdbcTemplate.query("select * from t_broker_det where broker_id=? and status=?",
                new Object[]{broker_id,status}, //in parameters
                new BrokerValuesRowMapper());
               
        } catch (Throwable fault) {
               System.out.println("Getting broker homescreen data");
               fault.printStackTrace();
               
        }
        
        
        return list;
	
	}

	public StatusBean saveBalance(int broker_id, String balance,
			JdbcTemplate jdbcTemplate) {
		// TODO Auto-generated method stub
		StatusBean statusBean=new StatusBean();
		
		 try {
			 System.out.println("try started");
			 int[] types = new int[] {Types.FLOAT};
			 int count= jdbcTemplate.update(
						"update t_broker_det set br_holding=?  where broker_id=?",

						 new Object[]{balance,broker_id});
			 if(count==0)
					statusBean.setStatus(null);
				else
					statusBean.setStatus("true");
			 
             
      } catch (Throwable fault) {
             System.out.println("Getting broker homescreen data");
             fault.printStackTrace();
             
      }
		 return statusBean;
	}
	
	}
		
	


