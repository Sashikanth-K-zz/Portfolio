package com.bku.inautix.broker.bean;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="viewdetails")
public class BrokerValuesBean {
       
	private String brokerId;
    private float futures;
    private float mf;
    private float equities;
    private float fx;
    private float bond;
    private String marginRatio;
    private String marginRate;
    private String timestamp;
    private String status;
    private String broker_name;
	public String getBrokerId() {
		return brokerId;
	}
	public void setBrokerId(String brokerId) {
		this.brokerId = brokerId;
	}
	public float getFutures() {
		return futures;
	}
	public void setFutures(float futures) {
		this.futures = futures;
	}
	public float getMf() {
		return mf;
	}
	public void setMf(float mf) {
		this.mf = mf;
	}
	public float getEquities() {
		return equities;
	}
	public void setEquities(float equities) {
		this.equities = equities;
	}
	public float getFx() {
		return fx;
	}
	public void setFx(float fx) {
		this.fx = fx;
	}
	public float getBond() {
		return bond;
	}
	public void setBond(float bond) {
		this.bond = bond;
	}
	public String getMarginRatio() {
		return marginRatio;
	}
	public void setMarginRatio(String marginRatio) {
		this.marginRatio = marginRatio;
	}
	public String getMarginRate() {
		return marginRate;
	}
	public void setMarginRate(String marginRate) {
		this.marginRate = marginRate;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBroker_name() {
		return broker_name;
	}
	public void setBroker_name(String broker_name) {
		this.broker_name = broker_name;
	}
    
}
