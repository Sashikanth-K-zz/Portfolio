package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.FXServiceBean;

public class FXRowMapper implements RowMapper<FXServiceBean> {
	
	
	public FXServiceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		FXServiceBean obj = new FXServiceBean();		
	
		obj.setFX_name(rs.getString(1));
		obj.setTicker_symbol(rs.getString(2));
		
		obj.setPrice(rs.getFloat(3));
		obj.setDate(rs.getString(4));
		
		
		return obj; 
	}


}
