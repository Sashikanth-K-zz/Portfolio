	
	package com.bku.inautix.component;

	import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bku.inautix.broker.bean.*;
	
	public class InsertUtility {
		
		//static final int STOCK_SHEET_NUMBER=1;
		//static final int NEWS_SHEET_NUMBER=2;
		static final int ADVICE_SHEET_NUMBER=7;
		/* sheet numbers and corresponding reading functions soon to be introduced to deal with
		 * bonds,mutal funds,etc
		 */
		
		
		
		public static void insertAdvice(ArrayList<AdviceBean> adviceBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(ADVICE_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	 AdviceBean adviceBean=new AdviceBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                  adviceBean.setAdvice(cell.getStringCellValue());
	                  
	                  cell = cellIterator.next();
	                  adviceBean.setId(new Integer((int) cell.getNumericCellValue()));
	              System.out.println("first"+ adviceBean.getAdvice());
	              adviceBeanList.add(adviceBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}

	

