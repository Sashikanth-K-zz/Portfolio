package com.bku.inautix.admin.dao;

import java.util.Date;
import java.util.List;

import javax.ws.rs.PathParam;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.ApprovalBean;
import com.bku.inautix.admin.bean.ApprovedBrokerBean;
import com.bku.inautix.admin.bean.BondServiceBean;
import com.bku.inautix.admin.bean.BrokerDetailsBean;
import com.bku.inautix.admin.bean.PublishedRatesBean;
import com.bku.inautix.admin.bean.RejectedBrokerBean;

public interface IBrokerDAO {
	
	public List<BrokerDetailsBean> getBrokerDetails(JdbcTemplate jdbcTemplate);
	public void approveBroker(@PathParam("broker_name") String brname,JdbcTemplate jdbcTemplate);
	public void publishBroker(@PathParam("broker_name") String brname,JdbcTemplate jdbcTemplate);
	public void rejectBroker(@PathParam("broker_name") String brname,JdbcTemplate jdbcTemplate);
	public List<RejectedBrokerBean> getBrokerRejected(JdbcTemplate jdbcTemplate);
	public List<PublishedRatesBean> getPublishedRates(JdbcTemplate jdbcTemplate);
	public List<ApprovalBean> getApprovalBroker(JdbcTemplate jdbcTemplate);
	public List<ApprovedBrokerBean> getApprovedBroker(JdbcTemplate jdbcTemplate);
	
	public String makeAdmin(@PathParam("userid") String userid,JdbcTemplate jdbcTemplate);
	public String removeUser(@PathParam("userid") String userid,JdbcTemplate jdbcTemplate);
	public String makeUser(@PathParam("userid") String userid,JdbcTemplate jdbcTemplate);
	
	 public String changeInterest(@PathParam("market_rate") float market_rate,JdbcTemplate jdbcTemplate);
	 public List<BondServiceBean> getBond(@PathParam("datetime") Date datetime,JdbcTemplate jdbcTemplate);
}
