package com.bku.inautix.model;

import java.util.List;

public class FX {
	
	private List<String> FX_name;
	private List<String> Ticker_symbol;
	private List<Float> price;
	private String date;
	
	public List<String> getFX_name() {
		return FX_name;
	}
	public void setFX_name(List<String> fX_name) {
		FX_name = fX_name;
	}
	public List<String> getTicker_symbol() {
		return Ticker_symbol;
	}
	public void setTicker_symbol(List<String> ticker_symbol) {
		Ticker_symbol = ticker_symbol;
	}
	public List<Float> getPrice() {
		return price;
	}
	public void setPrice(List<Float> price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	

}
