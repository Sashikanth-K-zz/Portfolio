package com.bku.inautix.admin.dao.impl;

import java.sql.Types;
import java.util.Date;
import java.util.List;

import javax.ws.rs.PathParam;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.ApprovalBean;
import com.bku.inautix.admin.bean.ApprovedBrokerBean;
import com.bku.inautix.admin.bean.BondServiceBean;
import com.bku.inautix.admin.bean.BrokerDetailsBean;
import com.bku.inautix.admin.bean.MarketRateBean;
import com.bku.inautix.admin.bean.PublishedRatesBean;
import com.bku.inautix.admin.bean.RejectedBrokerBean;
import com.bku.inautix.admin.dao.IBrokerDAO;
import com.bku.inautix.admin.rowmapper.ApprovalRowMapper;
import com.bku.inautix.admin.rowmapper.ApprovedRowMapper;
import com.bku.inautix.admin.rowmapper.BondRowMapper;
import com.bku.inautix.admin.rowmapper.BrokerRowMapper;
import com.bku.inautix.admin.rowmapper.MarketRateRowMapper;
import com.bku.inautix.admin.rowmapper.PublishedRatesRowMapper;
import com.bku.inautix.admin.rowmapper.RejectedRowMapper;

public class BrokerDAO implements IBrokerDAO{
	
	
		
	
	public List<PublishedRatesBean> getPublishedRates(JdbcTemplate jdbcTemplate)
	{
		
		List<PublishedRatesBean> list= null;
        try 
               {
   
        	
        	
               list= jdbcTemplate.query("select * from t_broker_det where status='p'",
                new Object[]{}, //in parameters
                new PublishedRatesRowMapper());
            }  
        
        catch (Throwable fault)
               {
               
        	 System.out.print("inga dan exception");
               fault.printStackTrace();
               
               }
        
        System.out.println(" Got the brokers, returning to you buddy");
               
        //if we return null here, it sends back a 404.  Good.
        return list;

	}
	
	
	
	public List<BrokerDetailsBean> getBrokerDetails(JdbcTemplate jdbcTemplate)
	{
		List<BrokerDetailsBean> list = null;
		try {
			list = jdbcTemplate.query("select * from t_broker_det where time_stamp in (select max(time_stamp) from t_broker_det group by broker_name)   and   status not in('r','p','bs','BS') ",
		        new Object[]{}, //in parameters
		        new BrokerRowMapper());
			
			
			
		} catch (Throwable fault) {
			
			
			System.out.println("EXXXCEPTION");
            fault.printStackTrace();
           
		}
		return list;
		
		//if we return null here, it sends back a 404.  Good.
		

	}
	
	
	
	
public void approveBroker(String brname,JdbcTemplate jdbcTemplate)
	{
		//int success=0;
        try 
        {
                     
                   jdbcTemplate.update(
                            "update t_broker_det set status='a' where broker_name=? and status='s' and time_stamp=(select max(time_stamp) from t_broker_det where broker_name=?)",new Object[]{brname,brname});
                   // if(success==1)
                    	//return "updated successfully";
                    	//else
                    	//	return "not updated";
                    
                     
        } 
        catch (Throwable fault) 
        {
              System.out.println("EXXXCEPTION");
              fault.printStackTrace();
              //return "exception thrown";
        }


	}
	
	
	
	public void publishBroker(String brname,JdbcTemplate jdbcTemplate)
	{
		//int success=0; 
		   
		 
        try 
        {
                     
jdbcTemplate.update(
                            "update t_broker_det set status='p' where broker_name=? and status='a' and time_stamp=(select max(time_stamp) from t_broker_det where broker_name=?)",new Object[]{brname,brname});
                  
     
   //  if (success==1)
    // 	return "Successfully updated";
     //	else
     	//	return "not updated";
     	
     
     
        } 
        catch (Throwable fault) 
        {
              System.out.println("EXXXCEPTION");
            //  return ("exception");
        }
   
	
	}
	
	
	public void rejectBroker(String brname,JdbcTemplate jdbcTemplate)
	{
	//	 int success;
	      try 
	      {
	     	 
	                   
	              jdbcTemplate.update(
	                          "update t_broker_det set status='r' where broker_name=? and status='s' and time_stamp=(select max(time_stamp) from t_broker_det where broker_name=?)",new Object[]{brname,brname});
	         
	              //  if (success==1)
	                // 	return "Successfully updated";
	                 //	else
	                 	//	return "not updated";
	          
	      } 
	      catch (Throwable fault) 
	      {
	            System.out.println("EXXXCEPTION");
	            fault.getStackTrace();
	            //return "exception";
	         
	            
	      }
	

	}
	
	public List<RejectedBrokerBean> getBrokerRejected(JdbcTemplate jdbcTemplate)
	{
		
	
	
	List<RejectedBrokerBean> list =null;
	try {
		list = jdbcTemplate.query("select * from t_broker_det where status='r'",
	       new Object[]{}, //in parameters
	       new RejectedRowMapper());
		
	} 
catch (Throwable fault)
	{
System.out.println("Got error.  Returning null (404)");
fault.printStackTrace();

}

//if we return null here, it sends back a 404.  Good.
return list;
	
	}


	
	
	
	public List<ApprovalBean> getApprovalBroker(JdbcTemplate jdbcTemplate)
	{
		List<ApprovalBean> list = null;
		try {
			list = jdbcTemplate.query("select * from t_broker_det where broker_name='icici' and status='s' and time_stamp=(select max (time_stamp) from t_broker_det where broker_name='icici') union select * from t_broker_det where broker_name='sharekhan' and status='s' and time_stamp=(select max (time_stamp) from t_broker_det where broker_name='sharekhan') union (select * from t_broker_det where broker_name='hdfc' and status='s' and time_stamp=(select max (time_stamp) from t_broker_det where broker_name='hdfc'))",
		        new Object[]{}, //in parameter
		        new ApprovalRowMapper());
		} 
		catch (Throwable fault)
     {
     System.out.println("Got error.  Returning null (404)");
     
     
     }
		
		//if we return null here, it sends back a 404.  Good.
		return list;
	
	}
	
	
	public List<ApprovedBrokerBean> getApprovedBroker(JdbcTemplate jdbcTemplate)
	{
		List<ApprovedBrokerBean> list = null;
		try {
			list = jdbcTemplate.query("select * from t_broker_det where status='a'",
		        new Object[]{}, //in parameter
		        new ApprovedRowMapper());
		} 
		catch (Throwable fault)
     {
     System.out.println("Got error.  Returning null (404)");
     
     
     }
		System.out.println(" Got the brokers, returning to you buddy");
		//if we return null here, it sends back a 404.  Good.
		return list;

	}

	//Abishek	
	
	 public String makeAdmin(@PathParam("userid") String userid,JdbcTemplate jdbcTemplate) {
			
			String sql = "UPDATE portfolio SET type='a' WHERE usrname = ?";
			int[] types={Types.VARCHAR};
			try {
				int success = jdbcTemplate.update(sql,
				        new Object[]{userid}, types);
				
				System.out.println(success);
				
				if(success==1){
					return (userid+" is made as admin");
					}else{
						return "!!! User not available !!!";	
						
					}
			
				
			} catch (Throwable fault) {
				System.out.println("Update to make admin failed");
				fault.printStackTrace();
				return "Exception occured: Update to make admin failed";

			}
			// if we return null here, it sends back a 404. Good.

		}
	 
	 //Abishek
	 public String removeUser(@PathParam("userid") String userid,JdbcTemplate jdbcTemplate) {
			
			String[] sql = {"DELETE from PORTFOLIO WHERE usrname = ?",
					"DELETE from BALANCE WHERE uid = ?",
					"DELETE from USER_SCREEN WHERE id = ?",
				    "DELETE from HOLDING WHERE uid = ?",
					"DELETE from TRANSACTION1 WHERE uid = ?",
					"DELETE from RANK_TABLE WHERE uid = ?"};
			int[] types={Types.VARCHAR};
		
			try {int[] success={0,0,0,0,0,0};
				for(int i=0;i<sql.length;i++){
				success[i]= jdbcTemplate.update(sql[i],
				        new Object[]{userid}, types);
				
				}
				System.out.println(success[0]);
				for(int j=0;j<success.length-3;j++){System.out.println(success[j]);
				if(success[j]==0){
					
					return "!!! Removing User failed !!! User may not be available ";
					}
				}
				
				return (userid+" is removed");
			
				
			} catch (Throwable fault) {
				System.out.println("remove users");
				fault.printStackTrace();
				return "Exception occured: Update to remove user failed";

			}
		

		}
	 
	 
	 public String makeUser(@PathParam("userid") String userid,JdbcTemplate jdbcTemplate) {
			
			String sql = "UPDATE portfolio SET type='u' WHERE usrname = ?";
			int[] types={Types.VARCHAR};
			try {
				
				int success = jdbcTemplate.update(sql,
				        new Object[]{userid}, types);
				
				System.out.println(success);
				
				if(success==1){
					return (userid +" is made as user");
					}else{
						return "!!! Admin not available !!!";	
					}
				
				
			} catch (Throwable fault) {
				System.out.println("make as user");
				fault.printStackTrace();
				return "Exception occured: Update for making user failed";

			}
			

		}
 
 public String changeInterest(@PathParam("market_rate") float market_rate,JdbcTemplate jdbcTemplate){
	 List<MarketRateBean> obj = null;
	 int  ret_obj;
	 float table_rate=0; 
	 //int[] types= new int[] {Types.FLOAT,Types.FLOAT};
	try {
					obj = jdbcTemplate.query("select market_interest from bonds ",
			        new Object[]{}, //in parameter
			        new MarketRateRowMapper());
					table_rate=obj.get(1).getMarket_rate();
				if(table_rate>market_rate){
			  ret_obj = jdbcTemplate.update("UPDATE bonds SET price=(price+(?*price)),market_interest=? ",new Object[]{market_rate,market_rate});
			  
		}
		else if (table_rate<market_rate){
			   ret_obj = jdbcTemplate.update("UPDATE bonds SET price=(price-(?*price)),market_interest=? ",new Object[]{market_rate,market_rate});
			   
		}
		else
			ret_obj=1;
   
  
    
     if(ret_obj==0)
     {
  	 
  	   return "Update Failed!";
     }
     else
     {
  	  
  	   return "Success";
     }
     
	} catch (Throwable fault) {
		
		//log.info(fault.getStackTrace());
		return "Exception";
		
	}
					
 }
 
 public List<BondServiceBean> getBond(@PathParam("datetime") Date datetime,JdbcTemplate jdbcTemplate) {
		List<BondServiceBean> list= null;
		try {
			list=  jdbcTemplate.query("select * from bonds",
		        new Object[]{}, //in parameters
		        new BondRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
			
		}
		System.out.println(" Got the Bond, returning to you buddy");
		
		
			
		//if we return null here, it sends back a 404.  Good.
		return list;
	 }


	
}
