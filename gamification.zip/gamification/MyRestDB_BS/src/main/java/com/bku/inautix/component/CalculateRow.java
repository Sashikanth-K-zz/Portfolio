package com.bku.inautix.component;


import java.util.Iterator;

import org.apache.poi.ss.usermodel.Row;


public class CalculateRow {
	
	public int[] getSize(Iterator<Row> rowIterator){
		
		System.out.println(" called the get size method");
		int s[] = new int[10];
		String stk[] = new String[3];
		int currentRow=0;
		int prevRow=-1;
		
		/*int flag=0;
		int max_space_counter=0;
		int limit=5;
		*/
		
try {
	
			
		       while (rowIterator.hasNext())
            {
            
                Row row = rowIterator.next();
                //For each row, iterate through all the columns
             
                
            /* if(row.getCell(0) == null && flag == 0){
            	 
            		 flag =1;
                 	s[9]=prevRow+1;
                 	
                 	System.out.println("News ends at : "+s[7]);
                 	System.out.println("done parsing for stock,bond,MF,FX,News...");
                 	return s;
            	 
             }  */
              
                
             
                
                   prevRow=currentRow;
                  if (row.getCell(0).getCellType() == 1){
                	  
                  
                    stk[0]=row.getCell(0).getStringCellValue();
        			stk[1]=row.getCell(1).getStringCellValue();
        			//stk[2]=row.getCell(2).getStringCellValue();
                  }
                  else if(row.getCell(0).getCellType() == 0)
                	  {
                	 Double temp=row.getCell(0).getNumericCellValue();
                	 stk[0] = temp.toString();
                	
                	System.out.println(" value of the readed numeric cell is :"+stk[0]);
          			stk[1]=row.getCell(1).getStringCellValue();
          			stk[2]=row.getCell(2).getStringCellValue();
          			
                	  }
                  else if(row.getRowNum() > s[8]){
                	  if ( row.getCell(0) == null){
                		  System.out.println("this is returning the value");
                		  s[9]= prevRow+1;
                		  return s;
                	  }
                  }
                  
                
                  currentRow=row.getRowNum();
        	        
        	        
        	        // System.out.println("flag : "+flag);
        		//	System.out.println(stk[0]);
        			//System.out.println(stk[1]);
        	        
        	      //  System.out.println("previous @ row : "+prevRow);
 
        			//System.out.println("currently @ row : "+currentRow);
        	        
        	        
        	        
        		
     			if(stk[0].equalsIgnoreCase("Stock Name")){
        				//System.out.println( "case 1 is true");
        				//System.out.println(" checking the next cell");
        				if(stk[1].equalsIgnoreCase("Symbol")){
        					//System.out.println(" case 2 is true");
        					//System.out.println(" getting row number");
        					s[0]=row.getRowNum();
        					
        					//System.out.println("Stock starts at :" +s[0]);
        					
        				}
        			}
        				
        			
        			if(stk[0].equalsIgnoreCase("Bond Name")){
        				//System.out.println( "case 1 is true");
        				//System.out.println(" checking the next cell");
        				if(stk[1].equalsIgnoreCase("Symbol")){
        					//System.out.println(" case 2 is true");
        					//System.out.println(" getting row number");
        					
        					s[1]=prevRow;
        					s[2]=row.getRowNum();
        				
        					//System.out.println("Stock ends at :" +s[1]);
        					//System.out.println("Bond starts at :" +s[2]);
        					
        				}
        			}
        			
        			
        			if(stk[0].equalsIgnoreCase("MF Name")){
        				//System.out.println( "case 1 is true");
        				//System.out.println(" checking the next cell");
        				if(stk[1].equalsIgnoreCase("Ticker Symbol")){
        					//System.out.println(" case 2 is true");
        					//System.out.println(" getting row number");
        					
        					s[3]=prevRow;
        					s[4]=row.getRowNum();
        					
        					//System.out.println("Bond ends at :" +s[3]);
        					//System.out.println("MF starts at :" +s[4]);
        					
        				}
        			}
        			
        			if(stk[0].equalsIgnoreCase("FX")){
        				//System.out.println( "case 1 is true");
        				//System.out.println(" checking the next cell");
        				if(stk[1].equalsIgnoreCase("Ticker Symbol")){
        				//	System.out.println(" case 2 is true");
        					//System.out.println(" getting row number");
        					
        					s[5]=prevRow;
        					s[6]=row.getRowNum();
        					
        					//System.out.println("MF ends at :" +s[5]);
        					//System.out.println("FX starts at :" +s[6]);
        				
        				}
        			}
        			
        			
        			if(stk[0].equalsIgnoreCase("SNO")){
        				//System.out.println( "case 1 is true");
        				//System.out.println(" checking the next cell");
        				if(stk[1].equalsIgnoreCase("News")){
        				//	System.out.println(" case 2 is true");
        					//System.out.println(" getting row number");
        					
        					s[7]=prevRow;
        					s[8]=row.getRowNum();
        					
        					//System.out.println("FX ends at :" +s[7]);
        					//System.out.println("News starts at :" +s[8]);
        				
        				}
        			}
        			
        		
        			
        			
        		//	System.out.println("prev Row :"+prevRow);
        		
             
            }
			
           // stkobj.setStkName(st_names);
           // stkobj.setStkPrice(st_price);
            
          
            
		} 
		
		 
		catch (NullPointerException e) {
			System.out.println("Reached end of file ");
			
		}
		
		System.out.println("the end is returning the value");
		s[9]=prevRow+1;
		return s;

		
	}
}
