package com.bku.inautix.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="transactionhistory")

public class TransactionHistory {
	
	public TransactionHistory(){}
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public Date getDat() {
		return dat;
	}
	public void setDat(Date dat) {
		this.dat = dat;
	}
	public String getSybl() {
		return sybl;
	}
	public void setSybl(String sybl) {
		this.sybl = sybl;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}


	public TransactionHistory(String userid, Date dat, String sybl, int quantity,
			float price, String security_type,String action,float br_fee,float br_int) {
		super();
		this.userid = userid;
		this.dat = dat;
		this.sybl = sybl;
		this.quantity = quantity;
		this.price = price;
		this.security_type=security_type;
		this.action = action;
		this.br_fee=br_fee;
		this.br_int=br_int;
	}
	private String security_type;
	public String getSecurity_type() {
		return security_type;
	}

	public void setSecurity_type(String security_type) {
		this.security_type = security_type;
	}
	private String userid;
	private Date dat;
	private String sybl;
	private int quantity;
	private float price;
	private String action;
	private float br_fee;
	private float br_int;
	public float getBr_fee() {
		return br_fee;
	}

	public void setBr_fee(float br_fee) {
		this.br_fee = br_fee;
	}

	public float getBr_int() {
		return br_int;
	}

	public void setBr_int(float br_int) {
		this.br_int = br_int;
	}
}
