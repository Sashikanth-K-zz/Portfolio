
// 13484
package com.bku.inautix.common.controller;

import java.sql.Types;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bku.inautix.common.bean.SessionBean;
import com.bku.inautix.dao.SessionMapper;


@Service("CommonServiceBean")
@Path("commonservice")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CommonService {

		
	@Context private HttpServletRequest request;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private static Logger log;
	//private final int SESSION_TIME_OUT=15*60;

	public CommonService() {
		log = Logger.getLogger(CommonService.class.getName());
	}
	
	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	//*********************************Helper Method for registerCheck method*******************************
	// 13484
	public SessionBean register( String usrname,
			 String passwd,  String name,String email_id) {
			try {
				
			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR,Types.VARCHAR };
			int[] type = new int[] { Types.VARCHAR };
			jdbcTemplate.update("insert into portfolio("+"usrname,"+"passwd,"+"name,"+"email_id,"+"type)"+" values (?,?,?,?,"+"'u')",
					new Object[] { usrname, passwd, name,email_id },// in
																		// parameter
					types);
			HttpSession session=request.getSession(true);
			//session.setMaxInactiveInterval(SESSION_TIME_OUT);
			session.setAttribute("id",usrname );
			session.setAttribute("name",name );
			session.setAttribute("type","u" );
			
			jdbcTemplate.update("insert into balance(uid,balance) values(?,"
					+ "100000" + ")", new Object[] { usrname },// in parameter
					type);
			jdbcTemplate.update("insert into user_screen(id,balance) values(?,"
					+ "100000" + ")", new Object[] { usrname },// in parameter
					type);
			log.info(usrname + "100000");
		} catch (Throwable fault) {
			

			log.info(fault.getStackTrace());
			request.getSession(false).invalidate();
			
			return null;

		}
		return new SessionBean(usrname,name,"u");
	}

	// ***********************Checking before registration. Whether username already exists or not ***************
	// 13484
	@GET
	@Path("register/{usrname}/{passwd}/{regname}/{email_id}")
	@Produces(MediaType.APPLICATION_JSON)
	public SessionBean registerCheck(@PathParam("usrname") String usrname,@PathParam("passwd") String password,@PathParam("regname") String name,@PathParam("email_id") String email_id) {
		SessionBean sessionBean ;
		try {
			 sessionBean = jdbcTemplate.queryForObject(
					"select usrname,name,type from portfolio where usrname = ?",
					new Object[] { usrname },// in parameter
					new SessionMapper());
			log.info(sessionBean.getId());
			sessionBean=null;
			
		} catch (DataAccessException doe) {
		
				sessionBean=register(usrname,password,name,email_id);	
		
				return sessionBean;
			
		}
		catch(Exception e)
				{
			
			
			log.info(e.getStackTrace());
			request.getSession(false).invalidate();
			return null;
				}
	
		return sessionBean;
	}
	//**************************************Login************************************
	// 13484
	@GET
	@Path("login/{usrname}/{passwd}")
	@Produces(MediaType.APPLICATION_JSON)
	public SessionBean processLoginRequest(@PathParam("usrname") String usrname,
			@PathParam("passwd") String passwd) {
		try {

			SessionBean sessionBean = jdbcTemplate.queryForObject(
					"select usrname, type,name from portfolio where usrname = ? and passwd = ?",
					new Object[] { usrname, passwd },// in parameter
					new SessionMapper());
		
			HttpSession session=request.getSession(true);
			//session.setMaxInactiveInterval(SESSION_TIME_OUT);
			session.setAttribute("id", sessionBean.getId());
			session.setAttribute("type",sessionBean.getType());
			session.setAttribute("name",sessionBean.getName());
			log.info("User Entered is : " + sessionBean.getId());
			
			return sessionBean;
		}
		catch(DataAccessException doe)
		{
		
		
			log.info("Invalid username or password!!");
	
			
			log.info(doe.getStackTrace());

			
			return null;
		}
		catch (Exception e) {
		
			if(request.getSession(false)!=null)
				request.getSession(false).invalidate();
			
			return null;
		}
		
	}
	
	// **********************Checking whether the user is logged in or not*******************
	// 13484
		@GET
		@Path("sessioncheck")
		@Produces(MediaType.APPLICATION_JSON)
		public SessionBean validateSession() {
			//System.out.println("here");
			SessionBean sessionBean;
			
			if(request.getSession(false)==null)
			{
				sessionBean=null;
			
				
			}
			else
			{
				sessionBean=new SessionBean(request.getSession(false).getAttribute("id").toString(),request.getSession(false).getAttribute("name").toString(),request.getSession(false).getAttribute("type").toString());
			
			}
		/*	if(sessionBean!=null)	
			System.out.println(sessionBean.getId());
			else
				System.out.println("sessionBean is null");
				*/
			return  sessionBean;
				
			
		}
	
		// ********************************Log Out***********************************************
		// 13484
		@GET
		@Path("logout")
		@Produces(MediaType.APPLICATION_JSON)
		public void logOut() {
		  if(request.getSession(false)!=null)
		  request.getSession(false).invalidate();
		
		}

}
