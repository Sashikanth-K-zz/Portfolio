package com.bku.inautix.dao;

public interface INewsDao {

}
