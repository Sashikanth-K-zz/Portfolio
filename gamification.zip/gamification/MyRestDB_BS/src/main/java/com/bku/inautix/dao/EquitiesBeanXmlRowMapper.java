package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.bku.inautix.model.EquitiesBeanXml;

public class EquitiesBeanXmlRowMapper implements RowMapper<EquitiesBeanXml> {
	public EquitiesBeanXml mapRow(ResultSet rs, int rowNum) throws SQLException {
		EquitiesBeanXml obj = new EquitiesBeanXml();		
		obj.setName(rs.getString("equ_name"));
		obj.setPrice(rs.getFloat("price"));
		return obj;
	}
}