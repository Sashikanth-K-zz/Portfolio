package com.bku.inautix.broker.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="savebrokervalues")
public class SaveBrokerValues {
	
	private int futures;
	private int mf;
	private int equities;
	private int fx;
	private int bond;
	private String mf_ratio;
	private String mf_rate;
	public int getFutures() {
		return futures;
	}
	public void setFutures(int futures) {
		this.futures = futures;
	}
	public int getMf() {
		return mf;
	}
	public void setMf(int mf) {
		this.mf = mf;
	}
	public int getEquities() {
		return equities;
	}
	public void setEquities(int equities) {
		this.equities = equities;
	}
	public int getFx() {
		return fx;
	}
	public void setFx(int fx) {
		this.fx = fx;
	}
	public int getBond() {
		return bond;
	}
	public void setBond(int bond) {
		this.bond = bond;
	}
	public String getMf_ratio() {
		return mf_ratio;
	}
	public void setMf_ratio(String mf_ratio) {
		this.mf_ratio = mf_ratio;
	}
	public String getMf_rate() {
		return mf_rate;
	}
	public void setMf_rate(String mf_rate) {
		this.mf_rate = mf_rate;
	}

}
