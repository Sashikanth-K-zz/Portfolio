package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.FXPriceBean;
import com.bku.inautix.model.MFPriceBean;


public class FXPriceRowMapper implements RowMapper<FXPriceBean>{

public FXPriceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		FXPriceBean obj = new FXPriceBean();		
		obj.setPrice(rs.getFloat("price"));
	
		obj.setFx_name(rs.getString("fx_name"));
		return obj;
}

}
