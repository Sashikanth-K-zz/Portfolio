package com.bku.inautix.model;

public class SecuritiesBean {
	 private String futures;
	    private String mf;
	    private String equities;
	    private String fx;
	    private String bond;
		public String getFutures() {
			return futures;
		}
		public void setFutures(String futures) {
			this.futures = futures;
		}
		public String getMf() {
			return mf;
		}
		public void setMf(String mf) {
			this.mf = mf;
		}
		public String getEquities() {
			return equities;
		}
		public void setEquities(String equities) {
			this.equities = equities;
		}
		public String getFx() {
			return fx;
		}
		public void setFx(String fx) {
			this.fx = fx;
		}
		public String getBond() {
			return bond;
		}
		public void setBond(String bond) {
			this.bond = bond;
		}
}
