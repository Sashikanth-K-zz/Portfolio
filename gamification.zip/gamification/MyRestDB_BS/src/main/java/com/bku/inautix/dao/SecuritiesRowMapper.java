package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.SecuritiesBean;


public class SecuritiesRowMapper  implements RowMapper<SecuritiesBean> {
    public SecuritiesBean mapRow(ResultSet rs, int rowNum) throws SQLException {
        SecuritiesBean obj = new SecuritiesBean();                          
        obj.setFutures(rs.getString("futures_rate"));
        obj.setMf(rs.getString("mf_rate"));
        obj.setEquities(rs.getString("equities_rate"));
        obj.setFx(rs.getString("fx_rate"));
        obj.setBond(rs.getString("bonds_rate"));
        return obj;
    }

}
