package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="Stock")
public class StockServiceBean {
	
	private String stk_name;
	private String stk_symbol;
	private String Stk_cusip;
	private Float stk_price;
	private String stk_date;
	
	
	public String getStk_name() {
		return stk_name;
	}
	public void setStk_name(String stk_name) {
		this.stk_name = stk_name;
	}
	public String getStk_symbol() {
		return stk_symbol;
	}
	public void setStk_symbol(String stk_symbol) {
		this.stk_symbol = stk_symbol;
	}
	public String getStk_cusip() {
		return Stk_cusip;
	}
	public void setStk_cusip(String stk_cusip) {
		Stk_cusip = stk_cusip;
	}
	public Float getStk_price() {
		return stk_price;
	}
	public void setStk_price(Float stk_price) {
		this.stk_price = stk_price;
	}
	public String getStk_date() {
		return stk_date;
	}
	public void setStk_date(String stk_date) {
		this.stk_date = stk_date;
	}
	
	
	
	

}
