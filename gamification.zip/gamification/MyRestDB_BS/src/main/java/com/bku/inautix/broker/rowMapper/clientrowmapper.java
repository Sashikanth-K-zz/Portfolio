package com.bku.inautix.broker.rowMapper;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.broker.bean.clientreport1;




	public class clientrowmapper implements RowMapper<clientreport1>
	{

		public clientreport1 mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			clientreport1 obj = new clientreport1();		
			
			obj. setName(rs.getString("name"));
			obj. setUser_Id(rs.getString("uid"));
			
			obj. setQuantity(rs.getInt("quantity"));
			obj. setPrice(rs.getFloat("price"));
			obj. setStatus(rs.getString("status"));
			obj. setNetvalue(rs.getFloat("netvalue"));
			obj. setBroker_fee(rs.getFloat("br_amount"));
			obj. setMar_Interest(rs.getFloat("marg_interest"));
			obj. setBid(rs.getString("bid"));
			return obj;
		}
		}

