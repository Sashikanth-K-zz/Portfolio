package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="news")
public class NewsXML {
private String news;

public String getNews() {
	return news;
}

public void setNews(String news) {
	this.news = news;
}
}
