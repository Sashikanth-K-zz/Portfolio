package com.bku.inautix.admin.dao.impl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.EquitiesBean;
import com.bku.inautix.admin.dao.IEquitiesDao;
import com.bku.inautix.admin.utility.InsertUtility;
import com.bku.inautix.dao.EquitiesBeanXmlRowMapper;
import com.bku.inautix.model.EquitiesBeanXml;
import com.bku.inautix.model.ExcelFilePathBean;

public class EquitiesDao implements IEquitiesDao{

	public void  insertEquities(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean)
	{
		log.info("\nEntered insertequities service");
			ArrayList<EquitiesBean> equitiesBeanList = new ArrayList<EquitiesBean>();
			InsertUtility.insertEquities(equitiesBeanList,excelFilePathBean.getExcelFilePath(),log);

			
				float dif,diff;
			    diff = 0.0f;
				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
						Types.VARCHAR, Types.FLOAT,Types.VARCHAR,Types.DATE ,Types.FLOAT};
				List<EquitiesBeanXml> oldEquitiesBeanList;
				
				try
				{
					oldEquitiesBeanList=jdbcTemplate.query("select equ_name,price from equities",new Object[]{},new EquitiesBeanXmlRowMapper());
					jdbcTemplate.update("delete from equities");
					for (int i=0; i< equitiesBeanList.size(); i++)
					{
						if(oldEquitiesBeanList.isEmpty()){
							dif=0;
							diff = dif;
						}
						else
						{
							dif=equitiesBeanList.get(i).getPrice()-oldEquitiesBeanList.get(i).getPrice();
			                	diff=((dif/oldEquitiesBeanList.get(i).getPrice())*100);		
						}
				
                         
					 jdbcTemplate.update(
							"insert into equities values(?,?,?,?,?,?,?)", new Object[] {
									equitiesBeanList.get(i).getName(), equitiesBeanList.get(i).getSymbol(),
									equitiesBeanList.get(i).getCusip(), equitiesBeanList.get(i).getPrice(),
									equitiesBeanList.get(i).getBeta(),new Date(),diff }, types);
					log.info("\nInserted equities values");
				
					}
					}
				catch(Exception e){
					e.printStackTrace();
				}
			

			
			log.info("\nReturning after inserting equities");
		
			
			
		}
		
	
	
	
}
