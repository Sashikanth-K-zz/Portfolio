package com.bku.inautix.broker.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.broker.bean.BrokerValuesBean;

public class BrokerNameRowMapper implements RowMapper<BrokerValuesBean>
{
	public BrokerValuesBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BrokerValuesBean obj = new BrokerValuesBean();
		
		obj.setBroker_name(rs.getString("broker_name"));
		obj.setBrokerId(rs.getString("broker_id"));
		return obj;
	}

	
}

