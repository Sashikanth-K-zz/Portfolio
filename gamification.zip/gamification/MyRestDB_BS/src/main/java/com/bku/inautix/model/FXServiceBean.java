package com.bku.inautix.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="FX")
public class FXServiceBean {
	
	private String FX_name;
	private String Ticker_symbol;
	private Float price;
	private String date;
	private String CUSIP;
	public String getCUSIP() {
		return CUSIP;
	}
	public void setCUSIP(String cUSIP) {
		CUSIP = cUSIP;
	}
	public String getFX_name() {
		return FX_name;
	}
	public void setFX_name(String fX_name) {
		FX_name = fX_name;
	}
	public String getTicker_symbol() {
		return Ticker_symbol;
	}
	public void setTicker_symbol(String ticker_symbol) {
		Ticker_symbol = ticker_symbol;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	

}
