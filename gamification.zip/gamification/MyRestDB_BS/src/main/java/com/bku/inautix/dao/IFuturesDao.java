package com.bku.inautix.dao;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.model.ExcelFilePathBean;

public interface IFuturesDao {
	public void insertFutures(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean);
}
