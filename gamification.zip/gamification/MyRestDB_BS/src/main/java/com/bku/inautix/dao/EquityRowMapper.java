package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.EquityBean;


	public class EquityRowMapper implements RowMapper<EquityBean> {
		public EquityBean mapRow(ResultSet rs, int rowNum) throws SQLException {
			EquityBean obj = new EquityBean();		
			obj.setBroker_id(rs.getString("broker_id"));
			obj.setB_name(rs.getString("broker_name"));
			obj.setMarg_ratio(rs.getString("margin_fund_ratio"));
			obj.setMarg_rate(rs.getString("margin_fund_rate"));
			return obj;
		}

}
