package com.bku.inautix.model;

public class ExcelFilePathBean {
	private String excelFilePath;

	public String getExcelFilePath() {
		return excelFilePath;
	}

	public void setExcelFilePath(String excelFilePath) {
		this.excelFilePath = excelFilePath;
	}
}
