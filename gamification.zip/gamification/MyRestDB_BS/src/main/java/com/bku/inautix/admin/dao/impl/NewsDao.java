package com.bku.inautix.admin.dao.impl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.NewsBean;
import com.bku.inautix.admin.dao.INewsDao;
import com.bku.inautix.admin.utility.InsertUtility;
import com.bku.inautix.model.ExcelFilePathBean;

public class NewsDao implements INewsDao {

	public void  insertNews(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean)
	{
	

			log.info("\nEntered insertnews service");
			ArrayList<NewsBean> newsBeanList = new ArrayList<NewsBean>();
			InsertUtility.insertNews(newsBeanList,excelFilePathBean.getExcelFilePath(),log);
				
				int[] types = new int[] {Types.VARCHAR,Types.DATE};
				jdbcTemplate.update("delete from news");
				for (NewsBean newsBean : newsBeanList) {
					jdbcTemplate.update("insert into news values(?,?)",
							new Object[] { newsBean.getNews(),new Date()}, types);
				}
					log.info("\nInserted news");
			

	}
		
}
