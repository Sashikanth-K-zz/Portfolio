package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="holding")
public class HoldingBean {
private String name;
private int quantity;
private float price;
private float holding;
private float amount_lg;
private float percentage_lg;
private float current_holding;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public float getHolding() {
	return holding;
}
public void setHolding(float holding) {
	this.holding = holding;
}
public float getAmount_lg() {
	return amount_lg;
}
public void setAmount_lg(float amount_lg) {
	this.amount_lg = amount_lg;
}
public float getPercentage_lg() {
	return percentage_lg;
}
public void setPercentage_lg(float percentage_lg) {
	this.percentage_lg = percentage_lg;
}
public float getCurrent_holding() {
	return current_holding;
}
public void setCurrent_holding(float current_holding) {
	this.current_holding = current_holding;
}

}