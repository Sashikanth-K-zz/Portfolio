package com.bku.inautix.admin.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="check")
public class CheckBean {
private int flag;
private int check;


public CheckBean()
{
	
}
public CheckBean(int flag)
{
	this.flag=flag;
}
public int getFlag() {
	return flag;
}
public void setFlag(int flag) {
	this.flag = flag;
}
public int getCheck() {
	return check;
}
public void setCheck(int check) {
	this.check = check;
}
}
