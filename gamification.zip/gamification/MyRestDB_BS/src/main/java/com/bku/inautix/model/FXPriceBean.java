package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="fxp")
public class FXPriceBean {
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getFx_name() {
		return fx_name;
	}
	public void setFx_name(String fx_name) {
		this.fx_name = fx_name;
	}
	private float price;
	public FXPriceBean(float price, String fx_name) {
		this.price = price;
		this.fx_name = fx_name;
	}
	public FXPriceBean() {
		
	}
	private String fx_name;

}
