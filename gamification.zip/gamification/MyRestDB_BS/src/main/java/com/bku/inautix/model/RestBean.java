package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="login")
public class RestBean {
	
	public RestBean(){}
	
	public RestBean(String usrname,String passwd) {
		this.usrname=usrname;
		this.passwd=passwd;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String name;
	private String usrname;
	private String passwd;
	public String getUsrname() {
		return usrname;
	}

	public void setUsrname(String usrname) {
		this.usrname = usrname;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

}
