package com.bku.inautix.admin.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.admin.bean.BondServiceBean;

public class BondRowMapper implements RowMapper<BondServiceBean> {
	
public BondServiceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BondServiceBean obj = new BondServiceBean();		
	
		obj.setBond_name(rs.getString("bond_name"));
		obj.setBond_symbl(rs.getString("bond_symbl"));
		obj.setCusip(rs.getString("cusip"));
		
		obj.setPrice(rs.getFloat("price"));
		obj.setMarketrate(rs.getFloat("market_interest"));
		
		
		return obj; 
	}

}