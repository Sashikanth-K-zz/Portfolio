package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.Equities;

public class EquitiesRowMapper  implements RowMapper<Equities> 
{
	public Equities mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		Equities obj = new Equities();		
		obj.setEqu_name(rs.getString("equ_name"));
		return obj;
	}
} 
