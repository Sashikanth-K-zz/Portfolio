package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.Login1;

public class LoginRowMapper1 implements RowMapper<Login1> {
	public Login1 mapRow(ResultSet rs, int rowNum) throws SQLException {
		Login1 obj = new Login1();		
		//obj.setId(rs.getInt("id"));
		//obj.setName(rs.getString("name"));
		obj.setUsrname(rs.getString("usrname"));
		//obj.setPasswd(rs.getString("passwd"));
		obj.setName(rs.getString("name"));
		//obj.setType(rs.getString("type"));
		return obj;
	}
}

