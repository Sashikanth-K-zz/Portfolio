package com.bku.inautix.broker.rowMapper;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.broker.bean.Losegain;







public class LosegainRowMapper implements RowMapper<Losegain> {
	public Losegain mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		Losegain obj = new Losegain();		
		obj.setEqu_symbl(rs.getString("equ_symbl"));
		obj.setDifference(rs.getFloat("difference"));
		return obj;
	}
}
