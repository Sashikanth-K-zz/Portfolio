package com.bku.inautix.admin.bean;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="bond")
public class BondServiceBean {
	private String cusip;
	private Float price;
	private String bond_symbl;
	private Float marketrate;
	private String bond_name;
	public String getCusip() {
		return cusip;
	}
	public void setCusip(String cusip) {
		this.cusip = cusip;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getBond_symbl() {
		return bond_symbl;
	}
	public void setBond_symbl(String bond_symbl) {
		this.bond_symbl = bond_symbl;
	}
	public Float getMarketrate() {
		return marketrate;
	}
	public void setMarketrate(Float marketrate) {
		this.marketrate = marketrate;
	}
	public String getBond_name() {
		return bond_name;
	}
	public void setBond_name(String bond_name) {
		this.bond_name = bond_name;
	}
	
	
	
	
	

}
