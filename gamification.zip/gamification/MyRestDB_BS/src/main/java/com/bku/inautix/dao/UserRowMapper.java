package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.User;

public class UserRowMapper implements RowMapper<User> {
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		User obj = new User();		
		obj.setId(rs.getString("id"));
		obj.setRank(rs.getInt("rank"));
		obj.setPortfoliovalue(rs.getFloat("portfoliovalue"));
		obj.setGlpercentage(rs.getDouble("glpercentage"));
		obj.setEquity(rs.getFloat("equity"));
		obj.setBond(rs.getFloat("bond"));
		obj.setMutualfund(rs.getFloat("mutualfund"));
		obj.setBalance(rs.getFloat("balance"));
		return obj;
	}
}
