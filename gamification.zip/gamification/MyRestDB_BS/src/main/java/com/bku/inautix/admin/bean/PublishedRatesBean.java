package com.bku.inautix.admin.bean;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="publishedbrokers")
public class PublishedRatesBean {
	public float getFutures() {
		return futures;
	}

	public void setFutures(float futures) {
		this.futures = futures;
	}

	public float getMf() {
		return mf;
	}

	public void setMf(float mf) {
		this.mf = mf;
	}

	public float getEquities() {
		return equities;
	}

	public void setEquities(float equities) {
		this.equities = equities;
	}

	public float getFx() {
		return fx;
	}

	public void setFx(float fx) {
		this.fx = fx;
	}

	public float getBonds() {
		return bonds;
	}

	public void setBonds(float bonds) {
		this.bonds = bonds;
	}

	public String getMfr() {
		return mfr;
	}

	public void setMfr(String mfr) {
		this.mfr = mfr;
	}

	public String getBroker_id() {
		return broker_id;
	}

	public void setBroker_id(String broker_id) {
		this.broker_id = broker_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

private float futures,mf,equities,fx,bonds;
String mfr;
String margin_fund_rate;
 
 public String getMargin_fund_rate() {
	return margin_fund_rate;
}

public void setMargin_fund_rate(String margin_fund_rate) {
	this.margin_fund_rate = margin_fund_rate;
}

private String broker_id,status,broker_name;
private String timestamp;

public String getTimestamp() {
	return timestamp;
}

public void setTimestamp(String timestamp) {
	this.timestamp = timestamp;
}

public String getBroker_name() {
	return broker_name;
}

public void setBroker_name(String broker_name) {
	this.broker_name = broker_name;
}
}
