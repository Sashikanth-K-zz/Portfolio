package com.bku.inautix.broker.bean;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="losegain")
 

public class Losegain {
	public Losegain()
	{
		
	}
	private String equ_symbl;
	private Float difference;
	
	public String getEqu_symbl() {
		return equ_symbl;
	}
	public void setEqu_symbl(String equ_symbl) {
		this.equ_symbl = equ_symbl;
	}
	public Float getDifference() {
		return difference;
	}
	public void setDifference(Float difference) {
		this.difference = difference;
	}
}
