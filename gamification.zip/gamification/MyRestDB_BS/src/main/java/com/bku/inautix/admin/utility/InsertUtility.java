package com.bku.inautix.admin.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bku.inautix.admin.bean.BondsBean;
import com.bku.inautix.admin.bean.EquitiesBean;
import com.bku.inautix.admin.bean.FXBean;
import com.bku.inautix.admin.bean.FuturesBean;
import com.bku.inautix.admin.bean.MFBean;
import com.bku.inautix.admin.bean.NewsBean;
import com.bku.inautix.broker.bean.AdviceBean;

 

	public class InsertUtility {
		
		static final int EQUITIES_SHEET_NUMBER=1;
		static final int BONDS_SHEET_NUMBER=2;
		static final int FX_SHEET_NUMBER=3;
		static final int MF_SHEET_NUMBER=4;
		static final int FUTURES_SHEET_NUMBER=5;
		static final int NEWS_SHEET_NUMBER=6;
		static final int ADVICE_SHEET_NUMBER=7;
		/* sheet numbers and corresponding reading functions soon to be introduced to deal with
		 * bonds,mutal funds,etc
		 */
		
		public static void insertEquities(ArrayList<EquitiesBean> equitiesBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(EQUITIES_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	  EquitiesBean equitiesBean=new EquitiesBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                 equitiesBean.setName(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  equitiesBean.setSymbol(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  cell.setCellType(Cell.CELL_TYPE_STRING);
	                  equitiesBean.setCusip(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  equitiesBean.setPrice(new Float(cell.getNumericCellValue()));
	                  cell = cellIterator.next();
	                  cell.setCellType(Cell.CELL_TYPE_STRING);
	                  equitiesBean.setBeta(Integer.parseInt(cell.getStringCellValue()));
	                  
	              
	              equitiesBeanList.add(equitiesBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				log.info(fnfe.getStackTrace());
			} catch (IOException ioe) {
				log.info(ioe.getStackTrace());
			}
			catch (Exception e) {
				log.info(e.getStackTrace());
			}
			
		}

		public static void insertBonds(ArrayList<BondsBean> bondsBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(BONDS_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	 BondsBean bondsBean=new BondsBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                 bondsBean.setName(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                 bondsBean.setSymbol(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  cell.setCellType(Cell.CELL_TYPE_STRING);
	                  bondsBean.setCusip(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  bondsBean.setPrice(new Float(cell.getNumericCellValue()));
	               
	              
	              bondsBeanList.add(bondsBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				
				log.info(fnfe.getStackTrace());
			} catch (IOException ioe) {
				log.info(ioe.getStackTrace());
				
			}
			catch (Exception e) {
				log.info(e.getStackTrace());
			
			}
			
		}
		public static void insertFX(ArrayList<FXBean> fxBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(FX_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	  FXBean fxBean=new FXBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                 fxBean.setName(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  fxBean.setSymbol(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  cell.setCellType(Cell.CELL_TYPE_STRING);
	                  fxBean.setCusip(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  fxBean.setPrice(new Float(cell.getNumericCellValue()));
	                
	              
	             fxBeanList.add(fxBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				log.info(fnfe.getStackTrace());
			} catch (IOException ioe) {
				log.info(ioe.getStackTrace());
			}
			catch (Exception e) {
				log.info(e.getStackTrace());
			}
			
		}
		public static void insertMF(ArrayList<MFBean> mfBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(MF_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	 MFBean mfBean=new MFBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                  mfBean.setName(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  mfBean.setSymbol(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  cell.setCellType(Cell.CELL_TYPE_STRING);
	                  mfBean.setCusip(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  mfBean.setPrice(new Float(cell.getNumericCellValue()));
	                 
	              
	              mfBeanList.add(mfBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				log.info(fnfe.getStackTrace());
			
			} catch (IOException ioe) {
				log.info(ioe.getStackTrace());
			
			}
			catch (Exception e) {
				
				log.info(e.getStackTrace());
			}
			
		}
		public static void insertFutures(ArrayList<FuturesBean> futuresBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(FUTURES_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	 FuturesBean futuresBean=new FuturesBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                 futuresBean.setName(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  futuresBean.setSymbol(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  cell.setCellType(Cell.CELL_TYPE_STRING);
	                  futuresBean.setCusip(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  futuresBean.setPrice(new Float(cell.getNumericCellValue()));
	                 
	              
	              futuresBeanList.add(futuresBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				log.info(fnfe.getStackTrace());
			} catch (IOException ioe) {
				log.info(ioe.getStackTrace());
			}
			catch (Exception e) {
				log.info(e.getStackTrace());
			}
			
		}

		
		public static void insertNews(ArrayList<NewsBean> newsBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(NEWS_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	 NewsBean newsBean=new NewsBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                  newsBean.setNews(cell.getStringCellValue());
	                
	              
	              newsBeanList.add(newsBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				log.info(fnfe.getStackTrace());
			} catch (IOException ioe) {
				log.info(ioe.getStackTrace());
			}
			catch (Exception e) {
				log.info(e.getStackTrace());
			}
			
			
		}

		public static void insertAdvice(ArrayList<AdviceBean> adviceBeanList, String excelFilePath,Logger log)
		{
			try
			{
			FileInputStream fileInputStream = new FileInputStream(excelFilePath);
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet worksheet = workbook.getSheetAt(ADVICE_SHEET_NUMBER-1);
			Iterator<Row> rowIterator = worksheet.iterator();
			//to skip the first row
			Row row = rowIterator.next();
	        while (rowIterator.hasNext())
	        {
	        	 AdviceBean adviceBean=new AdviceBean();
	              row = rowIterator.next();
	              Iterator<Cell> cellIterator = row.cellIterator();
	                                          	
	                  Cell cell = cellIterator.next();
	                  adviceBean.setAdvice(cell.getStringCellValue());
	                  cell = cellIterator.next();
	                  adviceBean.setId(new Integer((int) cell.getNumericCellValue()));
	            
	                  adviceBeanList.add(adviceBean);
			}
			}
			catch (FileNotFoundException fnfe) {
				log.info(fnfe.getStackTrace());
			} catch (IOException ioe) {
				log.info(ioe.getStackTrace());
			}
			catch (Exception e) {
				log.info(e.getStackTrace());
			}
			
		}
	}
