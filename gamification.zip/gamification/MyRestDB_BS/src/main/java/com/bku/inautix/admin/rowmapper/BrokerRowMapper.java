package com.bku.inautix.admin.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.admin.bean.BrokerDetailsBean;



public class BrokerRowMapper implements RowMapper<BrokerDetailsBean>
{
	public BrokerDetailsBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BrokerDetailsBean obj = new BrokerDetailsBean();
		obj.setBroker_id(rs.getString("broker_id"));
		obj.setBroker_name(rs.getString("broker_name"));
		obj.setFutures(rs.getFloat("futures_rate"));
		obj.setMf(rs.getFloat("mf_rate"));
		obj.setEquities(rs.getFloat("equities_rate"));
		obj.setFx(rs.getFloat("fx_rate"));
		obj.setBonds(rs.getFloat("bonds_rate"));
		obj.setFund_rate(rs.getString("margin_fund_rate"));
		obj.setFund_ratio(rs.getString("margin_fund_ratio"));
		obj.setStatus(rs.getString("status"));
		return obj;
	}

	
}
