package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.bku.inautix.model.EmployeeRow;

public class EmployeeRowMapper implements RowMapper<EmployeeRow> {
	public EmployeeRow mapRow(ResultSet rs, int rowNum) throws SQLException {
		EmployeeRow obj = new EmployeeRow();		
		obj.setName(rs.getString("equ_name"));
		obj.setPrice(rs.getFloat("price"));
		return obj;
	}
}