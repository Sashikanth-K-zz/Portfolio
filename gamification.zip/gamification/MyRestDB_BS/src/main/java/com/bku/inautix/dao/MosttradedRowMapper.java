package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.bku.inautix.model.Mosttraded;


public class MosttradedRowMapper implements RowMapper<Mosttraded>
{
	public Mosttraded mapRow(ResultSet rs, int rowNum) throws SQLException
	{
		Mosttraded obj= new Mosttraded();
		obj.setName(rs.getString("name"));
		obj.setCount(rs.getInt("count"));
		obj.setPrice(rs.getFloat("price"));
		
		
		return obj;
		
	}
}
