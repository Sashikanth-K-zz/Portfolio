package com.bku.inautix.admin.dao;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.model.ExcelFilePathBean;

public interface IMFDao {
	public void insertMF(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean);
}
