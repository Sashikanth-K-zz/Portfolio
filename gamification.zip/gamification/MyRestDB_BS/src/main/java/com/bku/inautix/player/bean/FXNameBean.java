package com.bku.inautix.player.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="fx")
public class FXNameBean {
	private String fx_name;

	public String getFx_name() {
		return fx_name;
	}

	public void setFx_name(String fx_name) {
		this.fx_name = fx_name;
	}

	public FXNameBean() {
		
	}

	public FXNameBean(String fx_name) {
		
		this.fx_name = fx_name;
	}


}
