package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.HoldingBean;

public class HoldingRowMapper implements RowMapper<HoldingBean> {
	public HoldingBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		HoldingBean obj = new HoldingBean();		
		obj.setName(rs.getString("name"));
		obj.setQuantity(rs.getInt("quantity"));
		obj.setPrice(rs.getFloat("price"));
		obj.setHolding(rs.getFloat("holding"));
		obj.setAmount_lg(rs.getFloat("amount_lg"));
		obj.setPercentage_lg(rs.getFloat("percentage_lg"));
		obj.setCurrent_holding(rs.getFloat("current_holding"));
		return obj;
	}
}
