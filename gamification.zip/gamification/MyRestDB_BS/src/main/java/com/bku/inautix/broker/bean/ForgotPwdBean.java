/**
 * DONE BY XBBLWC8 EMP ID : 13490
 */
package com.bku.inautix.broker.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="frgtpasswd")
public class ForgotPwdBean 
{
	private String password;
	private String email_id;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	

}
