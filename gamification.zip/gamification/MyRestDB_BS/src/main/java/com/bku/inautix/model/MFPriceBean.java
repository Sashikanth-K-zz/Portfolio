package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="mfp")
public class MFPriceBean {
	private String mf_name;
	public MFPriceBean() {
		
	}
	public MFPriceBean(String mf_name, float price) {
		
		this.mf_name = mf_name;
		this.price = price;
	}
	public String getMf_name() {
		return mf_name;
	}
	public void setMf_name(String mf_name) {
		this.mf_name = mf_name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	private float price;

}
