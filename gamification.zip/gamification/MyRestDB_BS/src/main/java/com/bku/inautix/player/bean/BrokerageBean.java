package com.bku.inautix.player.bean;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="brokeraging")
public class BrokerageBean {

	private String b_id;
	
	public float getFutures() {
		return futures;
	}
	public void setFutures(float futures) {
		this.futures = futures;
	}
	public float getBonds() {
		return bonds;
	}
	public void setBonds(float bonds) {
		this.bonds = bonds;
	}
	public float getMf() {
		return mf;
	}
	public void setMf(float mf) {
		this.mf = mf;
	}
	public float getFx() {
		return fx;
	}
	public void setFx(float fx) {
		this.fx = fx;
	}
	
	public String getB_id() {
		return b_id;
	}
	public void setB_id(String b_id) {
		this.b_id = b_id;
	}
	public String getMfr1() {
		return mfr1;
	}
	public void setMfr1(String mfr1) {
		this.mfr1 = mfr1;
	}
	public String getMfr2() {
		return mfr2;
	}
	public void setMfr2(String mfr2) {
		this.mfr2 = mfr2;
	}
	public float getEquities() {
		return equities;
	}
	public void setEquities(float equities) {
		this.equities = equities;
	}
	private float futures;
	private float bonds;
	private float mf;
	private float fx;
	private String mfr1;
	
	private String mfr2;
	private float equities;
	
	
	
}
