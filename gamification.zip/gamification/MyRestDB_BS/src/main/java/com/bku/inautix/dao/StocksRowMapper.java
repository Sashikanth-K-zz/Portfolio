package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.Stocks;

public class StocksRowMapper  implements RowMapper<Stocks> 
{
	public Stocks mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		Stocks obj = new Stocks();		
		obj.setStk_name(rs.getString("stk_name"));
		return obj;
	}
} 
