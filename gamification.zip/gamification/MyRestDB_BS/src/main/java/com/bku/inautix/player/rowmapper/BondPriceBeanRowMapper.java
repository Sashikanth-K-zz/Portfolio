package com.bku.inautix.player.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.BondPriceBean;

public class BondPriceBeanRowMapper implements RowMapper<BondPriceBean> {
public BondPriceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BondPriceBean obj = new BondPriceBean();		
	
		obj.setBond_name(rs.getString(1));
		obj.setBond_price(rs.getFloat(2));
		return obj;
}
}
