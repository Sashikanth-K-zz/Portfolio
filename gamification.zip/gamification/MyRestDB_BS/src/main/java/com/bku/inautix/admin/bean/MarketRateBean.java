package com.bku.inautix.admin.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="marketrate")
public class MarketRateBean {
	
	private Float market_rate;

	public Float getMarket_rate() {
		return market_rate;
	}

	public void setMarket_rate(Float market_rate) {
		this.market_rate = market_rate;
	}

	
}