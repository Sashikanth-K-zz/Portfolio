package com.bku.inautix.admin.dao.impl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.FXBean;
import com.bku.inautix.admin.dao.IFXDao;
import com.bku.inautix.admin.utility.InsertUtility;
import com.bku.inautix.model.ExcelFilePathBean;

public class FXDao implements IFXDao{

	public void  insertFX(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean)
	{
		log.info("\nEntered insertfx service");
			ArrayList<FXBean> fxBeanList = new ArrayList<FXBean>();
			InsertUtility.insertFX(fxBeanList,excelFilePathBean.getExcelFilePath(),log);

			

			
				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
						 Types.FLOAT, Types.DATE };
				jdbcTemplate.update("delete from fx");
				for (FXBean fxBean : fxBeanList) {

					 jdbcTemplate.update(
							"insert into fx values(?,?,?,?)", new Object[] {
									fxBean.getName(), fxBean.getSymbol(),
									 fxBean.getPrice(),
									new Date() }, types);
					log.info("\nInserted fx values");
				}

			

			
			log.info("\nReturning after inserting fx");
		
			
			
		}
		

}
