package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;


import com.bku.inautix.model.Dashboard;




public class DashboardRowMapper implements RowMapper<Dashboard> {
	public Dashboard mapRow(ResultSet rs, int rowNum) throws SQLException {
		Dashboard obj = new Dashboard();		
		obj.setUserid(rs.getString(1));
		obj.setTotalValue(rs.getFloat(2));
		return obj;
	}

}
