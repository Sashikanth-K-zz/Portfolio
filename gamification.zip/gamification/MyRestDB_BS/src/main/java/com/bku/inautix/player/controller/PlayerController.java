package com.bku.inautix.player.controller;

import java.sql.Types;
import java.util.Date;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bku.inautix.dao.EquityRowMapper;
import com.bku.inautix.dao.LoginRowMapper;
import com.bku.inautix.dao.TransactionRowMapper;
import com.bku.inautix.model.EquityBean;
import com.bku.inautix.model.Login;
import com.bku.inautix.model.Transaction;
import com.bku.inautix.player.bean.BrokerageBean;
import com.bku.inautix.player.bean.SavingBean;
import com.bku.inautix.dao.BondRowMapper;
import com.bku.inautix.dao.FXNameRowMapper;
import com.bku.inautix.dao.FXRowMapper;
import com.bku.inautix.dao.StocksRowMapper;
import com.bku.inautix.model.BondServiceBean;
import com.bku.inautix.model.Bonds;
import com.bku.inautix.model.FXNameBean;
import com.bku.inautix.model.FXServiceBean;
import com.bku.inautix.model.MFNameBean;
import com.bku.inautix.model.MFServiceBean;
import com.bku.inautix.model.Stocks;
import com.bku.inautix.player.dao.impl.PlayerDAO;
import com.bku.inautix.player.rowmapper.BondsRowMapper;
import com.bku.inautix.player.rowmapper.MFNameRowMapper;





@Service("PlayerBean")
@Path("player")
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON)  

public class PlayerController {
	
	private DataSource dataSourcePlayer;
	private JdbcTemplate jdbcTemplate;
	private PlayerDAO obj=new PlayerDAO();
	public DataSource getDataSourcePlayer() {
		return dataSourcePlayer;
	}

	public void setDataSourcePlayer(DataSource dataSourcePlayer) {
		this.dataSourcePlayer =dataSourcePlayer;
		jdbcTemplate = new JdbcTemplate(dataSourcePlayer);
	}
	
private static Logger log;
	
	
	public PlayerController()
	{
	log = Logger.getLogger(PlayerController.class.getName());
	}
	
	
/*new code to load other tables*******************************************************************************/
	
	
	@GET
	 @Path("insertbond") 
// @Consumes(MediaType.APPLICATION_JSON)
	 @Produces(MediaType.TEXT_HTML)
	public String insertbonds() {
		String sam=obj.insertbond(dataSourcePlayer);
		return sam;
	 }
	
	
	
/**************************************************************************************************************/
	
	
	
	
	

	

	@GET
	 @Path("insertmf") 
//@Consumes(MediaType.APPLICATION_JSON)
	// @Produces(MediaType.APPLICATION_JSON)
	public String insertmf() {
		 String sam=obj.insertmf(dataSourcePlayer);
		 return sam;
	}	
	
	
	
	/**************************************************************************************************************/
	
	
	@GET
	 @Path("insertfx") 
//@Consumes(MediaType.APPLICATION_JSON)
	// @Produces(MediaType.APPLICATION_JSON)
	public String insertfx() {
		
		
		String sam=obj.insertfx(dataSourcePlayer);
		return sam;
		
	 }	
	
	/**************************************************************************************************************/
	
	
		 
	@GET
	@Path("MF") 
  @Produces(MediaType.APPLICATION_JSON)
	public List<MFServiceBean> getMFS() {
		List<MFServiceBean> list=obj.getMFS(jdbcTemplate);
				return list;
	 }	
	
	
	/**************************************************************************************************************/
	
	
	
	@GET
	@Path("FX") 
  @Produces(MediaType.APPLICATION_JSON)
	public List<FXServiceBean> getFX() {
		
		List<FXServiceBean> list=obj.getFX(jdbcTemplate);
		return list;
		
	 }	
	
	/**************************************************************************************************************/
	
	
	
	@GET
	@Path("Bond") 
  @Produces(MediaType.APPLICATION_JSON)
	public List<BondServiceBean> getBond() {
		List<BondServiceBean> list= obj.getBond(jdbcTemplate);
		return list;
	 }	
	

	/**************************************************************************************************************/
	@POST
    @Path("/uploadbonds")
    @Produces(MediaType.TEXT_HTML)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public String uploadFileBond(
     @Multipart("fileUploadBonds") Attachment attachment) throws IOException {
	   
	  String sam=obj.uploadFileBond(attachment);
	  return sam;
    }  
	

	/**************************************************************************************************************/
	
	/*get bond name*/

	/*upload fx*/

	 
	 
	@POST
    @Path("/uploadFX")
    @Produces(MediaType.TEXT_HTML)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public String uploadFileFX(
     @Multipart("fileUploadFX") Attachment attachment) throws IOException {
	   
		
		String sam=obj.uploadFileFX(attachment);
		return sam;
	   
    }  
	
	
	/**************************************************************************************************************/
	/*get mf */
	
	@POST
    @Path("/uploadMF")
    @Produces(MediaType.TEXT_HTML)
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public String uploadFileMF(
     @Multipart("fileUploadMF") Attachment attachment) throws IOException {
	   
	  String sam=obj.uploadFileMF(attachment);
	  return sam;
    }  
	
	/**************************************************************************************************************/
	@GET
	@Path("MFName") 
	@Produces(MediaType.APPLICATION_JSON)
	public List<MFNameBean> getMFName()
	{
		List<MFNameBean> list=obj.getMFName(jdbcTemplate);
		return list;
	}
	/**************************************************************************************************************/
	@GET
	@Path("FXName") 
	@Produces(MediaType.APPLICATION_JSON)
	public List<FXNameBean> getFXName()
	{
		List<FXNameBean> list=obj.getFXName(jdbcTemplate);
		return list;
	}
	 
	/**************************************************************************************************************/
	@GET
	@Path("bondsName") 
	@Produces(MediaType.APPLICATION_JSON)
	public List<Bonds> getBondsName()
	{
		List<Bonds> list=obj.getBondsName(jdbcTemplate);
		return list;
	}
	 
		
	/**************************************************************************************************************/
	/*end of get bond name*/
	@GET
	@Path("stocksName") 
	@Produces(MediaType.APPLICATION_JSON)
	public List<Stocks> getStocksName()
	{
		List <Stocks> list=obj.getStocksName(jdbcTemplate);
		return list;
	}
		
	/**************************************************************************************************************/
	
//***EMP_ID = 13495***
//***********************SELECT BROKER DETAILS BY EMP_ID = 13495*********************
				 @GET
					@Path("brokeraging/{bid}") 
				    @Produces(MediaType.APPLICATION_JSON)
					public List<BrokerageBean> getBrokerageValues(@PathParam("bid") int bid)
					{
					 List<BrokerageBean> list =obj.getBrokerageValues(bid, jdbcTemplate);
					 return list;
					}	
				 
				 
	//EMP ID = 13487			 
	 //**************************************** Saving Broker, EMP ID = 13487 **************************************//

	 @GET
    @Path("savebroker/{uid}/{bid}/{getDatetime}") 
    @Produces(MediaType.APPLICATION_JSON)
    public List<SavingBean> getSavingValues(@PathParam("bid") String bid,@PathParam("uid") String uid,@PathParam("getDatetime") String getDatetime) {
          
          List<SavingBean> list = obj.getSavingValues(bid,uid,getDatetime,jdbcTemplate);
          return list;
    }  
	 
		//EMP ID = 14707			 
	 //**************************************** Saving Broker, EMP ID = 13487 **************************************//

	 @GET
    @Path("savedbroker/{uid}/{bid}/{getDatetime}") 
    @Produces(MediaType.APPLICATION_JSON)
    public List<SavingBean> getSavedValues(@PathParam("bid") String bid,@PathParam("uid") String uid,@PathParam("getDatetime") String getDatetime) {
          
          List<SavingBean> list = obj.getSavedValues(bid,uid,getDatetime,jdbcTemplate);
          return list;
    }  
	 
	 
	 //EMP ID = 13481
 //**************************************** Buying and Selling Equities, EMP ID = 13481 **************************************//

	 
	 @GET
		@Path("equitysell/{name}/{price}/{getDatetime}/{quantity}/{uid}/{security_type}/{equities}")
		@Produces(MediaType.APPLICATION_JSON)
		public List<Transaction> sellEquity(@PathParam("name") String name,
				@PathParam("price") Float price,
				@PathParam("getDatetime") Date getDatetime,
				@PathParam("quantity") Integer quantity,
				@PathParam("uid") String uid,
				@PathParam("security_type") String security_type,
				@PathParam("equities") String equities) {
		 
		 
		 List<Transaction> list = obj.sellEquity(name,price,getDatetime,quantity,uid,security_type,equities,jdbcTemplate);
					
			return list;
		}
		
	 //EMP ID = 13481
	//**************************************** Buying and Selling Equities, EMP ID = 13481 **************************************//
	@GET
			@Path("equity/{name}/{price}/{getDatetime}/{quantity}/{uid}/{security_type}/{equities}")
			@Produces(MediaType.APPLICATION_JSON)
			public List<Transaction> getEquity(@PathParam("name") String name,
					@PathParam("price") Float price,
					@PathParam("getDatetime") Date getDatetime,
					@PathParam("quantity") Integer quantity,
					@PathParam("uid") String uid,
					@PathParam("security_type") String security_type,
					@PathParam("equities") String equties) {
				List<Transaction> list = obj.getEquity(name, price, getDatetime, quantity, uid, security_type, equties, jdbcTemplate);
				
				return list;
			}

}
