package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="bonds")
public class Bonds {
	public Bonds()
	{
		
	}
	public Bonds(String bond_name)
	{
		this.bond_name=bond_name;
	}
	private String bond_name;
	public String getBond_name() {
		return bond_name;
	}
	public void setBond_name(String bond_name) {
		this.bond_name = bond_name;
	}
	
}
