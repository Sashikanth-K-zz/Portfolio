package com.bku.inautix.admin.dao.impl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.BondsBean;
import com.bku.inautix.admin.dao.IBondsDao;
import com.bku.inautix.admin.utility.InsertUtility;
import com.bku.inautix.model.ExcelFilePathBean;

public class BondsDao implements IBondsDao{

	public void  insertBonds(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean)
	{
		log.info("\nEntered insertbonds service");
			ArrayList<BondsBean> bondsBeanList = new ArrayList<BondsBean>();
			InsertUtility.insertBonds(bondsBeanList,excelFilePathBean.getExcelFilePath(),log);

			

	
				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
						Types.VARCHAR, Types.FLOAT, Types.DATE };
				jdbcTemplate.update("delete from bonds");
				for (BondsBean bondsBean : bondsBeanList) {
					System.out.println("entered");
					 jdbcTemplate.update(
							"insert into bonds (bond_name,bond_symbl,cusip,price,date) values(?,?,?,?,?)", new Object[] {
									bondsBean.getName(), bondsBean.getSymbol(),
									bondsBean.getCusip(), bondsBean.getPrice(),
									new Date() }, types);
					log.info("\nInserted bonds values");
				}

			
				System.out.println("here");
			
			log.info("\nReturning after inserting bonds");
		
			
			
		}
}
