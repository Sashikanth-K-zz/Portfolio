package com.bku.inautix.admin.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bku.inautix.admin.bean.ApprovalBean;
import com.bku.inautix.admin.bean.ApprovedBrokerBean;
import com.bku.inautix.admin.bean.BondServiceBean;
import com.bku.inautix.admin.bean.BrokerDetailsBean;
import com.bku.inautix.admin.bean.CheckBean;
import com.bku.inautix.admin.bean.PublishedRatesBean;
import com.bku.inautix.admin.bean.RejectedBrokerBean;
import com.bku.inautix.admin.dao.impl.BrokerDAO;
import com.bku.inautix.model.Dashboard;
import com.bku.inautix.model.ExcelFilePathBean;
import com.bku.inautix.model.IpAddressBean;
import com.bku.inautix.service.MyService;
import com.bku.inautix.admin.dao.impl.BondsDao;
import com.bku.inautix.admin.dao.impl.EquitiesDao;
import com.bku.inautix.admin.dao.impl.FXDao;
import com.bku.inautix.admin.dao.impl.FuturesDao;
import com.bku.inautix.admin.dao.impl.MFDao;
import com.bku.inautix.admin.dao.impl.NewsDao;
import com.bku.inautix.dao.DashboardRowMapper;

@Service("AdminServiceBean")
@Path("adminservice")

@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON)  

public class AdminService {
	
	
	private BrokerDAO obj=new BrokerDAO();
	@Autowired
	private ExcelFilePathBean excelFilePathBean;
	@Autowired
	private IpAddressBean ipAddress;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private final int UPLOADED_NOW=1;
	private final int NOT_UPLOADED_NOW=0;
	private CheckBean checkBean =new CheckBean(NOT_UPLOADED_NOW);
	
	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this
		.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private static Logger log;

	

	public AdminService() {
		log = Logger.getLogger(AdminService.class.getName());
	}
	
	
	
	//***************************Sundaresan S---13469****************************
	 @GET
		@Path("admin/view/brokerdetails") 
	   @Produces(MediaType.APPLICATION_JSON)
		public List<BrokerDetailsBean> getBrokerDetails() {
		 List<BrokerDetailsBean> list = obj.getBrokerDetails(jdbcTemplate);
		 return list;
				 }	
	
	
	//***************************Senkathir Selvi---13472****************************
	 @GET
		@Path("admin/rates/approvebroker/{broker_name}") 
	   @Produces(MediaType.APPLICATION_JSON)
		
	 public void approveBroker(@PathParam("broker_name") String brname)
  {
         
		obj.approveBroker(brname,jdbcTemplate);
		 return;
		 }	
	
	
	//***************************Sathish Kumar M---13477****************************

	 @GET
		@Path("admin/rates/publishbroker/{broker_name}") 
	   @Produces(MediaType.APPLICATION_JSON)
		
	 public void publishBroker(@PathParam("broker_name") String brname)
  {
		 
		 obj.publishBroker(brname,jdbcTemplate);
		 return ;
		 }	
	
	//***************************Logesh DuraiSwamy---13482****************************
	 
	 @GET
		@Path("admin/rates/rejectbroker/{broker_name}") 
	   @Produces(MediaType.APPLICATION_JSON)
		
	 public void rejectBroker(@PathParam("broker_name") String brname)
{
      
		obj.rejectBroker(brname,jdbcTemplate);
		return;
		 }	
	 
	 
	 
	//***************************Geeta Sneka---13475****************************
  @GET
@Path("admin/view/rejectedrates") 
@Produces(MediaType.APPLICATION_JSON)
  public List<RejectedBrokerBean> getBrokerRejected() {
 	 
	  List<RejectedBrokerBean> list =obj.getBrokerRejected(jdbcTemplate);
	  return list;
}	
	
 

//***************************Bala Vignesh---13476****************************
  @GET
	 @Path("admin/view/approvalrates") 
 @Produces(MediaType.APPLICATION_JSON)
	 public List<ApprovalBean> getBrokerforApproval()
	 {
	  List<ApprovalBean> list = obj.getApprovalBroker(jdbcTemplate);
	  return list;
		     }
  
//***************************Sathish Kumar---13477****************************
  @GET
	 @Path("admin/view/approvedrates") 
 @Produces(MediaType.APPLICATION_JSON)
	 public List<ApprovedBrokerBean> getBrokerApproved()
	 {
	  List<ApprovedBrokerBean> list = obj.getApprovedBroker(jdbcTemplate);
	  return list;
		    	 }

  
//***************************Srividhya K---13471****************************
	 @GET
	  @Path("admin/view/publishedrates") 
	@Produces(MediaType.APPLICATION_JSON)
	  public List<PublishedRatesBean> getPublishedRates()
	  {
		  List<PublishedRatesBean> list= obj.getPublishedRates(jdbcTemplate);
		  return list;
	           }

  	//Abishek
	// **********************make as admin**************************
	@GET
	@Path("makeAdmin/{userid}")
	@Produces(MediaType.TEXT_HTML)
	public String makeAdmin(@PathParam("userid") String userid) {
		
		String maStatus=obj.makeAdmin(userid,jdbcTemplate);
		return maStatus;
		

	}
	
	//Abishek
	// **********************remove users**************************
	@GET
	@Path("removeUsers/{userid}")
	@Produces(MediaType.TEXT_HTML)
	public String removeUser(@PathParam("userid") String userid) {
		
	String ruStatus=obj.removeUser(userid, jdbcTemplate);
	return ruStatus;

	}
	
	//Abishek
	// **********************make as user**************************
	@GET
	@Path("makeUsers/{userid}")
	@Produces(MediaType.TEXT_HTML)
	public String makeUser(@PathParam("userid") String userid) {
		
	String muStatus=obj.makeUser(userid, jdbcTemplate);
	return muStatus;

	}
//************************sangavi--Change bondInterest*****************************************
	@GET
	 @Path("changeInterest/{market_rate}") 
	 @Produces(MediaType.TEXT_HTML)
	 public String changeInterest(@PathParam("market_rate") float market_rate){
		 String rt_obj = obj.changeInterest(market_rate, jdbcTemplate);
		 return rt_obj;
		 
	}

	
	//********************sangavi--View bond*********************************************************
	@GET
	@Path("bond/{getDatetime}") 
   @Produces(MediaType.APPLICATION_JSON)
	public List<BondServiceBean> getBond(@PathParam("datetime") Date datetime) {
		List<BondServiceBean> list= obj.getBond(datetime, jdbcTemplate);
	
		return list;
	 }
	//13484 - Gokul && 13470 - Vasumathy
	//*****************************************Upload Equities Service*****************************************************
		@POST
		@Path("/upload")
		@Produces(MediaType.TEXT_HTML)
		@Consumes(MediaType.MULTIPART_FORM_DATA)
		public String uploadEquities(@Multipart("fileUploadEquities") Attachment attachment)
				throws IOException {

			try {

				EquitiesDao edao=new EquitiesDao();
				BondsDao bdao=new BondsDao();
				FXDao fdao=new FXDao();
				MFDao mdao=new MFDao();
				NewsDao ndao=new NewsDao();

				String ofilename = attachment.getContentDisposition().getParameter(
						"filename");
			//	String filename = "Pricing.xlsx";
				if (ofilename.contains(".xlsx") || ofilename.contains(".xls")) {
					
				java.nio.file.Path path = Paths.get(excelFilePathBean.getExcelFilePath());
					
					Files.deleteIfExists(path);
					
					InputStream in = attachment.getObject(InputStream.class);
				
					Files.copy(in, path);
				
					
				} else {
					return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
				}
				edao.insertEquities(jdbcTemplate,log,excelFilePathBean);
				bdao.insertBonds(jdbcTemplate, log, excelFilePathBean);
				mdao.insertMF(jdbcTemplate, log, excelFilePathBean);
				fdao.insertFX(jdbcTemplate, log, excelFilePathBean);
				ndao.insertNews(jdbcTemplate, log, excelFilePathBean);
				//MyService s = new MyService();
				//s.getAutoupdate();
				checkBean.setFlag(UPLOADED_NOW);
				return "<html><script>var r = alert(\"File Data inserted\");window.location.replace(\"http://"
				+ ipAddress.getIpAddress()
				+ "/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (DuplicateKeyException dke) {
				log.info(dke.getStackTrace());
				return "<html><script>alert(\"Update for the day is done\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			
			catch (IOException ioe) {
				log.info(ioe.getStackTrace());
				return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (Exception e) {

				log.info(e.getStackTrace());
				return "<html><script>alert(\"Error Inserting\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
		}
		//********************************************************Auto Update*********************************************************//
		 @GET
		 @Path("auto_update/{date}") 
	     @Produces(MediaType.APPLICATION_JSON)
		 public void getAutoupdate()
		 {

			try 
			{
				jdbcTemplate.update("update holding set holding.price=(select equities.price from equities where holding.name=equities.equ_name) where security_name='Equity'", new Object[]{}); 
				jdbcTemplate.update("update holding set holding.amount_lg=(select equities.price*holding.quantity-holding.holding from equities where holding.name=equities.equ_name) where security_name='Equity'", new Object[]{});
				jdbcTemplate.update("update holding set holding.percentage_lg=(select ((equities.price*holding.quantity-holding.holding)/(holding.holding))*100 from equities where holding.name=equities.equ_name) where security_name='Equity'", new Object[]{});
				jdbcTemplate.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name ) where security_name='Equity'",new Object[]{});
				jdbcTemplate.update("update holding set holding.price=(select bonds.price from bonds where holding.name=bonds.bond_name) where security_name='Bonds'", new Object[]{}); 
				jdbcTemplate.update("update holding set holding.amount_lg=(select bonds.price*holding.quantity-holding.holding from bonds where holding.name=bonds.bond_name) where security_name='Bonds'", new Object[]{});
				jdbcTemplate.update("update holding set holding.percentage_lg=(select ((bonds.price*holding.quantity-holding.holding)/(holding.holding))*100 from bonds where holding.name=bonds.bond_name) where security_name='Bonds'", new Object[]{});
				jdbcTemplate.update("update holding set holding.current_holding=(select bonds.price*holding.quantity from bonds where holding.name=bonds.bond_name ) where security_name='Bonds'",new Object[]{});
				jdbcTemplate.update("update holding set holding.price=(select mf.price from mf where holding.name=mf.mf_name) where security_name='MF'", new Object[]{}); 
				jdbcTemplate.update("update holding set holding.amount_lg=(select mf.price*holding.quantity-holding.holding from mf where holding.name=mf.mf_name) where security_name='MF'", new Object[]{});
				jdbcTemplate.update("update holding set holding.percentage_lg=(select ((mf.price*holding.quantity-holding.holding)/(holding.holding))*100 from mf where holding.name=mf.mf_name) where security_name='MF'", new Object[]{});
				jdbcTemplate.update("update holding set holding.current_holding=(select mf.price*holding.quantity from mf where holding.name=mf.mf_name ) where security_name='MF'",new Object[]{});
				jdbcTemplate.update("update holding set holding.price=(select fx.price from fx where holding.name=fx.fx_name) where security_name='FX'", new Object[]{}); 
				jdbcTemplate.update("update holding set holding.amount_lg=(select fx.price*holding.quantity-holding.holding from fx where holding.name=fx.fx_name) where security_name='FX'", new Object[]{});
				jdbcTemplate.update("update holding set holding.percentage_lg=(select ((fx.price*holding.quantity-holding.holding)/(holding.holding))*100 from fx where holding.name=fx.fx_name) where security_name='FX'", new Object[]{});
				jdbcTemplate.update("update holding set holding.current_holding=(select fx.price*holding.quantity from fx where holding.name=fx.fx_name ) where security_name='FX'",new Object[]{});
				jdbcTemplate.update("update user_screen set user_screen.glpercentage=(select CAST(avg(holding.percentage_lg) + 0.005 AS DECIMAL(15,2)) from holding where user_screen.id=holding.uid)", new Object[]{});
				jdbcTemplate.update("update user_screen set user_screen.portfoliovalue=(select sum(holding.current_holding) from holding where user_screen.id=holding.uid)",new Object[]{});
				int rank=1;
				int[] types= new int[] {Types.INTEGER,Types.VARCHAR};
				List<Dashboard> list = null;
					list = jdbcTemplate.query(
							"select id,balance+portfoliovalue total_value from user_screen where portfoliovalue is not null order by total_value desc",
				        new Object[]{}, //in parameter
				        new DashboardRowMapper());
					/*jdbcTemplate.execute("create table rank_table (uid varchar(25),rank integer)");*/
					for(int i=0;i<list.size();i++)
					{
						String x=list.get(i).getUserid();
						jdbcTemplate.update("update user_screen set rank=? where id=?",new Object[]{rank,x},types);
						rank++;
					}
			
			} 
			
			catch (Throwable fault) 
			{
				System.out.println("Got error.  Returning null (404)");
				fault.printStackTrace();
				
			}
			//if we return null here, it sends back a 404.  Good.
		
		 }
		//13484  - Gokul
		//*****************************************Upload Bonds Service*****************************************************
		@POST
		@Path("/uploadbonds")
		@Produces(MediaType.TEXT_HTML)
		@Consumes(MediaType.MULTIPART_FORM_DATA)
		public String uploadBonds(@Multipart("fileUploadBonds") Attachment attachment)
				throws IOException {

			try {

				BondsDao bdao=new BondsDao();

				String ofilename = attachment.getContentDisposition().getParameter("filename");
			//	String filename = "Pricing.xlsx";
				if (ofilename.contains(".xlsx") || ofilename.contains(".xls")) {
					
				java.nio.file.Path path = Paths.get(excelFilePathBean.getExcelFilePath());
					
					Files.deleteIfExists(path);
					
					InputStream in = attachment.getObject(InputStream.class);
				
					Files.copy(in, path);
				
					
				} else {
					return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
				}
				bdao.insertBonds(jdbcTemplate,log,excelFilePathBean);
				checkBean.setFlag(UPLOADED_NOW);
				return "<html><script>alert(\"Bonds inserted\");window.location.replace(\"http://"
				+ ipAddress.getIpAddress()
				+ "/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (DuplicateKeyException dke) {
				log.info(dke.getStackTrace());
				return "<html><script>alert(\"Update for the day is done\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			
			catch (IOException ioe) {
				log.info(ioe.getStackTrace());
				return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (Exception e) {

				log.info(e.getStackTrace());
				return "<html><script>alert(\"Error Inserting\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
		}
		//13484 - Gokul
		//*****************************************Upload FX Service*****************************************************
		@POST
		@Path("/uploadfx")
		@Produces(MediaType.TEXT_HTML)
		@Consumes(MediaType.MULTIPART_FORM_DATA)
		public String uploadFX(@Multipart("fileUploadFX") Attachment attachment)
				throws IOException {

			try {

				FXDao fdao=new FXDao();

				String ofilename = attachment.getContentDisposition().getParameter(
						"filename");
			//	String filename = "Pricing.xlsx";
				if (ofilename.contains(".xlsx") || ofilename.contains(".xls")) {
					
				java.nio.file.Path path = Paths.get(excelFilePathBean.getExcelFilePath());
					
					Files.deleteIfExists(path);
					
					InputStream in = attachment.getObject(InputStream.class);
				
					Files.copy(in, path);
				
					
				} else {
					return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
				}
				fdao.insertFX(jdbcTemplate,log,excelFilePathBean);
				checkBean.setFlag(UPLOADED_NOW);
				return "<html><script>alert(\"FX rates inserted\");window.location.replace(\"http://"
				+ ipAddress.getIpAddress()
				+ "/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (DuplicateKeyException dke) {
				log.info(dke.getStackTrace());
				return "<html><script>alert(\"Update for the day is done\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			
			catch (IOException ioe) {
				log.info(ioe.getStackTrace());
				
				return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (Exception e) {

				log.info(e.getStackTrace());
				
				return "<html><script>alert(\"Error Inserting\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
		}
		//13484 - Gokul
		//*****************************************Upload MF Service*****************************************************
		@POST
		@Path("/uploadmf")
		@Produces(MediaType.TEXT_HTML)
		@Consumes(MediaType.MULTIPART_FORM_DATA)
		public String uploadMF(@Multipart("fileUploadMF") Attachment attachment)
				throws IOException {

			try {

				MFDao mdao=new MFDao();

				String ofilename = attachment.getContentDisposition().getParameter(
						"filename");
			//	String filename = "Pricing.xlsx";
				if (ofilename.contains(".xlsx") || ofilename.contains(".xls")) {
					
				java.nio.file.Path path = Paths.get(excelFilePathBean.getExcelFilePath());
					
					Files.deleteIfExists(path);
					
					InputStream in = attachment.getObject(InputStream.class);
				
					Files.copy(in, path);
				
					
				} else {
					return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
				}
				mdao.insertMF(jdbcTemplate,log,excelFilePathBean);
				checkBean.setFlag(UPLOADED_NOW);
				return "<html><script>alert(\"MF data inserted\");window.location.replace(\"http://"
				+ ipAddress.getIpAddress()
				+ "/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (DuplicateKeyException dke) {
				log.info(dke.getStackTrace());
				return "<html><script>alert(\"Update for the day is done\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			
			catch (IOException ioe) {
				log.info(ioe.getStackTrace());
				return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (Exception e) {

				log.info(e.getStackTrace());
				return "<html><script>alert(\"Error Inserting\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
		}
		
		//13484 - Gokul
		//*****************************************Upload Futures Service*****************************************************
		@POST
		@Path("/uploadfutures")
		@Produces(MediaType.TEXT_HTML)
		@Consumes(MediaType.MULTIPART_FORM_DATA)
		public String uploadFile(@Multipart("fileUploadFutures") Attachment attachment)
				throws IOException {

			try {

				FuturesDao fudao=new FuturesDao();

				String ofilename = attachment.getContentDisposition().getParameter(
						"filename");
			//	String filename = "Pricing.xlsx";
				if (ofilename.contains(".xlsx") || ofilename.contains(".xls")) {
					
				java.nio.file.Path path = Paths.get(excelFilePathBean.getExcelFilePath());
					
					Files.deleteIfExists(path);
					
					InputStream in = attachment.getObject(InputStream.class);
				
					Files.copy(in, path);
				
					
				} else {
					return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
				}
				fudao.insertFutures(jdbcTemplate,log,excelFilePathBean);
				checkBean.setFlag(UPLOADED_NOW);
				return "<html><script>alert(\"Futures inserted\");window.location.replace(\"http://"
				+ ipAddress.getIpAddress()
				+ "/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (DuplicateKeyException dke) {
				log.info(dke.getStackTrace());
				return "<html><script>alert(\"Update for the day is done\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			
			catch (IOException ioe) {
				log.info(ioe.getStackTrace());
				return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (Exception e) {

				log.info(e.getStackTrace());
				return "<html><script>alert(\"Error Inserting\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
		}
		
		
		//13484 - Gokul
		// *********************************upload news service****************************************
		@POST
		@Path("/uploadnews")
		@Produces(MediaType.TEXT_HTML)
		@Consumes(MediaType.MULTIPART_FORM_DATA)
		public String uploadFileNews(
				@Multipart("fileUploadNews") Attachment attachment)
				throws IOException {
			
			try {
				NewsDao ndao= new NewsDao();
				String ofilename = attachment.getContentDisposition().getParameter("filename");
				if (ofilename.contains(".xlsx") || ofilename.contains(".xls")) {
								
					java.nio.file.Path path = Paths	.get(excelFilePathBean.getExcelFilePath());
					Files.deleteIfExists(path);
					InputStream in = attachment.getObject(InputStream.class);
					Files.copy(in, path);
				
				 
					
				} else {
					return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
				}
				ndao.insertNews(jdbcTemplate,log,excelFilePathBean);
				checkBean.setFlag(UPLOADED_NOW);
				log.info("\nReturning after inserting news");
				return "<html><script>alert(\"News Inserted!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\")</script></html>";
			

		} catch (DuplicateKeyException e) {
			log.info(e.getStackTrace());
			return "<html><script>alert(\"Update for the day is done!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\")</script></html>";
		}

	catch(IOException ioe)
			{
		
		return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\");</script></html>";
			}
			catch (Exception e) {
				log.info(e.getStackTrace());
				return "<html><script>alert(\"Error inserting\");window.location.replace(\"http://"+ ipAddress.getIpAddress()+"/PortfolioGame/admin.jsp\")</script></html>";
				
			}
		}
		//13484 - Gokul
		//******************************Check to decide whether to show upload section  or view section****************
			
			@GET
			@Path("check")
			@Produces(MediaType.APPLICATION_JSON)
			public CheckBean check()
			{
				int flag=checkBean.getFlag();
				if(flag==1)
				{
					checkBean.setFlag(NOT_UPLOADED_NOW);
					checkBean.setCheck(UPLOADED_NOW);
				}
				else if(flag==NOT_UPLOADED_NOW)
				{
					checkBean.setCheck(NOT_UPLOADED_NOW);
					
				}
				return checkBean;
					
			}
			
	
}
