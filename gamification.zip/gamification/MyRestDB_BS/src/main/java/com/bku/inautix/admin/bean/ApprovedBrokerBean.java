package com.bku.inautix.admin.bean;

import java.sql.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="approvedbrokers")

public class ApprovedBrokerBean {
	
	public ApprovedBrokerBean(){}
	
	private String broker_id;
	private String broker_name;
	private float futures;
	private float mf;
	private float equities;
	private float fx;
	private float bonds;
	private String fund_rate;
	private String fund_ratio;
	private String timestamp;
	private String status;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getBroker_name() {
		return broker_name;
	}
	public void setBroker_name(String broker_name) {
		this.broker_name = broker_name;
	}
	
	public String getBroker_id() {
		return broker_id;
	}
	public void setBroker_id(String broker_id) {
		this.broker_id = broker_id;
	}
	public float getFutures() {
		return futures;
	}
	public void setFutures(float futures) {
		this.futures = futures;
	}
	public float getMf() {
		return mf;
	}
	public void setMf(float mf) {
		this.mf = mf;
	}
	public float getEquities() {
		return equities;
	}
	public void setEquities(float equities) {
		this.equities = equities;
	}
	public float getFx() {
		return fx;
	}
	public void setFx(float fx) {
		this.fx = fx;
	}
	public float getBonds() {
		return bonds;
	}
	public void setBonds(float bonds) {
		this.bonds = bonds;
	}
	public String getFund_rate() {
		return fund_rate;
	}
	public void setFund_rate(String fund_rate) {
		this.fund_rate = fund_rate;
	}
	public String getFund_ratio() {
		return fund_ratio;
	}
	public void setFund_ratio(String fund_ratio) {
		this.fund_ratio = fund_ratio;
	}
		

	
}