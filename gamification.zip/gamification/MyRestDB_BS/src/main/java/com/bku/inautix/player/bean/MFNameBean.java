package com.bku.inautix.player.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="mf")
public class MFNameBean {
	String mf_name;

	public MFNameBean() {
		
	}

	public MFNameBean(String mf_name) {
		
		this.mf_name = mf_name;
	}

	public String getMf_name() {
		return mf_name;
	}

	public void setMf_name(String mf_name) {
		this.mf_name = mf_name;
	}
	

}
