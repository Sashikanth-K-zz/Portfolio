package com.bku.inautix.broker.bean;



import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="clientreport")
public class clientreport1 {

	
	private String Name;
	private String User_Id;
	private String bid;
	
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	private int quantity;
	private float price;
	private float netvalue;
	private String status;
	private float broker_fee;
	private float Mar_Interest;
	public float getBroker_fee() {
		return broker_fee;
	}
	public void setBroker_fee(float broker_fee) {
		this.broker_fee = broker_fee;
	}
	public float getMar_Interest() {
		return Mar_Interest;
	}
	public void setMar_Interest(float mar_Interest) {
		Mar_Interest = mar_Interest;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getUser_Id() {
		return User_Id;
	}
	public void setUser_Id(String user_Id) {
		User_Id = user_Id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getNetvalue() {
		return netvalue;
	}
	public void setNetvalue(float netvalue) {
		this.netvalue = netvalue;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}