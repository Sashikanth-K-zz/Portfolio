package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.userAdmin;

public class AdminRowMapper implements RowMapper<userAdmin>
{
	public userAdmin mapRow(ResultSet rs, int rowNum) throws SQLException {
		userAdmin obj = new userAdmin();		
		obj.setName(rs.getString("usrname"));
		return obj;
	}
}
