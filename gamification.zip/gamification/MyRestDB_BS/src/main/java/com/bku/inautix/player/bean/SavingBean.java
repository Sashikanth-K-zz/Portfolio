package com.bku.inautix.player.bean;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="saving")
public class SavingBean {
	private String bid;
	private String uid;
	private String date;
	private String locked;
	public String getBid() {
		return bid;
	}
	public void setLocked(String locked) {
		this.locked = locked;
	}
	public String getLocked() {
		return locked;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
		
}
