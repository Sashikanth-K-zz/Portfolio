package com.bku.inautix.model;

import java.sql.Date;
import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="transactions")
public class Transaction 
{
	public Transaction()
	{}
	public Transaction(int tid,String name, String uid, Date getDatetime, int quantity, float price,int netvalue, String status)
	{
		this.tid = tid;
		this.name= name;
		this.getDatetime=getDatetime;
		this.quantity=quantity;
		this.price=price;
		this.status=status;
		this.netvalue=netvalue;
		this.uid=uid;
		
		
	}
	private String name;
	
	private String uid;
	
	public String getUid() 
	{
		return uid;
	}
	public void setUid(String uid)
	{
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getGetDatetime() {
		return getDatetime;
	}
	public void setGetDatetime(Date getDatetime) {	
		this.getDatetime = getDatetime;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	private float price;
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private Date getDatetime;
	private int quantity;
    private int tid;
	private String status;
	private float mfr;
	private int netvalue;
	private Timestamp s;
	private int mfrate;
	private String bid;
	public Timestamp getTimer()
	{
		return s;
	}
	public void setTimer(Timestamp s)
	{
		this.s = s;
	}
	public float getMfr()
	{
		return mfr;
	}
	public void setMfr(float m)
	{
		this.mfr = m;
	}
	public int getNetvalue() {
		return netvalue;
	}
	public int getTidvalue() {
		return tid;
	}
	public void setNetvalue(int netvalue) {
		this.netvalue = netvalue;
	}
	public void setTidvalue(int tidvalue) {
		this.tid = tidvalue;
	}
	public int getMfrate() {
		return mfrate;
	}
	public void setMfrate(int mfrate) {
		this.mfrate = mfrate;
	}
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
}
