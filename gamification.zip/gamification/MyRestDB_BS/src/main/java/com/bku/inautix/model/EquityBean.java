package com.bku.inautix.model;

public class EquityBean {
	private String broker_id;
	
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getBroker_id() {
		return broker_id;
	}
	public void setBroker_id(String broker_id) {
		this.broker_id = broker_id;
	}
	public String getMarg_ratio() {
		return marg_ratio;
	}
	public void setMarg_ratio(String marg_ratio) {
		this.marg_ratio = marg_ratio;
	}
	public String getMarg_rate() {
		return marg_rate;
	}
	public void setMarg_rate(String marg_rate) {
		this.marg_rate = marg_rate;
	}
	private String b_name;
	private String marg_ratio;
	private String marg_rate;
}
