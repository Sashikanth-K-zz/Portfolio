package com.bku.inautix.broker.rowMapper;

	import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.broker.bean.*;
	


	public class AdviceRowMapper implements RowMapper<AdviceBean> {
		public AdviceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
			AdviceBean obj = new AdviceBean();		
			obj.setAdvice(rs.getString(1));
			
			return obj;
		}
	}

