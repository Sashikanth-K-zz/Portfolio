package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.TransactionHistory;

public class HistoryRowMapper implements  RowMapper<TransactionHistory> {
	public TransactionHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
		TransactionHistory obj = new TransactionHistory();		
		obj.setUserid(rs.getString("uid"));
		obj.setSybl(rs.getString("name"));
		obj.setDat(rs.getDate("getDatetime"));
		obj.setQuantity(rs.getInt("quantity"));
		obj.setPrice(rs.getFloat("price"));
		obj.setSecurity_type(rs.getString("security_type"));
		obj.setAction(rs.getString("status"));
		obj.setBr_fee(rs.getFloat("br_amount"));
		obj.setBr_int(rs.getFloat("marg_interest"));
		return obj;
	}
}