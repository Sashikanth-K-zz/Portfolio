package com.bku.inautix.player.dao.impl;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Types;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.JOptionPane;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.component.Read;
import com.bku.inautix.dao.BondRowMapper;
import com.bku.inautix.dao.EquityRowMapper;
import com.bku.inautix.dao.FXNameRowMapper;
import com.bku.inautix.dao.FXRowMapper;
import com.bku.inautix.dao.MFRowMapper;
import com.bku.inautix.dao.SecuritiesRowMapper;
import com.bku.inautix.dao.StocksRowMapper;
import com.bku.inautix.dao.TransactionRowMapper;
import com.bku.inautix.model.Bond;
import com.bku.inautix.model.BondServiceBean;
import com.bku.inautix.model.Bonds;
import com.bku.inautix.model.EquityBean;
import com.bku.inautix.model.FX;
import com.bku.inautix.model.FXNameBean;
import com.bku.inautix.model.FXServiceBean;
import com.bku.inautix.model.MFNameBean;
import com.bku.inautix.model.MFServiceBean;
import com.bku.inautix.model.SecuritiesBean;
import com.bku.inautix.model.Stock;
import com.bku.inautix.model.Stocks;
import com.bku.inautix.model.Transaction;
import com.bku.inautix.player.bean.BrokerageBean;
import com.bku.inautix.player.bean.SavingBean;
import com.bku.inautix.player.dao.IPlayerDAO;
import com.bku.inautix.player.rowmapper.BondsRowMapper;
import com.bku.inautix.player.rowmapper.BrokerageRowMapper;
import com.bku.inautix.player.rowmapper.MFNameRowMapper;
import com.bku.inautix.player.rowmapper.SavingBrokerRowMapper;

public class PlayerDAO implements IPlayerDAO{
	
	public String insertbond(DataSource dataSourcePlayer)
	{
		int count=0;
		Bond bondobject = new Bond();
		
		Read ReadObj= new Read();
		bondobject=ReadObj.ReadBond();
		
		//Parse variables for getting values into the bean
		List<String> com_name = bondobject.getBond_name();
		List<String> com_sym = bondobject.getBond_symbol();
		List<String> com_cusip = bondobject.getCUSIP();
		List<Float> com_price =bondobject.getPrice();
		
		System.out.println(com_name+" "+com_sym);
		
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd ");
		
		
		try {
	
			JdbcTemplate template = new JdbcTemplate(dataSourcePlayer);
			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR , Types.FLOAT, Types.DATE};
			
				System.out.println("size of the bonds :"+com_name.size());
				template.update("delete from bond");
		for (int i=0; i< com_name.size(); i++)
				{
					
			
				int row = template.update("insert into bonds values(?,?,?,?,?)", new Object[]{com_name.get(i),com_sym.get(i),com_cusip.get(i),com_price.get(i),dateFormat.format(date)}, types);
				if(row == 0)
					continue;
				count=count+row;
				//System.out.println("Row inserted is " +row);
			
				}
			 
			System.out.println("total number of rows inserted : " + count);
			 
			
		
		
			System.out.println("in try block");
			 

		 }
		catch(DuplicateKeyException e){
			return "<html><script>alert(\"Update for the day is done\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
		}
		
		
		catch (Throwable fault) {
			
			System.out.println("Error inserting : " );
			fault.printStackTrace();
			return "<html><script>alert(\"Error Inserting\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
			}
				
		return "<html><script>alert(\"Values inserted into stock database\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
		//if we return null here, it sends back a 404.  Good.
		
	}
	
	/**************************************************************************************************************/
	
	public String insertmf(DataSource dataSourcePlayer)
	{
		int count=0;
		Bond bondobject = new Bond();
		Read ReadObj= new Read();
		@SuppressWarnings("unused")
		Stock stockobj = new Stock();	// used because of a stupidity that i don't have time to solve now
		stockobj=ReadObj.ReadStock();
		bondobject = ReadObj.ReadBond();
		//Parse variables for getting values into the bean
		List<String> com_name = bondobject.getBond_name();
		List<String> com_sym = bondobject.getBond_symbol();
		List<String> com_cusip = bondobject.getCUSIP();
		List<Float> com_price =bondobject.getPrice();
		
		
		
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd ");
		
		
		try {
			
			JdbcTemplate template = new JdbcTemplate(dataSourcePlayer);
			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR , Types.FLOAT, Types.DATE};
			
				System.out.println("size of the bonds :"+com_name.size());
				
				for (int i=0; i< com_name.size(); i++)
				{
					
			
				int row = template.update("insert into bonds values(?,?,?,?,?)", new Object[]{com_name.get(i),com_sym.get(i),com_cusip.get(i),com_price.get(i),dateFormat.format(date)}, types);
				if(row == 0)
					continue;
				count=count+row;
				//System.out.println("Row inserted is " +row);
			
				}
			 
			System.out.println("total number of rows inserted : " + count);
			 
			
		
		
			System.out.println("in try block");
			 

		 }
		catch(DuplicateKeyException e){
			return "update for the day is done";
		}
		
		
		catch (Throwable fault) {
			
			System.out.println("Error inserting : " );
			fault.printStackTrace();
			return "error inserting";
			}
				
		return "Values inserted into bond database";
		//if we return null here, it sends back a 404.  Good.
	}
	
	
	/**************************************************************************************************************/
	
	public String insertfx(DataSource dataSourcePlayer)
	{
		int count=0;
		FX fxobject = new FX();
		Read ReadObj= new Read();
		@SuppressWarnings("unused")
		Stock stockobj = new Stock();	// used because of a stupidity that i don't have time to solve now
		stockobj=ReadObj.ReadStock();
		fxobject = ReadObj.ReadFX();
		//Parse variables for getting values into the bean
		List<String> com_name = fxobject.getFX_name();
		List<String> com_sym = fxobject.getTicker_symbol();
		
		List<Float> com_price =fxobject.getPrice();
		
		
		
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd ");
		
		
		try {
			
			JdbcTemplate template = new JdbcTemplate(dataSourcePlayer);
			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,Types.FLOAT, Types.DATE};
			
				System.out.println("size of the fx :"+com_name.size());
				
				for (int i=0; i< com_name.size(); i++)
				{
					
			
				int row = template.update("insert into fx values(?,?,?,?)", new Object[]{com_name.get(i),com_sym.get(i),com_price.get(i),dateFormat.format(date)}, types);
				if(row == 0)
					continue;
				count=count+row;
				//System.out.println("Row inserted is " +row);
			
				}
			 
			System.out.println("total number of rows inserted : " + count);
			 
			
		
		
			System.out.println("in try block");
			 

		 }
		catch(DuplicateKeyException e){
			return "update for the day is done";
		}
		
		
		catch (Throwable fault) {
			
			System.out.println("Error inserting : " );
			fault.printStackTrace();
			return "error inserting";
			}
				
		return "Values inserted into Forex database";
		//if we return null here, it sends back a 404.  Good.
	}
	
	
	/**************************************************************************************************************/
	
	public List<MFServiceBean> getMFS(JdbcTemplate jdbcTemplate)
	{
		List<MFServiceBean> list= null;
		try {
			list=  jdbcTemplate.query("select * from mf",
		        new Object[]{}, //in parameters
		        new MFRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
			
		}
		/*for(int i=0; i< obj.size() ; i++)
		{
			System.out.println(obj.get(i).getStock_name());
			System.out.println(obj.get(i).getStock_symbol());
			System.out.println(obj.get(i).getCUSIP());
			System.out.println(obj.get(i).getPrice());
			System.out.println(obj.get(i).getDate());
			
		}*/
		System.out.println(" Got the MF, returning to you buddy");
		
		
			
		//if we return null here, it sends back a 404.  Good.
		return list;
	}
	
	
	
	/**************************************************************************************************************/
	
	public List<FXServiceBean> getFX(JdbcTemplate jdbcTemplate)
	{
		List<FXServiceBean> list= null;
		try {
			list=  jdbcTemplate.query("select * from fx",
		        new Object[]{}, //in parameters
		        new FXRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
			
		}
		/*for(int i=0; i< obj.size() ; i++)
		{
			System.out.println(obj.get(i).getStock_name());
			System.out.println(obj.get(i).getStock_symbol());
			System.out.println(obj.get(i).getCUSIP());
			System.out.println(obj.get(i).getPrice());
			System.out.println(obj.get(i).getDate());
			
		}*/
		System.out.println(" Got the FX, returning to you buddy");
		
		
			
		//if we return null here, it sends back a 404.  Good.
		return list;
	}
	
	

	public List<BondServiceBean> getBond(JdbcTemplate jdbcTemplate)
	{
		List<BondServiceBean> list= null;
		try {
			list=  jdbcTemplate.query("select * from bonds",
		        new Object[]{}, //in parameters
		        new BondRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
			
		}
		/*for(int i=0; i< obj.size() ; i++)
		{
			System.out.println(obj.get(i).getStock_name());
			System.out.println(obj.get(i).getStock_symbol());
			System.out.println(obj.get(i).getCUSIP());
			System.out.println(obj.get(i).getPrice());
			System.out.println(obj.get(i).getDate());
			
		}*/
		System.out.println(" Got the Bond, returning to you buddy");
		
		
			
		//if we return null here, it sends back a 404.  Good.
		return list;
	}
	
	
	public String uploadFileBond(
		     @Multipart("fileUploadBonds") Attachment attachment)
		     {
		 try{ 		   

		       String ofilename = attachment.getContentDisposition().getParameter("filename");
		       String filename = "Pricing.xlsx";
		       if(ofilename.contains(".xlsx"))
		       { System.out.println(" original file name : "+ofilename);
		       System.out.println(" path in which the file is getting uploaded H:/Excel/"+filename);
		       //System.out.println(" file type :"+type);

		        java.nio.file.Path path = Paths.get("H:/Excel/" + filename);
		        Files.deleteIfExists(path);
		        InputStream in = attachment.getObject(InputStream.class);

		       Files.copy(in, path);
		       System.out.println("done uploading, redirecting to insert service");
		       return "<html><script>window.location.replace(\"http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/insertbond\")</script></html>" ;
		       }
		       else
		       {
		    	   return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
		       }
		       
			   }
			   
			  
			 	   
			   catch(Exception e){
				   return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
			   }
		     }
	
	public String uploadFileFX(
		     @Multipart("fileUploadFX") Attachment attachment)
		     {
		
		
		try{ 		   

		       String ofilename = attachment.getContentDisposition().getParameter("filename");
		       String filename = "Pricing.xlsx";
		       if(ofilename.contains(".xlsx"))
		       { System.out.println(" original file name : "+ofilename);
		       System.out.println(" path in which the file is getting uploaded H:/Excel/"+filename);
		       //System.out.println(" file type :"+type);

		        java.nio.file.Path path = Paths.get("H:/Excel/" + filename);
		        Files.deleteIfExists(path);
		        InputStream in = attachment.getObject(InputStream.class);

		       Files.copy(in, path);
		       System.out.println("done uploading, redirecting to insert service");
		       return "<html><script>window.location.replace(\"http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/insertfx\")</script></html>" ;
		       }
		       else
		       {
		    	   return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
		       }
		       
			   }
			   
			  
			 	   
			   catch(Exception e){
				   return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
			   }
		     }
	
	 public String uploadFileMF(
		     @Multipart("fileUploadMF") Attachment attachment)
		     {
		 try{ 		   

		       String ofilename = attachment.getContentDisposition().getParameter("filename");
		       String filename = "Pricing.xlsx";
		       if(ofilename.contains(".xlsx"))
		       { System.out.println(" original file name : "+ofilename);
		       System.out.println(" path in which the file is getting uploaded H:/Excel/"+filename);
		       //System.out.println(" file type :"+type);

		        java.nio.file.Path path = Paths.get("H:/Excel/" + filename);
		        Files.deleteIfExists(path);
		        InputStream in = attachment.getObject(InputStream.class);

		       Files.copy(in, path);
		       System.out.println("done uploading, redirecting to insert service");
		       return "<html><script>window.location.replace(\"http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/insertmf\")</script></html>" ;
		       }
		       else
		       {
		    	   return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
		       }
		       
			   }
			   
			  
			 	   
			   catch(Exception e){
				   return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://172.24.34.90:8090/PortfolioGame/admin.jsp\");</script></html>";
			   }
		     }
		 
		 
		 public List<MFNameBean> getMFName(JdbcTemplate jdbcTemplate)
		 {
			 List<MFNameBean> list = null;
				try 
				{	
					
					// to display stock_name and stock_price of that particular date
					list = jdbcTemplate.query(
							"select mf_name from mf",
				        new Object[]{}, //in parameter
				        new MFNameRowMapper());
					
					//to change the market_price to the updated market_price
					
				} 
				catch (Throwable fault) 
				{
					System.out.println("Got error.  Returning null (404)");
					fault.printStackTrace();
					
				}
				//if we return null here, it sends back a 404.  Good.
				return list;
		 }
	
		 
		 
		 public List<FXNameBean> getFXName(JdbcTemplate jdbcTemplate)
		 {
			 List<FXNameBean> list = null;
				try 
				{	
					
					// to display stock_name and stock_price of that particular date
					list = jdbcTemplate.query(
							"select fx_name from fx",
				        new Object[]{}, //in parameter
				        new FXNameRowMapper());
					
					//to change the market_price to the updated market_price
					
				} 
				catch (Throwable fault) 
				{
					System.out.println("Got error.  Returning null (404)");
					fault.printStackTrace();
					
				}
				//if we return null here, it sends back a 404.  Good.
				return list;
		 }
		 
		 
		 public List<Bonds> getBondsName(JdbcTemplate jdbcTemplate)
		 {
			 List<Bonds> list = null;
				try 
				{	
					
					// to display stock_name and stock_price of that particular date
					list = jdbcTemplate.query(
							"select bond_name from bond",
				        new Object[]{}, //in parameter
				        new BondsRowMapper());
					
					//to change the market_price to the updated market_price
	
				} 
				catch (Throwable fault) 
				{
					System.out.println("Got error.  Returning null (404)");
					fault.printStackTrace();
	
				}
				//if we return null here, it sends back a 404.  Good.
				return list;
		 }
	
	
		 public List<Stocks> getStocksName(JdbcTemplate jdbcTemplate)
		 {
			 List <Stocks> list = null;
				try 
				{	

					// to display stock_name and stock_price of that particular date
					list = jdbcTemplate.query(
							"select stk_name from stock",
				        new Object[]{}, //in parameter
				        new StocksRowMapper());

					//to change the market_price to the updated market_price

				} 
				catch (Throwable fault) 
				{
					System.out.println("Got error.  Returning null (404)");
					fault.printStackTrace();

				}
				//if we return null here, it sends back a 404.  Good.
				return list;
		 }
		//*********************bhavani CODE ends here*******************
/***********************************SELECTING BROKER ****************************************************/
	public List<BrokerageBean> getBrokerageValues(int bid,JdbcTemplate jdbcTemplate)
	{
	List<BrokerageBean> list = null;
	
	try {
			list = jdbcTemplate.query("select * from T_BROKER_DET where broker_id = ? and time_stamp = ( select max (time_stamp) from T_BROKER_DET where broker_id=?) and status='p'",
		        new Object[]{bid,bid}, //in parameters
		        new BrokerageRowMapper());
			} 
	catch (Throwable fault) {
		
		//EMP ID: 13486
		JOptionPane.showMessageDialog(null, "An Error has occured!");
		
		System.out.println("Checking the broker details");
		fault.printStackTrace();
		}
	
	return list;
	
	}
	
	
	/***********************************SAVING BROKER ****************************************************/
	public List<SavingBean> getSavingValues(String bid,String uid,String getDatetime,JdbcTemplate jdbcTemplate)
	{
		List<SavingBean> list1 = null;
		List<SavingBean> list = null;
	    try {
	       	   
	       //To query the DB for JSON output	   
	       list = jdbcTemplate.query("select * from savingbroker where uid = ? and bid = ?",
	       new Object[]{uid,bid}, //in parameters
	       new SavingBrokerRowMapper());
	       
	       //To check whether a given user exist
	       list1 =jdbcTemplate.query("select * from savingbroker where uid = ?",
	       new Object[]{uid}, //in parameters
	       new SavingBrokerRowMapper());
	       
	       //Initializations
			String exist = null;
			String dateindb = null;
			String bidb = null;
			
			for(SavingBean sab : list1) // To get the Initial date and time from DB
			{
			exist = sab.getUid();
			dateindb = sab.getDate();
			bidb = sab.getBid();
			}
			System.out.println(dateindb);
			if(dateindb == null) //If the user doesn't exist set them to current date
			  dateindb = getDatetime;
		 
			//To get difference in date!
			SimpleDateFormat formatcur = new SimpleDateFormat("yyyy-MM-dd-hh");
			Date stampdb = formatcur.parse(dateindb);
			Date stampurl = formatcur.parse(getDatetime);
			DecimalFormat brokerFormatter = new DecimalFormat("###,###");
			long diff = stampdb.getTime() - stampurl.getTime();
			int diffhours = (int) (diff / (60 * 60 * 1000));
			String difference = brokerFormatter.format(diffhours);
			System.out.println("At top The Difference is: "+difference);
			int diffe = Integer.parseInt(difference);
			int differences = 0;
			System.out.println("The Difference is: " +diffe);
			if(diffe < 0)
				differences = Math.abs(diffe);
			System.out.println("The Differences is: " +differences);
			//Differnce of date ends here!

	   
	    if( (list.size() == 0) && (exist==null) ) // Used to insert new user into DB
	    {
	   	System.out.println("Not Present, Adding user to the db- copy1");
	   	
	   	//Setting the current date to the stamp for the new user
			Date curDate = new Date();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-hh");
			String stamp = format.format(curDate);
			stamp = stamp.toString();
			System.out.println(stamp);
			
			//Row insertion
			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
			int row = jdbcTemplate.update("insert into savingbroker values(?,?,?)", new Object[]{uid,bid,stamp}, types);
			
			System.out.println(row+" row inserted!");
			
			 for(SavingBean sab : list1)
	        {
	   		 sab.setLocked("no");
	        }
	    }
	    
	    else if(differences <= 24) // Check if the user's last update was less than 24hours ago
	    {
	   	
	   	 for(SavingBean sab : list1)
	        {	
	   		 sab.setDate("null");
	   		 sab.setUid("null");
	   		 sab.setLocked("yes");
	        }
	   	 
	    }
	    
	    else if(differences > 24 ) // Updating the user only after 24 hours!
	    {
			Date curDate = new Date();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-hh");
			String stamp = format.format(curDate);
			stamp = stamp.toString();
			System.out.println(stamp);
			
			int row = jdbcTemplate.update("update savingbroker set bid=?,stamp=? where uid=?", new Object[]{bid,stamp,uid});
			System.out.println(row+" row updated!");
	        
			for(SavingBean sab : list1)
			{
				
				sab.setLocked("no");
			}
	       
	    }
	    
	    else
	    {
			String datetime = null;
			String userid = null;
			for(SavingBean sab : list)
			{
				datetime = sab.getDate();
				userid = sab.getUid();
			}
			    	
			  
			if(getDatetime.equals(datetime) && exist.equals(userid))
			{
				System.out.println("Present!");
				for(SavingBean sab : list1)
				{
					sab.setDate("null");
					sab.setUid("null");
					sab.setLocked("no");
				}
			} 
			else
				System.out.println("Absent!");
	       }                                 
	          }
	    catch (Throwable fault) {
	                 System.out.println("Checking the Saving details");
	                 fault.printStackTrace();                               
	          }
	    return list1;
	}
	
	
	/********************************************************************************************/
	/***********************************SAVING BROKER ****************************************************/
	public List<SavingBean> getSavedValues(String bid,String uid,String getDatetime,JdbcTemplate jdbcTemplate)
	{
		List<SavingBean> list = null;
		System.out.println("In player DAO saved broker");
	    try {   	   
	       //To query the DB for JSON output	   
	   
	
	       list = jdbcTemplate.query("select * from savingbroker where uid = ? and bid = ?",
	       new Object[]{uid,bid}, //in parameters
	       new SavingBrokerRowMapper());
                      
	          }
	    catch (Throwable fault) {
	                 System.out.println("Checking the Saving details");
	                 fault.printStackTrace();                               
	          }
	    System.out.println("return list val"+list);
	    return list;
	}
	
	
	/********************************************************************************************/
	public List<Transaction> sellEquity(String name,
			Float price,
			Date getDatetime,
			Integer quantity,
			String uid,
			String security_type,
			String equties,JdbcTemplate jdbcTemplate)
	{
		
		List<Transaction> list = null;
		List<EquityBean> list1 = null;
		List<SavingBean> list2 = null;
		List<SecuritiesBean> list3 = null;
		/*
		 * returns the number of rows that contains the given uid, if it is 0
		 * then the uid doesnt exist in holding_table else it exists in
		 * holding_table
		 */

		try {
			list2 = jdbcTemplate.query(
					"select * from savingbroker where uid=?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());
			String b_id = null;
			for (SavingBean eb : list2)
				b_id = eb.getBid();

			// To query the DB for JSON output
			list1 = jdbcTemplate.query("select * from brokerages where b_id=?",
					new Object[] { b_id }, // in parameters
					new EquityRowMapper());
			list3 = jdbcTemplate.query("select * from T_BROKER_DET where broker_id=?",
					new Object[] { b_id }, // in parameters
					new SecuritiesRowMapper());
			String marg_ratio = null;
			String br_rate = null;
			String marg_rate=null;
			for (EquityBean eb1 : list1)
				marg_ratio = eb1.getMarg_ratio();
			for (EquityBean eb1 : list1)
				marg_rate = eb1.getMarg_rate();
			for (SecuritiesBean eb1 : list3)
				br_rate = eb1.getEquities();
			float br_rate1=Float.parseFloat(br_rate);
			System.out.println(marg_ratio);
			String[] parts = marg_ratio.split(":");
			String[] parts1 = marg_rate.split("%");
			int part1 = Integer.parseInt(parts[0]); // user share
			int part2 = Integer.parseInt(parts[1]); // broker share
			int rate=Integer.parseInt(parts1[0]);
			System.out.println("hi" + part1 + part2);

			int uid_present = jdbcTemplate.queryForObject(
					"select count(*) from holding where uid=? and name=?",
					new Object[] { uid, name }, Integer.class);
			int holding_quantity =jdbcTemplate.queryForObject(
					"select quantity from holding where uid=? and name=?",
					new Object[] { uid, name }, Integer.class);

			// the new row with this uid does not exist

			if (uid_present > 0)

			{
				// the number of shares he holds is greater than number of
				// shares he is going to sell
				if (holding_quantity >= quantity) {
					int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
							Types.DATE, Types.INTEGER, Types.FLOAT,
							Types.VARCHAR,Types.FLOAT,Types.FLOAT };
					float netvalue = quantity * price;
					float user_share = (float) (netvalue * (part1 * .01));
                    float br_share= (float) (netvalue * (part2 * .01));
                    float br_int=(float)(br_share*(rate*.01));
					float br_fee=(float) (netvalue * (br_rate1 * .01));
					// Selling Transaction into Transaction1_table
					jdbcTemplate.update("insert into transaction1(" + "name,"
							+ "uid," + "getDatetime," + "quantity," + "price,"
							+ "netvalue," + "status," + "security_type," + " br_amount," + " marg_interest)"
							+ " values (?,?,?,?,?," + user_share + "," + "'S',?)",
							new Object[] { name, uid, getDatetime, quantity,
									price, security_type,br_fee,br_int },// in parameter

							types); // in parameter

					// subtract the quantity in holding_table after you sell the
					// shares
					int holding5 = jdbcTemplate
							.queryForObject(
									"select quantity from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					int holding6 = holding5 - quantity;

					// subtract the holding in holding_table after you sell the
					// shares
					int holding7 = jdbcTemplate
							.queryForObject(
									"select holding from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					float holding8 = holding7 - user_share;

					// update holding_table after sell
					jdbcTemplate
							.update("update holding set quantity=?,holding=? where uid=? and name=?",
									new Object[] { holding6, holding8, uid,
											name });

					// if holding is 0 then delete that entry from holding table
					if (holding8 == 0) {
						jdbcTemplate.update(
								"delete from holding where uid=? and name=?",
								new Object[] { uid, name });
					}

					// incrementing balance in balance_table
					float holding9 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					float holding10 = holding9 + user_share;
					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding10, uid });

					// display transaction1_table
					list = jdbcTemplate.query(
							"select * from transaction1 where getDatetime = ?",
							new Object[] { getDatetime },// in parameter
							new TransactionRowMapper());
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding10, uid });
					jdbcTemplate
							.update("update holding set holding.current_holding=(select stock.price*holding.quantity from stock where holding.name=stock.stk_name )",
									new Object[] {});
					System.out.println("I was in Player DAO sell equity");
				}
			}
		}

		catch (NullPointerException e) {
			// EMP ID: 13498
			JOptionPane.showMessageDialog(null, "An Error has occured!");
			System.out.println("Stock does not exist");
			// fault.printStackTrace();
			list = null;
			return list;
		} catch (Throwable fault) {
			System.out.println("Stock does not exist");
			//log.info("ERROR due to no data in holding for the user : " + uid);
		}

		//getAutoupdate();
		// if we return null here, it sends back a 404. Good.
		return list;

}
	/********************************************************************************************/

	
	
	
	public List<Transaction> getEquity(String name,
			Float price,
			Date getDatetime,
			Integer quantity,
			String uid,
			String security_type,
			String equties,JdbcTemplate jdbcTemplate) {
		List<Transaction> list = null;
		List<EquityBean> list1 = null;
		List<SavingBean> list2 = null;
		float brokers_share = 0;
		float netvalue = quantity * price;
		try {
			// EquityBean eq
			// =jdbcTemplate.queryForObject("select marg_ratio from brokerages where b_id=(select b_id from portfolio where usrname=?)",
			// new Object[]{uid},new EquityRowMapper());
			list2 = jdbcTemplate.query(
					"select * from savingbroker where uid=?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());
			String b_id = null;
			for (SavingBean eb : list2)
				b_id = eb.getBid();
			System.out.println(b_id);
			// To query the DB for JSON output
			list1 = jdbcTemplate.query("select * from brokerages where b_id=?",
					new Object[] { b_id }, // in parameters
					new EquityRowMapper());
		    String marg_ratio = null;
			for (EquityBean eb1 : list1)
				marg_ratio = eb1.getMarg_ratio();

			System.out.println(marg_ratio);

			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.DATE,
					Types.INTEGER, Types.FLOAT, Types.VARCHAR };
			int[] types1 = new int[] { Types.VARCHAR, Types.VARCHAR,
					Types.INTEGER, Types.FLOAT };

			//

			String[] parts = marg_ratio.split(":");
			int part1 = Integer.parseInt(parts[0]); // user share
			int part2 = Integer.parseInt(parts[1]); // broker share
			System.out.println("hi" + part1 + part2);
			float num = jdbcTemplate.queryForObject(
					"select balance from balance where uid=?",
					new Object[] { uid }, Integer.class);
			float user_share = (float) (netvalue * (part1 * .01));
			brokers_share = (float) (netvalue * (part2 * .01));
			System.out.println("net value: " + netvalue);
			System.out.println("To buy: " + user_share);
			System.out.println("brokers_share: " + brokers_share);
			// if balance greater than netvalue buy shares
			if (num >= user_share) {

				// Add the shares bought into transaction_table
				jdbcTemplate.update("insert into transaction1(" + "name,"
						+ "uid," + "getDatetime," + "quantity," + "price,"
						+ "netvalue," + "status," + "security_type)"
						+ " values (?,?,?,?,?," + user_share + "," + "'B',?)",
						new Object[] { name, uid, getDatetime, quantity, price,
								security_type },// in parameter
						types); // in parameter

				/*
				 * returns the number of rows that contains the given uid, if it
				 * is 0 then the uid doesnt exist in holding_table else it
				 * exists in holding_table
				 */
				int stockname_holding = jdbcTemplate.queryForObject(
						"select count(*) from holding where uid=? and name=?",
						new Object[] { uid, name }, Integer.class);

				// the new row with this uid does not exist
				if (stockname_holding == 0) {

					int holding17 = 0;
					float holding19 = 0;

					// if this uid does not exists add as a new row to the
					// holding_table
					jdbcTemplate.update("insert into holding(" + "uid,"
							+ "name," + "quantity," + "price," + "holding,"
							+ " amount_lg," + "percentage_lg,"
							+ "current_holding)" + " values (?,?,?,?," + user_share
							+ "," + holding17 + "," + holding19 + "," + user_share
							+ ")", new Object[] { uid, name, quantity, price },// in
																				// parameter
							types1);
					list = jdbcTemplate
							.query("select * from transaction1 where getDatetime = ? and uid=?",
									new Object[] { getDatetime, uid },// in
																		// parameter
									new TransactionRowMapper());
					/*for (Transaction tb : list)
						tb.setbroker_share();*/
					// reduce the balance
					float holding15 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					float holding16 = holding15 - user_share;
					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding16, uid });
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding16, uid });
					jdbcTemplate
							.update("update holding set holding.current_holding=(select stock.price*holding.quantity from stock where holding.name=stock.stk_name )",
									new Object[] {});
					System.out.println("I WAS HERE FIRST");
				}

				// if the row exists update the holding valuein holding_table

				else {
					float holding_current = jdbcTemplate
							.queryForObject(
									"select holding from holding where uid=? and name=?",
									new Object[] { uid, name }, Float.class);
					float holding_updated = holding_current + user_share;
					// jdbcTemplate.update("update holding set holding=?", new
					// Object[]{holding2});

					list = jdbcTemplate
							.query("select * from transaction1 where getDatetime = ? and uid=?",
									new Object[] { getDatetime, uid },// in
																		// parameter
									new TransactionRowMapper());
					/*for (Transaction tb : list)
						tb.setBrokers_share(brokers_share);*/
					// decrementing balance in balance_table
					float holding3 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					float holding4 = holding3 - user_share;

					// adding quantity in holding_table
					int holding13 = jdbcTemplate
							.queryForObject(
									"select quantity from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					int holding14 = holding13 + quantity;
					float amount_lg = (holding14 * price) - holding_updated;
					float percent_lg = (amount_lg / holding_updated) * 100;

					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding4, uid });
					jdbcTemplate
							.update("update holding set holding=?,quantity=?,price=?,amount_lg=?,percentage_lg=? where uid=? and name=?",
									new Object[] { holding_updated, holding14,
											price, amount_lg, percent_lg, uid,
											name });
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding4, uid });
					jdbcTemplate
							.update("update holding set holding.current_holding=(select stock.price*holding.quantity from stock where holding.name=stock.stk_name )",
									new Object[] {});
					System.out.println("I WAS HERE TOO ....");
				}

			}

		} catch (Throwable fault) {
			// EMP ID: 13498
			JOptionPane.showMessageDialog(null, "An Error has occured!");

			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
		}

		//getAutoupdate();
		// if we return null here, it sends back a 404. Good.

		return list;
	}

}
