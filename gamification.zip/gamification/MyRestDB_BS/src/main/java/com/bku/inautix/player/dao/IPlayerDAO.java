package com.bku.inautix.player.dao;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import javax.ws.rs.PathParam;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.model.Transaction;
import com.bku.inautix.player.bean.BrokerageBean;
import com.bku.inautix.player.bean.SavingBean;
import com.bku.inautix.model.BondServiceBean;
import com.bku.inautix.model.Bonds;
import com.bku.inautix.model.FXNameBean;
import com.bku.inautix.model.FXServiceBean;
import com.bku.inautix.model.MFNameBean;
import com.bku.inautix.model.MFServiceBean;
import com.bku.inautix.model.Stocks;

public interface IPlayerDAO {
	public List<BrokerageBean> getBrokerageValues(int bid,JdbcTemplate jdbcTemplate);
	public List<SavingBean> getSavingValues(@PathParam("bid") String bid,@PathParam("uid") String uid,@PathParam("getDatetime") String getDatetime,JdbcTemplate jdbcTemplate);
	public List<SavingBean> getSavedValues(@PathParam("bid") String bid,@PathParam("uid") String uid,@PathParam("getDatetime") String getDatetime,JdbcTemplate jdbcTemplate);
	public List<Transaction> sellEquity(@PathParam("name") String name,
			@PathParam("price") Float price,
			@PathParam("getDatetime") Date getDatetime,
			@PathParam("quantity") Integer quantity,
			@PathParam("uid") String uid,
			@PathParam("security_type") String security_type,
			@PathParam("equities") String equties,JdbcTemplate jdbcTemplate);
	public List<Transaction> getEquity(@PathParam("name") String name,
			@PathParam("price") Float price,
			@PathParam("getDatetime") Date getDatetime,
			@PathParam("quantity") Integer quantity,
			@PathParam("uid") String uid,
			@PathParam("security_type") String security_type,
			@PathParam("equities") String equties,JdbcTemplate jdbcTemplate);
public String insertbond(DataSource dataSourcePlayer);
	public String insertmf(DataSource dataSourcePlayer);
	public String insertfx(DataSource dataSourcePlayer);
	public List<MFServiceBean> getMFS(JdbcTemplate jdbcTemplate);
	public List<FXServiceBean> getFX(JdbcTemplate jdbcTemplate);
	public List<BondServiceBean> getBond(JdbcTemplate jdbcTemplate);
	public String uploadFileBond(
		     @Multipart("fileUploadBonds") Attachment attachment);
	
	public String uploadFileFX(
		     @Multipart("fileUploadFX") Attachment attachment);
	 public String uploadFileMF(
		     @Multipart("fileUploadMF") Attachment attachment);
	 
	 public List<MFNameBean> getMFName(JdbcTemplate jdbcTemplate);
	 public List<FXNameBean> getFXName(JdbcTemplate jdbcTemplate);
	 public List<Bonds> getBondsName(JdbcTemplate jdbcTemplate);
	 public List<Stocks> getStocksName(JdbcTemplate jdbcTemplate);
	

}
