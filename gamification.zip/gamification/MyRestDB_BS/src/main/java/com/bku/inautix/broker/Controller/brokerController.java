package com.bku.inautix.broker.Controller;

import java.util.List;

import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bku.inautix.admin.bean.BrokerDetailsBean;
import com.bku.inautix.broker.DAO.Impl.IbrokerDAOimpl;
import com.bku.inautix.broker.bean.BrokerValuesBean;
import com.bku.inautix.broker.bean.StatusBean;



@Service("BrokerServiceBean")
@Path("brokerservice")
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON)  

public class brokerController {
	
	

	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private IbrokerDAOimpl daoimpl=new IbrokerDAOimpl();
	public DataSource getDataSource() 
	{
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
		
	}

	//*********************************************************************************************************************
	@GET
	 @Path("savedetails/{broker_id}/{uid}/{futures}/{mf}/{equities}/{fx}/{bond}/{mf_ratio}/{mf_rate}") 
 @Produces(MediaType.APPLICATION_JSON)
	 public StatusBean saveBroke(@PathParam("broker_id") String broker_id,@PathParam("uid") String broker_name,@PathParam("futures") float futures, @PathParam("mf") float mf, @PathParam("equities") float equity,@PathParam("fx") float fx,@PathParam("bond") float bond,@PathParam("mf_ratio") String mf_ratio,@PathParam("mf_rate") String mf_rate)
	{
		StatusBean statusBean=new StatusBean();
		if(futures<100&&mf<100&&equity<100&&fx<100&&bond<100)
		{
		try 
		{
			System.out.println("haaaai"+mf_rate);
			
			daoimpl.saveBroke(broker_id,broker_name,futures, mf, equity, fx, bond, mf_ratio, mf_rate,jdbcTemplate);
		}
		 catch (Exception e) {
			System.out.println("Update Error");
			e.printStackTrace();
			statusBean.setStatus(null);
			return statusBean;
		}
		
		statusBean.setStatus("true");
		return statusBean;
		}
		else
		{
			System.out.println("Update Error");
			statusBean.setStatus(null);
			return statusBean;
		}
	}

	//*********************************************************************************************************************
		@GET
		 @Path("savebalance/{broker_id}/{balance}") 
	 @Produces(MediaType.APPLICATION_JSON)
		 public StatusBean saveBalance(@PathParam("broker_id") int broker_id,@PathParam("balance") String balance)
		{
			StatusBean statusBean=new StatusBean();
			
			try 
			{   
				System.out.println("brokerid"+broker_id);
				System.out.println("balance"+balance);
				daoimpl.saveBalance(broker_id,balance,jdbcTemplate);
			}
			 catch (Exception e) {
				System.out.println("Update Error");
				e.printStackTrace();
				statusBean.setStatus(null);
				return statusBean;
			}
			
			statusBean.setStatus("true");
			return statusBean;
		}

	//*********************************************************************************************************************
	@GET
	 @Path("publishdetails/{broker_id}") 
  @Produces(MediaType.APPLICATION_JSON)
	 public StatusBean putSecurities(@PathParam("broker_id") int broker_id){
		// SaveBrokerValues obj=null;
		StatusBean statusBean=null;
		try 
		{
			statusBean=daoimpl.publishBroker(broker_id,jdbcTemplate);
		}
		
			
		catch (Exception e) {
			System.out.println("Update Error");
			e.printStackTrace();	
		}
		return statusBean;
	}
	
	//*********************************************************************************************************************
	@GET
	@Path("viewalldetails/{broker_id}") 
 @Produces(MediaType.APPLICATION_JSON)
     public List<BrokerValuesBean> ViewAllBrokers(@PathParam("broker_id") int broker_id)
     {
           List<BrokerValuesBean> list = null;
           try {
                 list=daoimpl.ViewAllBrokers(broker_id,jdbcTemplate);
           } 
           catch (Throwable fault) 
           {
                  System.out.println("Getting broker homescreen data");
                  fault.printStackTrace();
                  
           }
           
           //if we return null here, it sends back a 404.  Good.
           return list;
     }

	//*********************************************************************************************************************
	@GET
	@Path("viewpublishdetails/{broker_id}/{status}") 
 @Produces(MediaType.APPLICATION_JSON)
     public List<BrokerValuesBean> getpublishBrokers(@PathParam("broker_id") int broker_id,@PathParam("status") String status) {
           List<BrokerValuesBean> list = null;
           try {
                  list=daoimpl.ViewBrokers(broker_id, status,jdbcTemplate);
           } catch (Throwable fault) {
                  System.out.println("Getting broker homescreen data");
                  fault.printStackTrace();
                  
           }
           
           //if we return null here, it sends back a 404.  Good.
           return list;
     }  
	
	
	
		
	 }