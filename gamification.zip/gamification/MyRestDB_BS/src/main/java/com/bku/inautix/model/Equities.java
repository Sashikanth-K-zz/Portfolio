package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="equitylist")
public class Equities 
{

	public Equities()
	{
		
	}
	public Equities(String equ_name)
	{
		this.equ_name=equ_name;
	}
	private String equ_name;
	public String getEqu_name() {
		return equ_name;
	}
	public void setEqu_name(String equ_name) {
		this.equ_name = equ_name;
	}
	
}