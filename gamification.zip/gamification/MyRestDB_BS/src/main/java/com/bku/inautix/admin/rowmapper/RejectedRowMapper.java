package com.bku.inautix.admin.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.admin.bean.RejectedBrokerBean;

	public class RejectedRowMapper implements RowMapper<RejectedBrokerBean> {
		public RejectedBrokerBean mapRow(ResultSet rs, int rowNum) throws SQLException {
			
			RejectedBrokerBean obj = new RejectedBrokerBean();	
			
			obj.setFutures(rs.getFloat("futures_rate"));
			obj.setMf(rs.getFloat("mf_rate"));
			obj.setEquities(rs.getFloat("equities_rate"));
			obj.setFx(rs.getFloat("fx_rate"));
			obj.setBonds(rs.getFloat("bonds_rate"));
			obj.setMfr(rs.getString("margin_fund_ratio"));
			obj.setMargin_fund_rate(rs.getString("margin_fund_rate"));
			
			
			obj.setBroker_id(rs.getString("broker_id"));
			obj.setBroker_name(rs.getString("Broker_name"));
			
			obj.setStatus(rs.getString("status"));
			obj.setTimestamp(rs.getString("time_stamp"));
			
			
			
			
			
			return obj;
		}

}




