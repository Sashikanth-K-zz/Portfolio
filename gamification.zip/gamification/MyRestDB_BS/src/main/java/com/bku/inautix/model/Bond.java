package com.bku.inautix.model;

import java.util.List;

public class Bond {
	
	private List<String> bond_name;
	private List<String> bond_symbol;
	private List<String> CUSIP;
	private List<Float> price;
	private String date;
	
	
	public List<String> getBond_name() {
		return bond_name;
	}
	public void setBond_name(List<String> bond_name) {
		this.bond_name = bond_name;
	}
	public List<String> getBond_symbol() {
		return bond_symbol;
	}
	public void setBond_symbol(List<String> bond_symbol) {
		this.bond_symbol = bond_symbol;
	}
	public List<String> getCUSIP() {
		return CUSIP;
	}
	public void setCUSIP(List<String> cUSIP) {
		CUSIP = cUSIP;
	}
	public List<Float> getPrice() {
		return price;
	}
	public void setPrice(List<Float> price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	
	

}
