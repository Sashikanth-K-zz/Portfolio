package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.MFServiceBean;



public class MFRowMapper implements RowMapper<MFServiceBean>{
	
	
	public MFServiceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		MFServiceBean obj = new MFServiceBean();		
	
		obj.setMF_name(rs.getString(1));
		obj.setTicker_symbol(rs.getString(2));
		obj.setCUSIP(rs.getString(3));
		obj.setPrice(rs.getFloat(4));
		obj.setDate(rs.getString(5));
		
		
		return obj; 
	}


}
