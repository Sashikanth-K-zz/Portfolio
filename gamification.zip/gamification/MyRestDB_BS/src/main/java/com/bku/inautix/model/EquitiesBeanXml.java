package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="equity")
public class EquitiesBeanXml {
	
	public EquitiesBeanXml(){}
	
	public EquitiesBeanXml(String name, float price, String symbol) 
	{
		this.name=name;
		this.symbol=symbol;
		this.price=price;
	}
	
	private String name;
	public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	private String symbol;
	private float price;
	
	

}
