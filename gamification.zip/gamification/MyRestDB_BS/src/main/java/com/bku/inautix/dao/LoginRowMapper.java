package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.Login;

public class LoginRowMapper implements RowMapper<Login> {
	public Login mapRow(ResultSet rs, int rowNum) throws SQLException {
		Login obj = new Login();		
		//obj.setId(rs.getInt("id"));
		//obj.setName(rs.getString("name"));
		obj.setUsrname(rs.getString("usrname"));
		obj.setPasswd(rs.getString("passwd"));
		obj.setName(rs.getString("name"));
		obj.setType(rs.getString("type"));
		return obj;
	}
}

