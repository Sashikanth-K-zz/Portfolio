package com.bku.inautix.admin.rowmapper;


	import java.sql.ResultSet;
	import java.sql.SQLException;

	import org.springframework.jdbc.core.RowMapper;

	import com.bku.inautix.admin.bean.MarketRateBean;


	public class MarketRateRowMapper implements RowMapper<MarketRateBean> {
		public MarketRateBean mapRow(ResultSet rs, int rowNum) throws SQLException {
			MarketRateBean obj = new MarketRateBean();		
			obj.setMarket_rate(rs.getFloat("market_interest"));
			return obj;
		}
	}

