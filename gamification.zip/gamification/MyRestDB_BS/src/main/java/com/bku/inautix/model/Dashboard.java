package com.bku.inautix.model;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="gamer")

public class Dashboard {
	
	public Dashboard(){}
	
	
	
	public Dashboard(String userid,float totalValue) {
		super();
		this.userid = userid;
		this.totalValue = totalValue;
	}

	private String userid;
	private float totalValue;
	public String getUserid() {
		return userid;
	}



	public void setUserid(String userid) {
		this.userid = userid;
	}



	public float getTotalValue() {
		return totalValue;
	}



	public void setTotalValue(float totalValue) {
		this.totalValue = totalValue;
	}
	

}
