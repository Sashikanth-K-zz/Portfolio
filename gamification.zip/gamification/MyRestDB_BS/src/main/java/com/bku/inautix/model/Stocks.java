package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="stocks")
public class Stocks 
{

	public Stocks()
	{
		
	}
	public Stocks(String stk_name)
	{
		this.stk_name=stk_name;
	}
	private String stk_name;
	public String getStk_name() {
		return stk_name;
	}
	public void setStk_name(String stk_name) {
		this.stk_name = stk_name;
	}
	
}