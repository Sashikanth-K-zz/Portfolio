package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;


import com.bku.inautix.model.Person;

public class PersonRowMapper implements RowMapper<Person> {
	public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
		Person obj = new Person();		
		obj.setId(rs.getInt("id"));
		obj.setName(rs.getString("name"));
		return obj;
	}
}

