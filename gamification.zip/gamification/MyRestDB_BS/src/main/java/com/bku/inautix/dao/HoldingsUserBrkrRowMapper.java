package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.HoldingsUserBrkr;

public class HoldingsUserBrkrRowMapper implements RowMapper<HoldingsUserBrkr> {
	public HoldingsUserBrkr mapRow(ResultSet rs, int rowNum) throws SQLException {
		HoldingsUserBrkr obj = new HoldingsUserBrkr();		
		
		obj.setUid(rs.getString("uid"));
		obj.setBid(rs.getString("bid"));
		obj.setSid(rs.getString("sid"));
		obj.setMode_trade(rs.getString("mode_trade"));
		obj.setQuantity(rs.getInt("quantity"));
		obj.setInitial_stocl_value(rs.getDouble("intial_stock_value"));
		obj.setBr_mf_ratio(rs.getDouble("br_mf_ratio"));
		obj.setBr_mf_rate(rs.getDouble("br_mr_rate"));
		obj.setSecurity_type(rs.getString("security_type"));
		obj.setTime_stamp(rs.getDate("timestamp"));
		return obj;
	}
}
