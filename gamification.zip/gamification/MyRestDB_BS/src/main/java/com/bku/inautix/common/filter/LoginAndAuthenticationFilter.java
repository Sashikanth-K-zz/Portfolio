package com.bku.inautix.common.filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

public class LoginAndAuthenticationFilter implements Filter {

//
	
		  public FilterConfig filterConfig;                                
			@Autowired
			private final String  ipAddress="172.24.34.90:8090";
			private final String loginurl="/MyRestDB/cxfservlet/jaxrs-server/commonservice/login/";
			private final String registerurl="/MyRestDB/cxfservlet/jaxrs-server/commonservice/register/";
			private final String forgotpasswordurl="MyRestDB/cxfservlet/jaxrs-server/service/forgotPassword/";
		  public void doFilter(final ServletRequest req,             
		                       final ServletResponse res,
		                       FilterChain chain)
		      throws java.io.IOException, javax.servlet.ServletException { 
			  HttpServletResponse response = (HttpServletResponse) res;
			  response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
		        response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		        response.setDateHeader("Expires", 0); // Proxies.
		    
		      HttpServletRequest request = (HttpServletRequest) req;
		     
		        if(request.getSession(false)!=null || request.getRequestURL().toString().contains(loginurl) ||request.getRequestURL().toString().contains(registerurl)||request.getRequestURL().toString().contains(forgotpasswordurl) )
		        {	chain.doFilter(req,res);
		     
		        }
		        else
		        {
		       // chain.doFilter(req,res);
		        	response.sendRedirect("http://" + ipAddress+ "/PortfolioGame/");
		        
		        }
		  } 

		  public void init(final FilterConfig filterConfig) {            
		    this.filterConfig = filterConfig;
		  } 

		  public void destroy() {                                     
		  }
		}


    //...

   