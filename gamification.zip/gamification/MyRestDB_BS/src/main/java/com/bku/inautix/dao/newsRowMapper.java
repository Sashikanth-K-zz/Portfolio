package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.NewsXML;
import com.bku.inautix.model.newsBean;

public class newsRowMapper implements RowMapper<NewsXML> {
	public NewsXML mapRow(ResultSet rs, int rowNum) throws SQLException {
		NewsXML obj = new NewsXML();		
		obj.setNews(rs.getString("news"));
		return obj;
	}
}
