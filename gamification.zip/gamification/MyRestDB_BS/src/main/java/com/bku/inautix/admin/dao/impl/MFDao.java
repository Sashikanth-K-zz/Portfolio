package com.bku.inautix.admin.dao.impl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.admin.bean.MFBean;
import com.bku.inautix.admin.dao.IMFDao;
import com.bku.inautix.admin.utility.InsertUtility;
import com.bku.inautix.model.ExcelFilePathBean;

public class MFDao implements IMFDao{

	public void  insertMF(JdbcTemplate jdbcTemplate,Logger log,ExcelFilePathBean excelFilePathBean)
	{
		log.info("\nEntered insertmf service");
			ArrayList<MFBean> mfBeanList = new ArrayList<MFBean>();
			InsertUtility.insertMF(mfBeanList,excelFilePathBean.getExcelFilePath(),log);

			

			
				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
						Types.VARCHAR, Types.FLOAT, Types.DATE };
				jdbcTemplate.update("delete from mf");
				for (MFBean mfBean : mfBeanList) {
try{
					 jdbcTemplate.update(
							"insert into mf values(?,?,?,?,?)", new Object[] {
									mfBean.getName(), mfBean.getSymbol(),
									mfBean.getCusip(), mfBean.getPrice(),
									new Date() }, types);
					log.info("\nInserted MF values");
}
catch(Exception e)
{
	e.printStackTrace();
}
				}

			

			
			log.info("\nReturning after inserting MF");
		
			
			
		}
		

}
