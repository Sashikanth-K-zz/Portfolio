package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="marketPrice")
public class marketPrice {
	
	public marketPrice(){}
	
	public marketPrice(String symbol,String name,float price,int beta) {
		this.symbol = symbol;
		this.name = name;
		this.price= price;
		this.beta=beta;
	}
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice(){
		return price;
	}
	public void setPrice(float price){
		this.price = price;
	}
	private String symbol;
	private String name;
	private float price;
	private int beta;
	public int getBeta() {
		return beta;
	}

	public void setBeta(int beta) {
		this.beta = beta;
	}

}