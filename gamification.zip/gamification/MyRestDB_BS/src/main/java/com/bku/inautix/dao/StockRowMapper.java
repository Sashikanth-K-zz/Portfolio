package com.bku.inautix.dao;


import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;


import com.bku.inautix.model.StockServiceBean;

public class StockRowMapper implements RowMapper<StockServiceBean> {
	

	
	public StockServiceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		StockServiceBean obj = new StockServiceBean();		
	
		obj.setStk_name(rs.getString(1));
		obj.setStk_symbol(rs.getString(2));
		obj.setStk_cusip(rs.getString(3));
		obj.setStk_price(rs.getFloat(4));
		obj.setStk_date(rs.getString(5));
		
		
		return obj; 
	}

}
