package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.SavingBean;

public class SavingBrokerRowMapper  implements RowMapper<SavingBean>{
	public SavingBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		SavingBean obj = new SavingBean();		
		obj.setBid(rs.getString("bid"));
		obj.setUid(rs.getString("uid"));
		obj.setDate(rs.getString("stamp"));
		return obj;
}







}
