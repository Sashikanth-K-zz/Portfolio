package com.bku.inautix.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

// Component Bean, this bean cannot be used for service

public class Stock {
	
	private List<String> Stock_name;
	private List<String> Stock_symbol;
	private List<String> CUSIP;
	private List<Float> price;
	private List<Integer> beta;
	private String date;
	
	
	public List<Integer> getBeta() {
		return beta;
	}
	public void setBeta(List<Integer> beta) {
		this.beta = beta;
	}
	
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<String> getStock_name() {
		return Stock_name;
	}
	public void setStock_name(List<String> stock_name) {
		Stock_name = stock_name;
	}
	public List<String> getStock_symbol() {
		return Stock_symbol;
	}
	public void setStock_symbol(List<String> stock_symbol) {
		Stock_symbol = stock_symbol;
	}
	public List<String> getCUSIP() {
		return CUSIP;
	}
	public void setCUSIP(List<String> cUSIP) {
		CUSIP = cUSIP;
	}
	public List<Float> getPrice() {
		return price;
	}
	public void setPrice(List<Float> price) {
		this.price = price;
	}
	
	

}
