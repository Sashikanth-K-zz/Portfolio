package com.bku.inautix.model;

import java.util.Date;

public class HoldingsUserBrkr {

	private String uid;
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	public String getMode_trade() {
		return mode_trade;
	}
	public void setMode_trade(String mode_trade) {
		this.mode_trade = mode_trade;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getInitial_stocl_value() {
		return initial_stocl_value;
	}
	public void setInitial_stocl_value(double initial_stocl_value) {
		this.initial_stocl_value = initial_stocl_value;
	}
	public double getBr_mf_ratio() {
		return br_mf_ratio;
	}
	public void setBr_mf_ratio(double br_mf_ratio) {
		this.br_mf_ratio = br_mf_ratio;
	}
	public double getBr_mf_rate() {
		return br_mf_rate;
	}
	public void setBr_mf_rate(double br_mf_rate) {
		this.br_mf_rate = br_mf_rate;
	}
	public String getSecurity_type() {
		return security_type;
	}
	public void setSecurity_type(String security_type) {
		this.security_type = security_type;
	}
	public Date getTime_stamp() {
		return time_stamp;
	}
	public void setTime_stamp(Date time_stamp) {
		this.time_stamp = time_stamp;
	}
	private String sid;
	private String bid;
	private String mode_trade;
	private int quantity;
	private double initial_stocl_value;
	private double br_mf_ratio;
	private double br_mf_rate;
	private String security_type;
	private Date time_stamp;
}
