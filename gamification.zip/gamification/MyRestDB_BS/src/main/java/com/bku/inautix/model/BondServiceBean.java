package com.bku.inautix.model;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="bond")
public class BondServiceBean {
	private Float marketInterest;
	public Float getMarketInterest() {
		return marketInterest;
	}
	public void setMarketInterest(Float marketInterest) {
		this.marketInterest = marketInterest;
	}
	private String bond_name;
	private String bond_symbol;
	private String CUSIP;
	private Float price;
	private String date;
	public BondServiceBean(){
		
	}
	public BondServiceBean(String bond_name, String bond_symbol, String cUSIP,
			Float price, String date) {
		super();
		this.bond_name = bond_name;
		this.bond_symbol = bond_symbol;
		CUSIP = cUSIP;
		this.price = price;
		this.date = date;
	}
	
	public String getBond_name() {
		return bond_name;
	}
	public void setBond_name(String bond_name) {
		this.bond_name = bond_name;
	}
	public String getBond_symbol() {
		return bond_symbol;
	}
	public void setBond_symbol(String bond_symbol) {
		this.bond_symbol = bond_symbol;
	}
	public String getCUSIP() {
		return CUSIP;
	}
	public void setCUSIP(String cUSIP) {
		CUSIP = cUSIP;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
	

}
