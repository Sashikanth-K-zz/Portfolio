package com.bku.inautix.service;

import javax.xml.bind.annotation.XmlRootElement;


//stupid problem being solved stupidly
@XmlRootElement
public class Data {
	public String value;
	public Data (){}
	public Data (String in) {
		value = in;
	}
}