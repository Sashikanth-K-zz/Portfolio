package com.bku.inautix.player.rowmapper;


import java.sql.ResultSet;
import java.sql.SQLException;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.MFPriceBean;



public class MFPriceRowMapper  implements RowMapper<MFPriceBean>{

public MFPriceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		MFPriceBean obj = new MFPriceBean();		
		obj.setPrice(rs.getFloat(2));
	
		obj.setMf_name(rs.getString("mf_name"));
		return obj;
}
}
