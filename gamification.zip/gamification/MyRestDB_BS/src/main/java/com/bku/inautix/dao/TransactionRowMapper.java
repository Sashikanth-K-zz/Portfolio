package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;




import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.Transaction;


public class TransactionRowMapper implements RowMapper<Transaction>
{
	public Transaction mapRow(ResultSet rs, int rowNum) throws SQLException {
		Transaction obj = new Transaction();		
		obj.setName(rs.getString("name"));
		obj.setGetDatetime(rs.getDate("getDatetime"));
		obj.setQuantity(rs.getInt("quantity"));
		obj.setPrice(rs.getFloat("price"));
		obj.setStatus(rs.getString("status"));
		obj.setNetvalue(rs.getInt("netvalue"));
		obj.setUid(rs.getString("uid"));
		obj.setMfr(rs.getFloat("marg_interest"));
		obj.setTimer(rs.getTimestamp("time_stamp"));
		obj.setMfrate(rs.getInt("mfr"));
		obj.setBid(rs.getString("bid"));
		obj.setTidvalue(rs.getInt("tid"));
		return obj;
	}
}
