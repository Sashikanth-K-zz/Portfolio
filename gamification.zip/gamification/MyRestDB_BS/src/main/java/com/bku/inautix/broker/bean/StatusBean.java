package com.bku.inautix.broker.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="statusbean")
public class StatusBean {
	String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
