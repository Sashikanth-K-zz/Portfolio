package com.bku.inautix.player.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.Bonds;


public class BondsRowMapper implements RowMapper<Bonds> {
	public Bonds mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		Bonds obj = new Bonds();		
		obj.setBond_name(rs.getString("bond_name"));
		return obj;
	}
}
