package com.bku.inautix.common.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="session")
public class SessionBean {
	private String id;
	private String type;
	private String name;
	
	public SessionBean()
	{
		
	}
public SessionBean(String id,String name,String type)
{
	this.id=id;
	this.name=name;
	this.type=type;
}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
