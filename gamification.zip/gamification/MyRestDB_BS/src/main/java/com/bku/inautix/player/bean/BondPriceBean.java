package com.bku.inautix.player.bean;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="BondPrice")
public class BondPriceBean {
	
	
	public BondPriceBean() {
		
	}
	public BondPriceBean(String bond_name, float bond_price) {
		super();
		this.bond_name = bond_name;
		this.bond_price = bond_price;
	}
	private String bond_name;
	private Float bond_price;
	public String getBond_name() {
		return bond_name;
	}
	public void setBond_name(String bond_name) {
		this.bond_name = bond_name;
	}
	public float getBond_price() {
		return bond_price;
	}
	public void setBond_price(float bond_price) {
		this.bond_price = bond_price;
	}
	
}
