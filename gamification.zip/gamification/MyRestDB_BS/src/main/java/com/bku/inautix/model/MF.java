package com.bku.inautix.model;

import java.util.List;

public class MF {

	private List<String> MF_name;
	private List<String> Ticker_symbol;
	private List<String> CUSIP;
	private List<Float> price;
	private String date;
	
	
	public List<String> getMF_name() {
		return MF_name;
	}
	public void setMF_name(List<String> mF_name) {
		MF_name = mF_name;
	}
	public List<String> getTicker_symbol() {
		return Ticker_symbol;
	}
	public void setTicker_symbol(List<String> ticker_symbol) {
		Ticker_symbol = ticker_symbol;
	}
	public List<String> getCUSIP() {
		return CUSIP;
	}
	public void setCUSIP(List<String> cUSIP) {
		CUSIP = cUSIP;
	}
	public List<Float> getPrice() {
		return price;
	}
	public void setPrice(List<Float> price) {
		this.price = price;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	
}
