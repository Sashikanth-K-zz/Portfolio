package com.bku.inautix.player.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.Bonds;
import com.bku.inautix.model.MFNameBean;

public class MFNameRowMapper implements RowMapper<MFNameBean> {
	public MFNameBean mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		MFNameBean obj = new MFNameBean();	
		obj.setMf_name(rs.getString("mf_name"));
		return obj;

}
}
