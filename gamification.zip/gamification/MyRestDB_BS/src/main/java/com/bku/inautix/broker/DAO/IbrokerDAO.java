package com.bku.inautix.broker.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bku.inautix.broker.bean.BrokerValuesBean;
import com.bku.inautix.broker.bean.StatusBean;
public interface IbrokerDAO 
{
	public void saveBroke(String broker_id,String broker_name,float futures, float mf,float equity,float fx,float bond,String mf_ratio,String mf_rate,JdbcTemplate s);
	public StatusBean saveBalance(int broker_id,String balance,JdbcTemplate s);
	public StatusBean publishBroker(int broker_id,JdbcTemplate s);
	public List<BrokerValuesBean> ViewAllBrokers(int broker_id,JdbcTemplate s);
	public List<BrokerValuesBean> ViewBrokers(int broker_id,String status,JdbcTemplate s);
	}
