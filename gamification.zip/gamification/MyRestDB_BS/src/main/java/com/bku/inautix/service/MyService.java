package com.bku.inautix.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bku.inautix.broker.bean.AdviceBean;
import com.bku.inautix.broker.bean.BrokerValuesBean;
import com.bku.inautix.broker.bean.ForgotPwdBean;
import com.bku.inautix.broker.bean.Losegain;
import com.bku.inautix.broker.bean.clientreport1;
import com.bku.inautix.broker.rowMapper.AdviceRowMapper;
import com.bku.inautix.broker.rowMapper.BrokerNameRowMapper;
import com.bku.inautix.broker.rowMapper.ForgotPwdRowMapper;
import com.bku.inautix.broker.rowMapper.LosegainRowMapper;
import com.bku.inautix.broker.rowMapper.clientrowmapper;
import com.bku.inautix.component.InsertUtility;
import com.bku.inautix.dao.BondRowMapper;
import com.bku.inautix.dao.DashboardRowMapper;
import com.bku.inautix.dao.EmployeeRowMapper;
import com.bku.inautix.dao.EquitiesBeanXmlRowMapper;
import com.bku.inautix.dao.EquitiesRowMapper;
import com.bku.inautix.dao.EquityRowMapper;
import com.bku.inautix.dao.FXNameRowMapper;
import com.bku.inautix.dao.FXPriceRowMapper;
import com.bku.inautix.dao.FXRowMapper;
import com.bku.inautix.dao.HistoryRowMapper;
import com.bku.inautix.dao.HoldingRowMapper;
import com.bku.inautix.dao.HoldingsUserBrkrRowMapper;
import com.bku.inautix.dao.MFRowMapper;
import com.bku.inautix.dao.MosttradedRowMapper;
import com.bku.inautix.dao.PersonRowMapper;
import com.bku.inautix.dao.SavingBrokerRowMapper;
import com.bku.inautix.dao.SecuritiesRowMapper;
import com.bku.inautix.dao.StockRowMapper;
import com.bku.inautix.dao.StocksRowMapper;
import com.bku.inautix.dao.TransactionRowMapper;
import com.bku.inautix.dao.UserRowMapper;
import com.bku.inautix.dao.marketPriceRowMapper;
import com.bku.inautix.dao.newsRowMapper;
import com.bku.inautix.model.BondPriceBean;
import com.bku.inautix.model.BondServiceBean;
import com.bku.inautix.model.Bonds;
import com.bku.inautix.model.Dashboard;
import com.bku.inautix.model.EmployeeRow;
import com.bku.inautix.model.Equities;
import com.bku.inautix.model.EquitiesBeanXml;
import com.bku.inautix.model.EquityBean;
import com.bku.inautix.model.ExcelFilePathBean;
import com.bku.inautix.model.FXNameBean;
import com.bku.inautix.model.FXPriceBean;
import com.bku.inautix.model.FXServiceBean;
import com.bku.inautix.model.HoldingBean;
import com.bku.inautix.model.HoldingsUserBrkr;
import com.bku.inautix.model.IpAddressBean;
import com.bku.inautix.model.MFNameBean;
import com.bku.inautix.model.MFPriceBean;
import com.bku.inautix.model.MFServiceBean;
import com.bku.inautix.model.Mosttraded;
import com.bku.inautix.model.NewsXML;
import com.bku.inautix.model.Person;
import com.bku.inautix.model.SavingBean;
import com.bku.inautix.model.SecuritiesBean;
import com.bku.inautix.model.StockServiceBean;
import com.bku.inautix.model.Stocks;
import com.bku.inautix.model.Transaction;
import com.bku.inautix.model.TransactionHistory;
import com.bku.inautix.model.User;
import com.bku.inautix.model.marketPrice;
import com.bku.inautix.player.rowmapper.BondPriceBeanRowMapper;
import com.bku.inautix.player.rowmapper.BondsRowMapper;
import com.bku.inautix.player.rowmapper.MFNameRowMapper;
import com.bku.inautix.player.rowmapper.MFPriceRowMapper;

@SuppressWarnings("unused")
@Service("ServiceBean")
@Path("service")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MyService {
	float o_net;

	@GET
	@Path("wish/{name}/{nam}")
	@Produces(MediaType.APPLICATION_JSON)
	public Data process(@PathParam("name") int name,
			@PathParam("nam") String nam) {
		return new Data("Happy Morning " + name + "," + nam);
	}

	@Autowired
	private IpAddressBean IpAddress;
	@Autowired
	private ExcelFilePathBean excelFilePathBean;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public int getDateDifference(Date currdate, Date trandate) {
		long duration = currdate.getTime() - trandate.getTime();
		int diffInDays = (int) TimeUnit.MILLISECONDS.toDays(duration);
		return diffInDays;
	}

	public float getMarginInterestAmount(int numberOfDays, float brokerShare,
			float brokerInterest) {
		return (numberOfDays * brokerShare * brokerInterest / 360);
	}

	public boolean isMarginfund(String user_name, String security_name) {
		List l = jdbcTemplate
				.query("select * from transaction1 where uid = ? and name = ? and marg_interest is NOT NULL",
						new Object[] { user_name, security_name }, // in
																	// parameters
						new TransactionRowMapper());
		if (l.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private static Logger log;

	private String username;

	public MyService() {
		log = Logger.getLogger(MyService.class.getName());
	}

	@GET
	@Path("Person/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Person getPerson(@PathParam("id") Integer id) {
		Person obj = null;
		try {
			obj = jdbcTemplate.queryForObject(
					"select * from mytable where id = ?", new Object[] { id }, // in
																				// parameter
					new PersonRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	@GET
	@Path("Persons")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Person> getPersons() {
		List<Person> list = null;
		try {
			list = jdbcTemplate.query("select * from mytable", new Object[] {}, // in
																				// parameters
					new PersonRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		System.out.println(list.size());
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("insperson/{id}/{name}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Data insertPersons(@PathParam("id") int id,
			@PathParam("name") String name) {

		try {

			JdbcTemplate template = new JdbcTemplate(dataSource);

			int[] types = new int[] { Types.INTEGER, Types.VARCHAR };

			int row = template.update("insert into mytable values(?,?)",
					new Object[] { id, name }, types);
			System.out.println("Row inserted is " + row);

		} catch (Throwable fault) {

			System.out.println("Error inserting : ");
			fault.printStackTrace();

		}
		return new Data("Values inserted are " + id + " , " + name);
		// if we return null here, it sends back a 404. Good.

	}

	@GET
	@Path("Stocks")
	@Produces(MediaType.APPLICATION_JSON)
	public List<StockServiceBean> getStocks() {
		List<StockServiceBean> list = null;
		try {
			list = jdbcTemplate.query("select * from equities",
					new Object[] {}, // in parameters
					new StockRowMapper());
		} catch (Throwable fault) {

			log.info(fault.getStackTrace());

		}
		/*
		 * for(int i=0; i< obj.size() ; i++) {
		 * System.out.println(obj.get(i).getStock_name());
		 * System.out.println(obj.get(i).getStock_symbol());
		 * System.out.println(obj.get(i).getCUSIP());
		 * System.out.println(obj.get(i).getPrice());
		 * System.out.println(obj.get(i).getDate());
		 * 
		 * }
		 */
		System.out.println(" Got the equities, returning to you buddy");

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("mutualprices/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<MFServiceBean> getmutualprice(
			@PathParam("datetime") Date datetime) {
		List<MFServiceBean> list = null;
		try {
			list = jdbcTemplate.query("select * from mf", new Object[] {}, // in
																			// parameters
					new MFRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		System.out.println(" Got the Bond, returning to you buddy");

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("foreignPrices/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<FXServiceBean> getforeignprice(
			@PathParam("datetime") Date datetime) {
		List<FXServiceBean> list = null;
		try {
			list = jdbcTemplate.query("select * from fx", new Object[] {}, // in
																			// parameters
					new FXRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		System.out.println(" Got the Bond, returning to you buddy");

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("MF")
	@Produces(MediaType.APPLICATION_JSON)
	public List<MFServiceBean> getMFS() {
		List<MFServiceBean> list = null;
		try {
			list = jdbcTemplate.query("select * from mf", new Object[] {}, // in
																			// parameters
					new MFRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		/*
		 * for(int i=0; i< obj.size() ; i++) {
		 * System.out.println(obj.get(i).getStock_name());
		 * System.out.println(obj.get(i).getStock_symbol());
		 * System.out.println(obj.get(i).getCUSIP());
		 * System.out.println(obj.get(i).getPrice());
		 * System.out.println(obj.get(i).getDate());
		 * 
		 * }
		 */
		System.out.println(" Got the MF, returning to you buddy");

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("FX")
	@Produces(MediaType.APPLICATION_JSON)
	public List<FXServiceBean> getFX() {
		List<FXServiceBean> list = null;
		try {
			list = jdbcTemplate.query("select * from fx", new Object[] {}, // in
																			// parameters
					new FXRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		/*
		 * for(int i=0; i< obj.size() ; i++) {
		 * System.out.println(obj.get(i).getStock_name());
		 * System.out.println(obj.get(i).getStock_symbol());
		 * System.out.println(obj.get(i).getCUSIP());
		 * System.out.println(obj.get(i).getPrice());
		 * System.out.println(obj.get(i).getDate());
		 * 
		 * }
		 */
		System.out.println(" Got the FX, returning to you buddy");

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("bond/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<BondServiceBean> getBond(@PathParam("datetime") Date datetime) {
		List<BondServiceBean> list = null;
		try {
			list = jdbcTemplate.query("select * from bonds", new Object[] {}, // in
																				// parameters
					new BondRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		System.out.println(" Got the Bond, returning to you buddy");

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("equitysell/{name}/{price}/{getDatetime}/{quantity}/{uid}/{security_type}/{equities}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Transaction> sellEquity(@PathParam("name") String name,
			@PathParam("price") Float price,
			@PathParam("getDatetime") Date getDatetime,
			@PathParam("quantity") Integer quantity,
			@PathParam("uid") String uid,
			@PathParam("security_type") String security_type,
			@PathParam("equities") String equties) {
		List<Transaction> list = null;
		List<EquityBean> list1 = null;
		List<SavingBean> list2 = null;
		List<SecuritiesBean> list3 = null;
		/*
		 * returns the number of rows that contains the given uid, if it is 0
		 * then the uid doesnt exist in holding_table else it exists in
		 * holding_table
		 */

		try {
			list2 = jdbcTemplate.query(
					"select * from savingbroker where uid=?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());
			String b_id = null;
			for (SavingBean eb : list2)
				b_id = eb.getBid();

			// To query the DB for JSON output
			list1 = jdbcTemplate
					.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, // in parameters
							new EquityRowMapper());
			list3 = jdbcTemplate
					.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, // in parameters
							new SecuritiesRowMapper());
			String marg_ratio = null;
			String marg_rate = null;
			String br_rate = null;
			for (EquityBean eb1 : list1)
				marg_ratio = eb1.getMarg_ratio();
			for (EquityBean eb1 : list1)
				marg_rate = eb1.getMarg_rate();
			for (SecuritiesBean eb1 : list3)
				br_rate = eb1.getEquities();
			// System.out.println("Broker contribution:"+br_share);
			System.out.println(o_net);
			System.out.println(marg_ratio);
			System.out.println(marg_rate);
			System.out.println(br_rate);
			String[] parts = marg_ratio.split(":");
			String[] parts1 = marg_rate.split("%");
			// String[] parts2 = br_rate.split("%");
			int part1 = Integer.parseInt(parts[0]); // user share
			int part2 = Integer.parseInt(parts[1]); // broker share
			int rate = Integer.parseInt(parts1[0]); // Broker interest rate
			// int rate1=Integer.parseInt(parts2[0]); //Brokerage rate
			float br_rate1 = Float.parseFloat(br_rate);
			System.out.println(br_rate1);
			System.out.println("hi" + part1 + part2);

			int uid_present = jdbcTemplate.queryForObject(
					"select count(*) from holding where uid=? and name=?",
					new Object[] { uid, name }, Integer.class);
			int holding_quantity = this.jdbcTemplate.queryForObject(
					"select quantity from holding where uid=? and name=?",
					new Object[] { uid, name }, Integer.class);

			// the new row with this uid does not exist

			if (uid_present > 0)

			{
				// the number of shares he holds is greater than number of
				// shares he is going to sell
				if (holding_quantity >= quantity) {
					int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
							Types.DATE, Types.INTEGER, Types.FLOAT,
							Types.FLOAT, Types.VARCHAR, Types.FLOAT };
					float netvalue = quantity * price;
					float br_share = (float) (o_net * (part2 * .01));
					float br_int = (float) (br_share * (rate * .01));
					float br_rate2 = (float) (netvalue * (br_rate1 * .01));
					float user_share = (float) (netvalue - (br_share + br_rate2));
					System.out.println("Broker share" + br_share);
					
					System.out.println("Broker share percent" + br_int);
					System.out.println("Brokerage percent" + br_rate2);
					// Selling Transaction into Transaction1_table
					jdbcTemplate.update("insert into transaction1(" + "tid,"
							+ "name," + "uid," + "getDatetime," + "quantity,"
							+ "price," + "netvalue," + "status,"
							+ "security_type," + " br_amount)"
							+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,?,"
							+ "'S',?,?)", new Object[] { name, uid,
							getDatetime, quantity, price, netvalue,
							security_type, br_rate2 },// in parameter

							types); // in parameter

					// subtract the quantity in holding_table after you sell the
					// shares
					int holding5 = jdbcTemplate
							.queryForObject(
									"select quantity from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					int holding6 = holding5 - quantity;
					// subtract the holding in holding_table after you sell the
					// shares
					int holding7 = jdbcTemplate
							.queryForObject(
									"select holding from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					float holding8 = holding7 - user_share;
					// update holding_table after sell
					jdbcTemplate
							.update("update holding set quantity=?,holding=? where uid=? and name=?",
									new Object[] { holding6, holding8, uid,
											name });
					// if holding is 0 then delete that entry from holding table
					if (holding8 == 0) {
						jdbcTemplate.update(
								"delete from holding where uid=? and name=?",
								new Object[] { uid, name });
					}
					float br_holding = jdbcTemplate
							.queryForObject(
									"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { b_id, b_id }, Float.class);
					System.out.println("THE BROKER SHARE" + br_share);
					br_holding = br_holding + br_rate2 + br_share;
					// incrementing balance in balance_table
					float holding9 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					float holding10 = holding9 + user_share;
					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding10, uid });
					int i = jdbcTemplate
							.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { br_holding, b_id, b_id });
					System.out.println("success" + i);
					// display transaction1_table
					list = jdbcTemplate.query(
							"select * from transaction1 where getDatetime = ?",
							new Object[] { getDatetime },// in parameter
							new TransactionRowMapper());
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding10, uid });
					jdbcTemplate
							.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
									new Object[] {});
				}
			}
		}

		catch (NullPointerException e) {

			// fault.printStackTrace();
			list = null;
			return list;
		} catch (Throwable fault) {

			log.info("ERROR due to no data in holding for the user : " + uid);
		}

		getAutoupdate();
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	
	
	public void dosell(String name, Float price,Integer quantity, Date date, String uid, String security_type, String equities){
		List<HoldingsUserBrkr> holdingsList = null;
		int count = 0;
		int sizeMfs = 0;
		holdingsList = jdbcTemplate.query( "select * from holdings_user_brkr where uid = ? and sid = ? order by br_mr_rate desc",
				new Object[] {uid,name},
				new HoldingsUserBrkrRowMapper());
		sizeMfs = holdingsList.size();
		int myquantity = quantity;
		int i=0;
		for(;myquantity>0;){
			int tempQuantity = holdingsList.get(i).getQuantity();
			String mybid = holdingsList.get(i).getBid();
			if(tempQuantity >= myquantity){
				tempQuantity -= myquantity;
			 jdbcTemplate.update("update holdings_user_brkr set quantity= ? where uid=? and bid=?",
						                new Object[]{tempQuantity,uid,mybid});
				myquantity = 0;
				break;
			}
			else{
				myquantity -= tempQuantity;
				int j =  jdbcTemplate.update("update holdings_user_brkr set quantity=0 where uid=? and bid=?",
		                new Object[]{uid,mybid});
			}
			i++;
		}
		
		
		int j =  jdbcTemplate.update("delete from holdings_user_brkr  where quantity = 0"
              );
		
		
		
		
		//int tempQuantity = holdingsList.get(i).getQuantity();
		
		
		
	}
	// ************** Ashwin's COMMON SELL MODULE
	// ATTEMPT************************

	@GET
	@Path("equitysell1/{name}/{price}/{getDatetime}/{quantity}/{uid}/{security_type}/{equities}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Transaction> sellEquity1(@PathParam("name") String name,
			@PathParam("price") Float price,
			@PathParam("getDatetime") Date getDatetime,
			@PathParam("quantity") Integer quantity,
			@PathParam("uid") String uid,
			@PathParam("security_type") String security_type,
			@PathParam("equities") String equties) {
		List<Transaction> list = null;
		List<EquityBean> list1 = null;
		List<SavingBean> list2 = null;
		List<SecuritiesBean> list3 = null;
		List<HoldingsUserBrkr> holdingsList = null;
		float brokers_share = 0;
		float netvalue = quantity * price;
		o_net = netvalue;
		/*
		 * returns the number of rows that contains the given uid, if it is 0
		 * then the uid doesnt exist in holding_table else it exists in
		 * holding_table
		 */
		System.out.println("I am in my edit");
		System.out.println(uid);
		try {
			
			//dosell(String name, Double price,Integer quantity, Date date, String uid, String security_type, String equities){
			dosell(name,price,quantity,getDatetime,uid,security_type,equties);
			int soldQuantity = 0;
			float something = 0;
			int remainingQuantity = quantity;
			System.out.println(remainingQuantity);
			int i = 0;
			int count = 0;
			int sizeMfs = 0;
			int myQuantity  = quantity;
			System.out.println("Security type main" + security_type);
			// Req
		//	holdingsList = jdbcTemplate.query( "select * from holdings_user_brkr where uid = ? and name = ? order by br_mr_rate desc",
			//				new Object[] {uid,name},
			//				new HoldingsUserBrkrRowMapper());
			
			List mfs = jdbcTemplate
					.query("select * from t_transaction where uid = ? and name = ? order by mfr desc",
							new Object[] { uid, name }, // in parameters
							new TransactionRowMapper());
			sizeMfs = mfs.size();
			System.out.println(mfs.size());
			int remQuan = jdbcTemplate
					.queryForObject(
							"select sum(quantity) from t_transaction where uid = ? and name = ?",
							new Object[] { uid, name }, // in parameters
							Integer.class);
			System.out.println("remQuan" + " " + remQuan);
			while (remainingQuantity > 0 && i < mfs.size()) {
				System.out.println("am i in while?");
				Timestamp t = ((Transaction) mfs.get(i)).getTimer();
				System.out.println("timeer" + t);
				int mfr = ((Transaction) mfs.get(i)).getMfrate();
				System.out.println("mfr" + mfr);
				int tid = ((Transaction) mfs.get(i)).getTidvalue();
				System.out.println("Tid outside" + tid);
				float pr = ((Transaction) mfs.get(i)).getPrice();
				System.out.println("Price" + pr);
				if (mfr != 0) {
					Date newdate = new Date(t.getTime());
					Timestamp stamp = new Timestamp(System.currentTimeMillis());
					Date date = new Date(stamp.getTime());
					int diffindays = getDateDifference(date, newdate) + 1;
					String bid = ((Transaction) mfs.get(i)).getBid();
					String ratio = jdbcTemplate
							.queryForObject(
									"select margin_fund_ratio from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { bid, bid }, String.class);
					Double rate = jdbcTemplate
							.queryForObject(
									"select mf_rate from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { bid, bid }, Double.class);
					Double br_rate1 = jdbcTemplate
							.queryForObject(
									"select equities_rate from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { bid, bid }, Double.class);
					String[] parts = ratio.split(":");
					int part1 = Integer.parseInt(parts[0]);
					int part2 = Integer.parseInt(parts[1]);
					float nvalue = quantity * pr;
					float prd = price - pr;
					float missing = prd * quantity;
					something += (diffindays * part2 * mfr * 0.01 * nvalue) / 365;
					System.out.println("something " + something);
					int mainquantity = ((Transaction) mfs.get(i)).getQuantity();
					System.out.println("Main quantity is" + mainquantity);
					int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
							Types.DATE, Types.INTEGER, Types.FLOAT,
							Types.VARCHAR, Types.FLOAT, Types.FLOAT };
					// float netvalue = quantity * price;
					float brokerfee = (float) (netvalue * (rate * .01));
					float usershare = netvalue - brokerfee;
					System.out.println("Broker Fee" + brokerfee);
					System.out.println("usershare" + usershare);

					// Selling Transaction into Transaction1_table

					if (remainingQuantity >= mainquantity) {
						System.out.println("Im in");

						float br_share = (float) (o_net * (part2 * .01));
						float br_int = (float) (br_share * (rate * .01));
						float br_rate2 = (float) (nvalue * (br_rate1 * .01));
						float user_share = (float) (nvalue - (br_share + br_rate2));
						remainingQuantity -= mainquantity;
						int holding5 = jdbcTemplate
								.queryForObject(
										"select quantity from holding where uid=? and name=?",
										new Object[] { uid, name },
										Integer.class);
						int holding6 = holding5 - mainquantity;
						// subtract the holding in holding_table after you sell
						// the
						// shares
						
					//	int tempQuantity = holdingsList.get(i).getQuantity();
						
						int holding7 = jdbcTemplate
								.queryForObject(
										"select holding from holding where uid=? and name=?",
										new Object[] { uid, name },
										Integer.class);
						System.out.println("Holding 7 which is current "
								+ holding7);
						float holding8 = holding7 - missing - user_share
								- br_share;
						float sweep = something;
						jdbcTemplate
								.update("insert into transaction1("
										+ "tid,"
										+ "name,"
										+ "uid,"
										+ "getDatetime,"
										+ "quantity,"
										+ "price,"
										+ "netvalue,"
										+ "status,"
										+ "security_type,"
										+ " br_amount,"
										+ "marg_interest)"
										+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,"
										+ usershare + "," + "'S',?,?,?)",
										new Object[] { name, uid, getDatetime,
												quantity, price, security_type,
												brokerfee, sweep },// in
																	// parameter

										types);
						// update holding_table after sell
						jdbcTemplate
								.update("update holding set quantity=?,holding=? where uid=? and name=?",
										new Object[] { holding6, holding8, uid,
												name });
						// if holding is 0 then delete that entry from holding
						// table
						if (holding8 == 0) {
							jdbcTemplate
									.update("delete from holding where uid=? and name=?",
											new Object[] { uid, name });
						}
						float br_holding = jdbcTemplate
								.queryForObject(
										"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
										new Object[] { bid, bid }, Float.class);
						System.out.println("BROKER SHARE" + br_share);
						br_holding = br_holding + br_rate2 + something
								+ br_share;
						// incrementing balance in balance_table
						float holding9 = jdbcTemplate.queryForObject(
								"select balance from balance where uid=?",
								new Object[] { uid }, Integer.class);
						float holding10 = holding9 + user_share;
						jdbcTemplate.update(
								"update balance set balance=? where uid=?",
								new Object[] { holding10, uid });
						int irp = jdbcTemplate
								.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
										new Object[] { br_holding, bid, bid });
						System.out.println("success" + irp);
						// display transaction1_table
						list = jdbcTemplate
								.query("select * from t_transaction where getDatetime = ?",
										new Object[] { getDatetime },// in
																		// parameter
										new TransactionRowMapper());
						jdbcTemplate
								.update("update user_screen set user_screen.balance=? where user_screen.id=?",
										new Object[] { holding10, uid });
						jdbcTemplate
								.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
										new Object[] {});

						jdbcTemplate.update(
								"delete from t_transaction where tid=?",
								new Object[] { tid });

					} else {
						System.out.println("Im in else");

						float br_share = (float) (o_net * (part2 * .01));
						float br_int = (float) (br_share * (rate * .01));
						float br_rate2 = (float) (nvalue * (br_rate1 * .01));
						float user_share = (float) (nvalue - (br_share + br_rate2));
						mainquantity = mainquantity - remainingQuantity;
						System.out.println("New quantity" + mainquantity);

						int holding5 = jdbcTemplate
								.queryForObject(
										"select quantity from holding where uid=? and name=?",
										new Object[] { uid, name },
										Integer.class);
						int holding6 = holding5 - remainingQuantity;
						jdbcTemplate
								.update("update t_transaction set quantity = ? where tid = ?",
										new Object[] { mainquantity, tid });
						// subtract the holding in holding_table after you sell
						// the
						// shares
						remainingQuantity = 0;
						System.out.println("tid" + tid);
						int holding7 = jdbcTemplate
								.queryForObject(
										"select holding from holding where uid=? and name=?",
										new Object[] { uid, name },
										Integer.class);
						float holding8 = holding7 - missing - user_share
								- br_share;
						float sweep = something;
						jdbcTemplate
								.update("insert into transaction1("
										+ "tid,"
										+ "name,"
										+ "uid,"
										+ "getDatetime,"
										+ "quantity,"
										+ "price,"
										+ "netvalue,"
										+ "status,"
										+ "security_type,"
										+ " br_amount,"
										+ "marg_interest)"
										+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,"
										+ usershare + "," + "'S',?,?,?)",
										new Object[] { name, uid, getDatetime,
												quantity, price, security_type,
												brokerfee, sweep },// in
																	// parameter

										types);
						// update holding_table after sell
						jdbcTemplate
								.update("update holding set quantity=?,holding=? where uid=? and name=?",
										new Object[] { holding6, holding8, uid,
												name });
						// if holding is 0 then delete that entry from holding
						// table
						if (holding8 == 0) {
							jdbcTemplate
									.update("delete from holding where uid=? and name=?",
											new Object[] { uid, name });
						}
						float br_holding = jdbcTemplate
								.queryForObject(
										"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
										new Object[] { bid, bid }, Float.class);
						br_holding = br_holding + br_rate2 + something
								+ br_share;
						// incrementing balance in balance_table
						float holding9 = jdbcTemplate.queryForObject(
								"select balance from balance where uid=?",
								new Object[] { uid }, Integer.class);
						float holding10 = holding9 + user_share;
						jdbcTemplate.update(
								"update balance set balance=? where uid=?",
								new Object[] { holding10, uid });
						int irp = jdbcTemplate
								.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
										new Object[] { br_holding, bid, bid });
						System.out.println("success" + irp);
						// display transaction1_table
						list = jdbcTemplate
								.query("select * from transaction1 where getDatetime = ?",
										new Object[] { getDatetime },// in
																		// parameter
										new TransactionRowMapper());
						jdbcTemplate
								.update("update user_screen set user_screen.balance=? where user_screen.id=?",
										new Object[] { holding10, uid });
						jdbcTemplate
								.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
										new Object[] {});
					}
				} else {
					List<Transaction> listdup = null;
					List<SavingBean> listdup1 = null;
					List<SecuritiesBean> listdup2 = null;
					/*
					 * returns the number of rows that contains the given uid,
					 * if it is 0 then the uid doesnt exist in holding_table
					 * else it exists in holding_table
					 */
					System.out.println("Sec type" + security_type);

					if (security_type.equals("FX")) {
						System.out.println("inside FX");
						name = name.replace("-", "/");
					}
					if (security_type.equals("Bonds")) {
						System.out.println("inside Bonds");
						name = name.replace("-", "%");
					}
					int uid_present = jdbcTemplate
							.queryForObject(
									"select count(*) from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					int holding_quantity = this.jdbcTemplate
							.queryForObject(
									"select quantity from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					listdup1 = jdbcTemplate.query(
							"select * from savingbroker where uid=?",
							new Object[] { uid }, // in parameters
							new SavingBrokerRowMapper());
					String b_id = null;
					for (SavingBean eb : listdup1)
						b_id = eb.getBid();
					listdup2 = jdbcTemplate
							.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { b_id, b_id }, // in
																	// parameters
									new SecuritiesRowMapper());
					String br_rate = null;
					for (SecuritiesBean eb1 : listdup2)
						br_rate = eb1.getEquities();
					/*
					 * for (BrokerValuesBean eb1 : list2) br_rate =
					 * eb1.getEquities();
					 */
					// the new row with this uid does not exist
					System.out.println(br_rate);
					// String[] parts2 = br_rate.split("%");
					// int rate1=Integer.parseInt(parts2[0]);
					// System.out.println("hi"+rate1);
					float rate = Float.parseFloat(br_rate);
					System.out.println(rate);
					if (uid_present > 0)

					{
						// the number of shares he holds is greater than number
						// of
						// shares he is going to sell
						if (holding_quantity >= remainingQuantity) {
							int[] types = new int[] { Types.VARCHAR,
									Types.VARCHAR, Types.DATE, Types.INTEGER,
									Types.FLOAT, Types.VARCHAR, Types.FLOAT };
							float nvalue = remainingQuantity * price;
							float brokerfee = (float) (nvalue * (rate * .01));
							float user_share = nvalue - brokerfee;
							System.out.println("Broker Fee" + brokerfee);
							System.out.println("usershare" + user_share);

							// Selling Transaction into Transaction1_table
							jdbcTemplate
									.update("insert into transaction1("
											+ "tid,"
											+ "name,"
											+ "uid,"
											+ "getDatetime,"
											+ "quantity,"
											+ "price,"
											+ "netvalue,"
											+ "status,"
											+ "security_type,"
											+ " br_amount)"
											+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,"
											+ user_share + "," + "'S',?,?)",
											new Object[] { name, uid,
													getDatetime, quantity,
													price, security_type,
													brokerfee },// in parameter

											types); // in parameter

							// subtract the quantity in holding_table after you
							// sell the
							// shares
							int holding5 = jdbcTemplate
									.queryForObject(
											"select quantity from holding where uid=? and name=?",
											new Object[] { uid, name },
											Integer.class);
							int holding6 = holding5 - remainingQuantity;

							// subtract the holding in holding_table after you
							// sell the
							// shares
							int holding7 = jdbcTemplate
									.queryForObject(
											"select holding from holding where uid=? and name=?",
											new Object[] { uid, name },
											Integer.class);
							float holding8 = holding7 - netvalue;

							// update holding_table after sell
							jdbcTemplate
									.update("update holding set quantity=?,holding=? where uid=? and name=?",
											new Object[] { holding6, holding8,
													uid, name });
							jdbcTemplate
									.update("update t_transaction set quantity=? where tid=?",
											new Object[] { holding6, tid });
							if (holding6 == 0) {
								jdbcTemplate
										.update("delete from t_transaction where tid=?",
												new Object[] { tid });
							}
							// if holding is 0 then delete that entry from
							// holding table
							if (holding8 == 0) {
								jdbcTemplate
										.update("delete from holding where uid=? and name=?",
												new Object[] { uid, name });
							}
							float br_holding = jdbcTemplate
									.queryForObject(
											"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
											new Object[] { b_id, b_id },
											Float.class);
							br_holding = br_holding + brokerfee;
							System.out.println("Broker updated holding"
									+ br_holding);

							// incrementing balance in balance_table
							float holding9 = jdbcTemplate.queryForObject(
									"select balance from balance where uid=?",
									new Object[] { uid }, Float.class);

							float holding10 = holding9 + user_share;
							System.out.println("Current holding" + holding9);
							System.out.println("New holding" + holding10);
							jdbcTemplate.update(
									"update balance set balance=? where uid=?",
									new Object[] { holding10, uid });
							int is = jdbcTemplate
									.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
											new Object[] { br_holding, b_id,
													b_id });
							System.out.println("success" + is);

							// display transaction1_table
							list = jdbcTemplate
									.query("select * from transaction1 where getDatetime = ?",
											new Object[] { getDatetime },// in
																			// parameter
											new TransactionRowMapper());
							jdbcTemplate
									.update("update user_screen set user_screen.balance=? where user_screen.id=?",
											new Object[] { holding10, uid });
							jdbcTemplate
									.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
											new Object[] {});
						}
					}

				}
				i++;
			}
			/*
			 * for(int i=0;i<mfs.size();i++) { System.out.println(((Transaction)
			 * mfs.get(i)).getQuantity()); while(quantity>soldQuantity) { int
			 * quantity1 = ((Transaction) mfs.get(i)).getQuantity(); float mfr1
			 * = ((Transaction) mfs.get(i)).getMfr(); Timestamp t =
			 * ((Transaction) mfs.get(i)).getTimer(); Timestamp t1 = new
			 * Timestamp(System.currentTimeMillis()); Date date = new
			 * Date(t.getTime()); Date date1 = new Date(t1.getTime());
			 * System.out.println(mfs); //float costtobededucted = quantity *
			 * getDateDifference(date1,date) * mfr1 * } }
			 */
		}

		catch (Exception e) {

			// fault.printStackTrace();
			System.out.println(e.toString());
			list = null;
			return list;
		}
		getAutoupdate();
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// ************* End of Ashwin's edit ***************************
	// ******************************************************buy
	// equity*********************************************//

	//*********************************************************************//
	// update_Holdings_mf
	
	public void update_Holdings_mf(String name, Float price, Date date, Integer quantity, String uid, String security_type, String equties,String mode){
		
		
		System.out.println("in \"Do Something\" ---- helooo -- enter ");
		float  total_stock_value = price * quantity;
		double  broker_share =0;
		double  user_share = 0;
		float  broker_fee_rate = 0;
		float  margin_fund_rate = 0;
		float  user_ratio = 0;
		float  broker_ratio = 0;
		float user_balance = 0;
		float broker_balance = 0;
		float broker_fee = 0; 
		String broker_id = "";
		
		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.DATE,
				Types.INTEGER, Types.FLOAT, Types.FLOAT, Types.VARCHAR,
				Types.FLOAT, Types.FLOAT, Types.INTEGER, Types.VARCHAR,Types.FLOAT };
		int[] types1 = new int[] { Types.VARCHAR, Types.VARCHAR,
				Types.INTEGER, Types.FLOAT, Types.VARCHAR };
		
		
		List<Transaction> transbean_list = null;
		List<EquityBean> equitybean_list = null;
		List<SavingBean> savingbean_list = null;
		List<SecuritiesBean> securitybean_list = null;
		
		
		
		
		
		
		
		
		
		savingbean_list = jdbcTemplate.query(
							"select * from savingbroker where uid=?",
							new Object[] { uid }, // in parameters
							new SavingBrokerRowMapper());
		
		
		for (SavingBean eb : savingbean_list)
			broker_id = eb.getBid(); 
		
		
		securitybean_list = jdbcTemplate
				.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
						new Object[] { broker_id, broker_id }, // in parameters
						new SecuritiesRowMapper());
		
		
		for (SecuritiesBean eb1 : securitybean_list)
			broker_fee_rate = Float.parseFloat(eb1.getEquities());
		
		
		equitybean_list = jdbcTemplate
				.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
						new Object[] { broker_id, broker_id }, // in parameters
						new EquityRowMapper());
		
		
		for (EquityBean eb1 : equitybean_list){
			String marg_ratio = eb1.getMarg_ratio();
			String[] parts = marg_ratio.split(":");
			user_ratio = Float.parseFloat(parts[0]); 
			broker_ratio = Float.parseFloat(parts[1]); 
			
			margin_fund_rate = Float.parseFloat(((eb1.getMarg_rate()).split("%")[0]));
		}
			
			
		
		
		user_balance = this.jdbcTemplate.queryForObject(
				"select balance from balance where uid=?",
				new Object[] { uid }, Integer.class);
		broker_balance = jdbcTemplate
				.queryForObject(
						"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
						new Object[] { broker_id, broker_id }, Float.class);
		
		user_share = total_stock_value *(user_ratio * 0.01);
		broker_share = total_stock_value *(broker_ratio * 0.01);
		broker_fee = total_stock_value * broker_fee_rate;
		
		
		System.out.println("in \"Do Something\" ---- helooo -- middle ");
		
		if(user_balance >= user_share + broker_fee_rate){
			System.out.println("in \"Do Something\" ---- helooo -- IF -- befor - jdbc ");
		
			
			String ss = "sashikanth";
			double d = 589.89;
			try{
				jdbcTemplate.update("insert into holdings_user_brkr  (uid,sid,bid,mode_trade,quantity,intial_stock_value,br_mf_ratio,br_mr_rate,security_type,timestamp )" 
						+ " values (?,?,?,?,?,?,?,?,?,?)",
						new Object[] {uid,name,broker_id,mode,quantity,price,broker_ratio,margin_fund_rate,security_type,date
						}); 
				
			}
			catch(Exception e){
				System.out.println(e);
			}
			
			System.out.println("in \"Do Something\" ---- helooo -- IF ");
			
		}else
		{
			System.out.println("in \"Do Something\" ---- helooo --- ELSE ");
			return;
		}
		
		
		
		
		
		
	}
	
	
	//*********************************************************************//
	
	
	
	@GET
	@Path("buyequity/{name}/{price}/{getDatetime}/{quantity}/{uid}/{security_type}/{equities}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Transaction> getEquity(@PathParam("name") String name,
			@PathParam("price") Float price,
			@PathParam("getDatetime") Date getDatetime,
			@PathParam("quantity") Integer quantity,
			@PathParam("uid") String uid,
			@PathParam("security_type") String security_type,
			@PathParam("equities") String equties) {
		List<Transaction> list = null;
		List<EquityBean> list1 = null;
		List<SavingBean> list2 = null;
		List<SecuritiesBean> list3 = null;
		float brokers_share = 0;
		float netvalue = quantity * price;
		o_net = netvalue;//l
		try {
			System.out.println("this is kjhaskjnhrvflakj");
//dosomething(String name, Float price, Date date, Float quantity, String uid, String security_type, String equties,char mode){
			
			// EquityBean eq
			// =jdbcTemplate.queryForObject("select marg_ratio from brokerages where b_id=(select b_id from portfolio where usrname=?)",
			// new Object[]{uid},new EquityRowMapper());

			update_Holdings_mf(name, price, getDatetime, quantity, uid, security_type, equties, "B");
			System.out.println("prinlntkn in buy equity ..");
			
			list2 = jdbcTemplate.query(
					"select * from savingbroker where uid=?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());
			
			String b_id = null;
			String br_rate = null;
			for (SavingBean eb : list2)
				b_id = eb.getBid(); //l
			
			System.out.println("this is " + b_id);
			list3 = jdbcTemplate
					.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, // in parameters
							new SecuritiesRowMapper());
			for (SecuritiesBean eb1 : list3)
				br_rate = eb1.getEquities();//l
			
			
			
			System.out.println(br_rate);
			float br_rate1 = Float.parseFloat(br_rate);//l
			
			
			
			System.out.println("Broker rate in float " + br_rate1);
			
			
			
			float br_fee = (float) (netvalue * (br_rate1 * .01));
			
			
			
			// To query the DB for JSON output
			list1 = jdbcTemplate
					.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, // in parameters
							new EquityRowMapper());
			
			
			String marg_ratio = null;
			String marg_rate = null;
			
			for (EquityBean eb1 : list1)
				marg_ratio = eb1.getMarg_ratio();//l
			for (EquityBean eb1 : list1)
				marg_rate = eb1.getMarg_rate();//l
			System.out.println(marg_ratio);

			
			
			
			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.DATE,
					Types.INTEGER, Types.FLOAT, Types.FLOAT, Types.VARCHAR,
					Types.FLOAT, Types.FLOAT, Types.INTEGER, Types.VARCHAR,Types.FLOAT };
			int[] types1 = new int[] { Types.VARCHAR, Types.VARCHAR,
					Types.INTEGER, Types.FLOAT, Types.VARCHAR };

			//

			String[] parts = marg_ratio.split(":");
			int part1 = Integer.parseInt(parts[0]); // user share
			int part2 = Integer.parseInt(parts[1]); // broker share
			String[] parts1 = marg_rate.split("%");
			System.out.println("hi" + part1 + part2);
			
			
			
			
			float num = this.jdbcTemplate.queryForObject(
					"select balance from balance where uid=?",
					new Object[] { uid }, Integer.class);
			
			
			
			
			float user_share = (float) (netvalue * (part1 * .01));
			brokers_share = (float) (netvalue * (part2 * .01));
			
			
			
			
			
			float br_holding1 = jdbcTemplate
					.queryForObject(
							"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, Float.class);
			br_holding1 = br_holding1 - brokers_share;
			System.out.println("hey"+br_holding1);
			
			
			
			//int j = jdbcTemplate
			//		.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
			//				new Object[] { br_holding1, b_id, b_id });
			
			
			
			//System.out.println("success" + j);
			int rate = Integer.parseInt(parts1[0]);
			// br_share=brokers_share;
			System.out.println("net value: " + netvalue);
			System.out.println("To buy: " + user_share);
			System.out.println("brokers_share: " + brokers_share);
			// if balance greater than netvalue buy shares
			System.out.println("num=" + num);
			System.out.println("user_share=" + user_share);
			float brokerfee = (float) (netvalue * (br_rate1 * .01));
			float br_int = (float) (brokers_share * (rate * .01));
			float actualnetvalue=netvalue- (float)brokers_share;
			
			
			
			
			String sr = jdbcTemplate
					.queryForObject(
							"select margin_fund_rate from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, String.class);
			StringTokenizer s = new StringTokenizer(sr);
			sr = s.nextToken("%");
			int x = Integer.parseInt(sr);
			
			
			
			
			float zero = 0.0f;
			
			String bid = jdbcTemplate.queryForObject(
					"select bid from savingbroker where uid=?",
					new Object[] { uid }, String.class);
			
			
			
			if (num >= user_share) {
				// Add the shares bought into transaction_table
				
				jdbcTemplate.update("insert into transaction1(" + "tid,"
						+ "name," + "uid," + "getDatetime," + "quantity,"
						+ "price," + "netvalue," + "status," + "security_type,"
						+ " br_amount," + " marg_interest, " + " mfr, bid,brokers_share)"
						+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,?,"
						+ "'B',?,?,?,?,?,?)", new Object[] { name, uid,
						getDatetime, quantity, price, actualnetvalue, security_type,
						brokerfee, zero, x, bid, brokers_share },// in parameter
						types); // in parameter
				jdbcTemplate.update("insert into t_transaction(" + "tid,"
						+ "name," + "uid," + "getDatetime," + "quantity,"
						+ "price," + "netvalue," + "status," + "security_type,"
						+ " br_amount," + " marg_interest, " + " mfr, bid,brokers_share)"
						+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,?,"
						+ "'B',?,?,?,?,?,?)", new Object[] { name, uid,
						getDatetime, quantity, price, actualnetvalue, security_type,
						brokerfee, br_int, x, bid,brokers_share },// in parameter
						types);
				/* change
				 * returns the number of rows that contains the given uid, if it
				 * is 0 then the uid doesnt exist in holding_table else it
				 * exists in holding_table
				 */
				
				int stockname_holding = jdbcTemplate.queryForObject(
						"select count(*) from holding where uid=? and name=?",
						new Object[] { uid, name }, Integer.class);

				// the new row with this uid does not exist
				if (stockname_holding == 0) {

					int holding17 = 0;
					float holding19 = 0;
					String mfr = jdbcTemplate
							.queryForObject(
									"Select margin_fund_rate from t_broker_det where broker_id= ? and time_stamp= (select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { b_id, b_id }, String.class);
					// if this uid does not exists add as a new row to the
					// holding_table
					jdbcTemplate.update("insert into holding(" + "hid,"
							+ "uid," + "name," + "quantity," + "price,"
							+ "holding," + " amount_lg," + "percentage_lg,"
							+ "security_name," + "current_holding" + ")"
							+ " values (NEXT VALUE FOR h_sequence,?,?,?,?,"
							+ netvalue + "," + holding17 + "," + holding19
							+ ",?," + actualnetvalue + ")", new Object[] { uid, name,
							quantity, price, security_type },// in
							// parameter
							types1);
					list = jdbcTemplate
							.query("select * from transaction1 where getDatetime = ? and uid=?",
									new Object[] { getDatetime, uid },// in
																		// parameter
									new TransactionRowMapper());
					System.out.println("Testing the list out" + list);
					/*
					 * for (Transaction tb : list) tb.setbroker_share();
					 */
					// reduce the balance

					float holding15 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					float br_holding = jdbcTemplate
							.queryForObject(
									"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { b_id, b_id }, Float.class);
					br_holding = br_holding + brokerfee - br_int;
					System.out.println("Broker updated holding" + br_holding);
					float holding16 = holding15 - (user_share + brokerfee);
					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding16, uid });
					int i = jdbcTemplate
							.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { br_holding, b_id, b_id });
					System.out.println("success" + i);
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding16, uid });
					jdbcTemplate
							.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
									new Object[] {});
					// jdbcTemplate.update("update holding set holding.mfr=(select margin_fund_rate from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?) )",new
					// Object[] {b_id,b_id});

				}

				// if the row exists update the holding valuein holding_table

				else {
					float holding_current = jdbcTemplate
							.queryForObject(
									"select holding from holding where uid=? and name=?",
									new Object[] { uid, name }, Float.class);
					float holding_updated = holding_current + netvalue;
					// jdbcTemplate.update("update holding set holding=?", new
					// Object[]{holding2});

					list = jdbcTemplate
							.query("select * from transaction1 where getDatetime = ? and uid=?",
									new Object[] { getDatetime, uid },// in
																		// parameter
									new TransactionRowMapper());
					/*
					 * for (Transaction tb : list)
					 * tb.setBrokers_share(brokers_share);
					 */
					// decrementing balance in balance_table
					float holding3 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					System.out.println("Broker Fee" + brokerfee);
					float holding4 = holding3 - (user_share - br_int);

					// adding quantity in holding_table
					int holding13 = jdbcTemplate
							.queryForObject(
									"select quantity from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					int holding14 = holding13 + quantity;
					float amount_lg = (holding14 * price) - holding_updated;
					float percent_lg = (amount_lg / holding_updated) * 100;

					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding4, uid });
					jdbcTemplate
							.update("update holding set holding=?,quantity=?,price=?,amount_lg=?,percentage_lg=? where uid=? and name=?",
									new Object[] { holding_updated, holding14,
											price, amount_lg, percent_lg, uid,
											name });
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding4, uid });
					jdbcTemplate
							.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
									new Object[] {});

				}

			}

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
		}

		getAutoupdate();
		// if we return null here, it sends back a 404. Good.

		return list;
	}

	// ******************************Getting user homescreen
	// data****************************
	@GET
	@Path("user/{uid}/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public User getUserScreen(@PathParam("uid") String uid,
			@PathParam("getDatetime") Date getDatetime) {
		User obj = null;
		try {
			System.out.println(uid);
			obj = jdbcTemplate.queryForObject(
					"select * from user_screen where id = ?",
					new Object[] { uid }, // in parameter
					new UserRowMapper());

		} catch (Throwable fault) {
			log.info(fault.getStackTrace());

		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	// *********************Getting admin homescreen
	// data*********************************
	@GET
	@Path("users")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getUsers() {
		List<User> list = null;
		try {
			list = jdbcTemplate.query(
					"select * from user_screen order by rank", new Object[] {}, // in
																				// parameters
					new UserRowMapper());
			log.info("rank list:");
			log.info(list);
		} catch (Throwable fault) {
			log.info(fault.getStackTrace());

		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// ***********************Checking the holding value for the current
	// user*********************
	@GET
	@Path("holding/{uid}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<HoldingBean> getHoldingValues(@PathParam("uid") String uid) {
		List<HoldingBean> list = null;
		try {
			list = jdbcTemplate.query(
					"select * from holding where uid = ? and quantity > 0",
					new Object[] { uid }, // in parameters
					new HoldingRowMapper());
			System.out.println("AmountLGCC"
					+ list.get(list.size() - 1).getAmount_lg() + "Name "
					+ list.get(list.size() - 1).getName());
		} catch (Throwable fault) {

			System.out.println(fault.getStackTrace());

			System.out.println("exception");
		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// ******************************VIEW
	// NEWS*************************************
	// Checking the news in general
	@GET
	@Path("news/{getDatetime}")
	// @Path("mosttraded/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<NewsXML> getNews(@PathParam("getDatetime") Date getDatetime) {
		List<NewsXML> list = null;
		try {
			list = jdbcTemplate.query("select news from news", new Object[] {}, // in
																				// parameters
					new newsRowMapper());
			log.info("News :" + list);
		} catch (Throwable fault) {

			log.info(fault.getStackTrace());

		}

		return list;
	}

	// ***************Checking the market price for the current
	// date**************
	@GET
	@Path("marketPrices/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<marketPrice> getMarketPrice(
			@PathParam("getDatetime") Date getDatetime) {
		List<marketPrice> list = null;
		try {
			list = jdbcTemplate.query(
					"select equ_name,equ_symbl,price,beta from equities",
					new Object[] {}, // in parameters
					new marketPriceRowMapper());
			log.info("Current Market Prices");
			log.info(list);
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// **********************make as admin**************************
	@GET
	@Path("makeAdmin/{userid}")
	@Produces(MediaType.APPLICATION_JSON)
	public void getUser(@PathParam("userid") String userid) {
		Connection conn = null;
		String sql = "UPDATE portfolio SET type='a' WHERE usrname = ?";
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userid);
			ps.executeUpdate();
			conn.commit();
			ps.close();
		} catch (Throwable fault) {
			log.info(fault.getStackTrace());
		}
		// if we return null here, it sends back a 404. Good.

	}

	@GET
	@Path("equity/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public EquitiesBeanXml getEquityNameAndPrice(@PathParam("name") String name) {
		EquitiesBeanXml obj = null;
		try {
			// to display equity_name and equity_price
			obj = jdbcTemplate.queryForObject(
					"select equ_name,price from equities where equ_name = ?",
					new Object[] { name }, // in parameter
					new EquitiesBeanXmlRowMapper());
			System.out.println("price" + obj.getPrice());
		} catch (Throwable fault) {

			log.info(fault.getStackTrace());

		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	@GET
	@Path("bonds/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public BondPriceBean getBondNameAndPrice(@PathParam("name") String name) {
		BondPriceBean obj = null;
		try {
			String names = name + "%";
			// to display stock_name and stock_price
			obj = jdbcTemplate.queryForObject(
					"select bond_name,price from bonds where bond_name = ?",
					new Object[] { names }, // in parameter
					new BondPriceBeanRowMapper());
			System.out.println("price1234" + obj.getBond_price());
		} catch (Throwable fault) {
			System.out.println("Geting stock");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	@GET
	@Path("MF/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public MFPriceBean getMfNameAndPrice(@PathParam("name") String name) {
		MFPriceBean obj = null;
		try {
			// to display stock_name and stock_price
			obj = jdbcTemplate.queryForObject(
					"select mf_name,price from mf where mf_name = ?",
					new Object[] { name }, // in parameter
					new MFPriceRowMapper());
		} catch (Throwable fault) {

			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	@GET
	@Path("FX/{basename}/{quotedname}")
	@Produces(MediaType.APPLICATION_JSON)
	public FXPriceBean getFxNameAndPrice(
			@PathParam("basename") String basename,
			@PathParam("quotedname") String quotedname) {
		FXPriceBean obj = null;
		try {
			String names = basename + "/" + quotedname;
			System.out.println(names);
			// to display stock_name and stock_price
			obj = jdbcTemplate.queryForObject(
					"select fx_name,price from fx where fx_name = ?",
					new Object[] { names }, // in parameter
					new FXPriceRowMapper());
		} catch (Throwable fault) {
			System.out.println("Geting fx");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	// ******************************************************buy*********************************************//

	@GET
	@Path("employee/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public EmployeeRow getStockNameAndPrice(@PathParam("name") String name) {
		EmployeeRow obj = null;
		try {
			// to display stock_name and stock_price
			obj = jdbcTemplate.queryForObject(
					"select equ_name,price from equities where equ_name = ?",
					new Object[] { name }, // in parameter
					new EmployeeRowMapper());
		} catch (Throwable fault) {
			System.out.println("Geting stock");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	// ******************************************************buy*********************************************//
	JFrame frame = new JFrame("Hello");

	@GET
	@Path("buy/{name}/{price}/{getDatetime}/{quantity}/{uid}/{security_type}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Transaction> getBuyerDetails(@PathParam("name") String name,
			@PathParam("price") Float price,
			@PathParam("getDatetime") Date getDatetime,
			@PathParam("quantity") Integer quantity,
			@PathParam("uid") String uid,
			@PathParam("security_type") String security_type) {
		List<Transaction> list = null;
		List<SecuritiesBean> list1 = null;
		List<SavingBean> list2 = null;
		float netvalue = quantity * price;
		System.out.println("HEREEEEE");
		try {
			if (security_type.equals("FX")) {
				name = name.replace("-", "/");
			}
			if (security_type.equals("Bonds")) {
				name = name.replace("-", "%");
			}

			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.DATE,
					Types.INTEGER, Types.FLOAT, Types.FLOAT, Types.VARCHAR,
					Types.FLOAT, Types.INTEGER };
			int[] types1 = new int[] { Types.VARCHAR, Types.VARCHAR,
					Types.INTEGER, Types.FLOAT, Types.VARCHAR };

			float num = this.jdbcTemplate.queryForObject(
					"select balance from balance where uid=?",
					new Object[] { uid }, Integer.class);
			list2 = jdbcTemplate.query(
					"select * from savingbroker where uid=?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());
			String b_id = null;
			for (SavingBean eb : list2)
				b_id = eb.getBid();
			list1 = jdbcTemplate
					.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, // in parameters
							new SecuritiesRowMapper());
			String br_rate = null;
			for (SecuritiesBean eb1 : list1)
				br_rate = eb1.getEquities();
			System.out.println(br_rate);
			float br_rate1 = Float.parseFloat(br_rate);
			System.out.println("Broker rate in float " + br_rate1);
			float br_fee = (float) (netvalue * (br_rate1 * .01));
			
			int x = 0;
			// if balance greater than netvalue buy shares
			if (num >= netvalue) {

				// Add the shares bought into transaction_table
				jdbcTemplate.update("insert into transaction1(" + "tid,"
						+ "name," + "uid," + "getDatetime," + "quantity,"
						+ "price," + "netvalue," + "status," + "security_type,"
						+ " br_amount, mfr)"
						+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,?,"
						+ "'B',?,?,?)", new Object[] { name, uid, getDatetime,
						quantity, price, netvalue, security_type, br_fee, x },// in
																				// parameter
						types); // in parameter
				jdbcTemplate.update("insert into t_transaction(" + "tid,"
						+ "name," + "uid," + "getDatetime," + "quantity,"
						+ "price," + "netvalue," + "status," + "security_type,"
						+ " br_amount, mfr)"
						+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,?,"
						+ "'B',?,?,?)", new Object[] { name, uid, getDatetime,
						quantity, price, netvalue, security_type, br_fee, x },// in
																				// parameter
						types);

				/*
				 * returns the number of rows that contains the given uid, if it
				 * is 0 then the uid doesnt exist in holding_table else it
				 * exists in holding_table
				 */
				int stockname_holding = jdbcTemplate.queryForObject(
						"select count(*) from holding where uid=? and name=?",
						new Object[] { uid, name }, Integer.class);

				// the new row with this uid does not exist
				if (stockname_holding == 0) {

					int holding17 = 0;
					float holding19 = 0;

					// if this uid does not exists add as a new row to the
					// holding_table
					jdbcTemplate.update("insert into holding(" + "hid,"
							+ "uid," + "name," + "quantity," + "price,"
							+ "holding," + " amount_lg," + "percentage_lg,"
							+ "security_name," + "current_holding)"
							+ " values (NEXT VALUE FOR h_sequence,?,?,?,?,"
							+ netvalue + "," + holding17 + "," + holding19
							+ ",?," + netvalue + ")", new Object[] { uid, name,
							quantity, price, security_type },// in parameter
							types1);

					list = jdbcTemplate.query(
							"select * from transaction1 where getDatetime = ?",
							new Object[] { getDatetime },// in parameter
							new TransactionRowMapper());

					// reduce the balance
					float holding15 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					float br_holding = jdbcTemplate
							.queryForObject(
									"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { b_id, b_id }, Float.class);

					System.out.println("Broker Fee" + br_fee);
					float holding16 = holding15 - (netvalue + br_fee);
					br_holding = br_holding + br_fee;
					System.out.println("Broker updated holding" + br_holding);
					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding16, uid });
					int i = jdbcTemplate
							.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { br_holding, b_id, b_id });
					System.out.println("success" + i);
					
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding16, uid });
					if (security_type == "Equity") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
										new Object[] {});
					} else if (security_type == "Bonds") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select bonds.price*holding.quantity from bonds where holding.name=bonds.bond_name )",
										new Object[] {});
					} else if (security_type == "MF") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select mf.price*holding.quantity from mf where holding.name=mf.mf_name )",
										new Object[] {});
					} else if (security_type == "FX") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select fx.price*holding.quantity from fx where holding.name=fx.fx_name )",
										new Object[] {});
					}
					float pricer12 = jdbcTemplate
							.queryForObject(
									"select current_holding from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					float pricer13 = jdbcTemplate
							.queryForObject(
									"select amount_lg from holding where uid=? and name=?",
									new Object[] { uid, name }, Float.class);
					System.out.println("Amount_lg AA " + pricer13);
					List<HoldingBean> lister = new ArrayList<HoldingBean>();
					lister = jdbcTemplate
							.query("select * from holding where uid = ? and quantity > 0",
									new Object[] { uid }, // in parameters
									new HoldingRowMapper());
					System.out
							.println(" Amount_lgBB "
									+ lister.get(lister.size() - 1)
											.getAmount_lg() + "Name "
									+ lister.get(lister.size() - 1).getName());
					float pricer11 = jdbcTemplate
							.queryForObject(
									"select amount_lg from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					System.out.println(" CH izzz amount_lg" + pricer11);
				}

				// if the row exists update the holding valuein holding_table

				else {
					float holding_current = jdbcTemplate
							.queryForObject(
									"select holding from holding where uid=? and name=?",
									new Object[] { uid, name }, Float.class);
					float br_holding = jdbcTemplate
							.queryForObject(
									"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { b_id, b_id }, Float.class);
					float holding_updated = holding_current + netvalue;
					// jdbcTemplate.update("update holding set holding=?", new
					// Object[]{holding2});

					list = jdbcTemplate.query(
							"select * from transaction1 where getDatetime = ?",
							new Object[] { getDatetime },// in parameter
							new TransactionRowMapper());

					// decrementing balance in balance_table
					float holding3 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Integer.class);
					float holding4 = holding3 - (netvalue + br_fee);
					br_holding = br_holding + br_fee;
					System.out.println("Broker updated holding" + br_holding);
					// adding quantity in holding_table
					int holding13 = jdbcTemplate
							.queryForObject(
									"select quantity from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					int holding14 = holding13 + quantity;
					float amount_lg = (holding14 * price) - holding_updated;
					float percent_lg = (amount_lg / holding_updated) * 100;

					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding4, uid });
					int i = jdbcTemplate
							.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { br_holding, b_id, b_id });
					System.out.println("success" + i);
					System.out.println("holding updated " + holding_updated
							+ " quantity " + holding14 + "price " + price
							+ "amount lg " + amount_lg + "percent lg"
							+ percent_lg + " uid " + uid + " name " + name);
					jdbcTemplate
							.update("update holding set holding=?,quantity=?,price=?,amount_lg=?,percentage_lg=? where uid= ? and name=?",
									new Object[] { holding_updated, holding14,
											price, amount_lg, percent_lg, uid,
											name });
					float pricer = jdbcTemplate
							.queryForObject(
									"select amount_lg from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					System.out.println(pricer);
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding4, uid });
					if (security_type == "Equity") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
										new Object[] {});
					} else if (security_type == "Bonds") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select bonds.price*holding.quantity from bonds where holding.name=bonds.bond_name )",
										new Object[] {});
					} else if (security_type == "MF") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select mf.price*holding.quantity from mf where holding.name=mf.mf_name )",
										new Object[] {});
					} else if (security_type == "FX") {
						jdbcTemplate
								.update("update holding set holding.current_holding=(select fx.price*holding.quantity from fx where holding.name=fx.fx_name )",
										new Object[] {});
					}
					float pricer11 = jdbcTemplate
							.queryForObject(
									"select amount_lg from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					System.out.println(pricer11);
					float pricer13 = jdbcTemplate
							.queryForObject(
									"select amount_lg from holding where uid=? and name=?",
									new Object[] { uid, name }, Float.class);
					System.out.println("In else Amount_lg AA " + pricer13);
					List<HoldingBean> lister = new ArrayList<HoldingBean>();
					lister = jdbcTemplate
							.query("select * from holding where uid = ? and quantity > 0",
									new Object[] { uid }, // in parameters
									new HoldingRowMapper());
					System.out
							.println("In else Amount_lgBB "
									+ lister.get(lister.size() - 1)
											.getAmount_lg() + "Name "
									+ lister.get(lister.size() - 1).getName());
					float pricer112 = jdbcTemplate
							.queryForObject(
									"select amount_lg from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					System.out.println("In else CH izzz amount_lg" + pricer112);
				}

			}

		} catch (NullPointerException e) {
			System.out.println("Exception " + e.toString());
		} catch (Throwable fault) {

			/*
			 * JOptionPane.showMessageDialog(frame,
			 * "Oops!!!! something went wrong :(");
			 */

			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
		}

		getAutoupdate();
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// ******************************************sell*********************************************************//

	// **************************************** Saving Broker
	// **************************************//

	@GET
	@Path("savebroker/{uid}/{bid}/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<SavingBean> getSavingValues(@PathParam("bid") String bid,
			@PathParam("uid") String uid,
			@PathParam("getDatetime") String getDatetime) {
		List<SavingBean> list = null;
		List<SavingBean> list1 = null;
		System.out.println("Did I call u?");
		try {

			// To query the DB for JSON output
			list = jdbcTemplate.query(
					"select * from savingbroker where uid = ? and bid = ?",
					new Object[] { uid, bid }, // in parameters
					new SavingBrokerRowMapper());

			// To check whether a given user exist
			list1 = jdbcTemplate.query(
					"select * from savingbroker where uid = ?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());

			// Initializations
			String exist = null;
			String dateindb = null;
			String bidb = null;

			for (SavingBean sab : list1) // To get the Initial date and time
											// from DB
			{
				exist = sab.getUid();
				dateindb = sab.getDate();
				bidb = sab.getBid();
			}
			System.out.println(dateindb);
			if (dateindb == null) // If the user doesn't exist set them to
									// current date
				dateindb = getDatetime;

			// To get difference in date!
			SimpleDateFormat formatcur = new SimpleDateFormat("yyyy-MM-dd-hh");
			Date stampdb = formatcur.parse(dateindb);
			Date stampurl = formatcur.parse(getDatetime);
			DecimalFormat brokerFormatter = new DecimalFormat("###,###");
			long diff = stampdb.getTime() - stampurl.getTime();
			int diffhours = (int) (diff / (60 * 60 * 1000));
			String difference = brokerFormatter.format(diffhours);
			System.out.println("At top The Difference is: " + difference);
			int diffe = Integer.parseInt(difference);
			int differences = 0;
			System.out.println("The Difference is: " + diffe);
			if (diffe < 0)
				differences = Math.abs(diffe);
			System.out.println("The Differences is: " + differences);
			// Differnce of date ends here!

			if ((list.size() == 0) && (exist == null)) // Used to insert new
														// user into DB
			{
				System.out.println("Not Present, Adding user to the db");

				// Setting the current date to the stamp for the new user
				Date curDate = new Date();
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-hh");
				String stamp = format.format(curDate);
				stamp = stamp.toString();
				System.out.println(stamp);

				// Row insertion
				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
						Types.VARCHAR };
				int row = jdbcTemplate.update(
						"insert into savingbroker values(?,?,?)", new Object[] {
								uid, bid, stamp }, types);

				System.out.println(row + " row inserted!");

				for (SavingBean sab : list1) {
					sab.setLocked("no");
				}
			}

			else if (differences <= 24) // Check if the user's last update was
										// less than 24hours ago
			{

				for (SavingBean sab : list1) {
					sab.setDate("null");
					sab.setUid("null");
					sab.setLocked("yes");
				}

			}

			else if (differences > 24) // Updating the user only after 24 hours!
			{
				Date curDate = new Date();
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-hh");
				String stamp = format.format(curDate);
				stamp = stamp.toString();
				System.out.println(stamp);

				int row = jdbcTemplate.update(
						"update savingbroker set bid=?,stamp=? where uid=?",
						new Object[] { bid, stamp, uid });
				System.out.println(row + " row updated!");

				for (SavingBean sab : list1) {

					sab.setLocked("no");
				}

			}

			else {
				String datetime = null;
				String userid = null;
				for (SavingBean sab : list) {
					datetime = sab.getDate();
					userid = sab.getUid();
				}

				if (getDatetime.equals(datetime) && exist.equals(userid)) {
					System.out.println("Present!");
					for (SavingBean sab : list1) {
						sab.setDate("null");
						sab.setUid("null");
						sab.setLocked("no");
					}
				} else
					System.out.println("Absent!");
			}
		} catch (Throwable fault) {
			System.out.println("Checking the Saving details");
			fault.printStackTrace();
		}

		// if we return null here, it sends back a 404. Good.
		return list1;
	}

	// check for broker selected or not //

	@GET
	@Path("savedbroker/{uid}/{bid}/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<SavingBean> getSavedValues(@PathParam("bid") String bid,
			@PathParam("uid") String uid,
			@PathParam("getDatetime") String getDatetime) {
		List<SavingBean> list = null;

		System.out.println("In saved broker");
		try {

			// To query the DB for JSON output
			list = jdbcTemplate.query(
					"select * from savingbroker where uid = ? and bid = ?",
					new Object[] { uid, bid }, // in parameters
					new SavingBrokerRowMapper());

		} catch (Throwable fault) {
			System.out.println("Checking the Saving details");
			fault.printStackTrace();
		}
		try {
			System.out.println("Broker check" + list.get(0).getBid());
		} catch (NullPointerException e) {
			System.out.println("Broker check fault");
		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// ************************************ //

	// ******************************************sell*********************************************************//
	@GET
	@Path("sell/{name}/{price}/{getDatetime}/{quantity}/{uid}/{security_type}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Transaction> getSellDetails(@PathParam("name") String name,
			@PathParam("price") Float price,
			@PathParam("getDatetime") Date getDatetime,
			@PathParam("quantity") Integer quantity,
			@PathParam("uid") String uid,
			@PathParam("security_type") String security_type) {
		List<Transaction> list = null;
		List<SavingBean> list1 = null;
		List<SecuritiesBean> list2 = null;
		/*
		 * returns the number of rows that contains the given uid, if it is 0
		 * then the uid doesnt exist in holding_table else it exists in
		 * holding_table
		 */

		try {
			if (security_type.equals("FX")) {
				name = name.replace("-", "/");
			}
			if (security_type.equals("Bonds")) {
				name = name.replace("-", "%");
			}
			int uid_present = jdbcTemplate.queryForObject(
					"select count(*) from holding where uid=? and name=?",
					new Object[] { uid, name }, Integer.class);
			int holding_quantity = this.jdbcTemplate.queryForObject(
					"select quantity from holding where uid=? and name=?",
					new Object[] { uid, name }, Integer.class);
			list1 = jdbcTemplate.query(
					"select * from savingbroker where uid=?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());
			String b_id = null;
			for (SavingBean eb : list1)
				b_id = eb.getBid();
			list2 = jdbcTemplate
					.query("select * from T_BROKER_DET where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
							new Object[] { b_id, b_id }, // in parameters
							new SecuritiesRowMapper());
			String br_rate = null;
			for (SecuritiesBean eb1 : list2)
				br_rate = eb1.getEquities();
			/*
			 * for (BrokerValuesBean eb1 : list2) br_rate = eb1.getEquities();
			 */
			// the new row with this uid does not exist
			System.out.println(br_rate);
			// String[] parts2 = br_rate.split("%");
			// int rate1=Integer.parseInt(parts2[0]);
			// System.out.println("hi"+rate1);
			float rate = Float.parseFloat(br_rate);
			System.out.println(rate);
			if (uid_present > 0)

			{
				// the number of shares he holds is greater than number of
				// shares he is going to sell
				if (holding_quantity >= quantity) {
					int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
							Types.DATE, Types.INTEGER, Types.FLOAT,
							Types.VARCHAR, Types.FLOAT };
					float netvalue = quantity * price;
					float brokerfee = (float) (netvalue * (rate * .01));
					float user_share = netvalue - brokerfee;
					System.out.println("Broker Fee" + brokerfee);
					System.out.println("usershare" + user_share);

					// Selling Transaction into Transaction1_table
					jdbcTemplate.update("insert into transaction1(" + "tid,"
							+ "name," + "uid," + "getDatetime," + "quantity,"
							+ "price," + "netvalue," + "status,"
							+ "security_type," + " br_amount)"
							+ " values (NEXT VALUE FOR t_sequence,?,?,?,?,?,"
							+ user_share + "," + "'S',?,?)", new Object[] {
							name, uid, getDatetime, quantity, price,
							security_type, brokerfee },// in parameter

							types); // in parameter

					// subtract the quantity in holding_table after you sell the
					// shares
					int holding5 = jdbcTemplate
							.queryForObject(
									"select quantity from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					int holding6 = holding5 - quantity;

					// subtract the holding in holding_table after you sell the
					// shares
					int holding7 = jdbcTemplate
							.queryForObject(
									"select holding from holding where uid=? and name=?",
									new Object[] { uid, name }, Integer.class);
					float holding8 = holding7 - netvalue;

					// update holding_table after sell
					jdbcTemplate
							.update("update holding set quantity=?,holding=? where uid=? and name=?",
									new Object[] { holding6, holding8, uid,
											name });

					// if holding is 0 then delete that entry from holding table
					if (holding8 == 0) {
						jdbcTemplate.update(
								"delete from holding where uid=? and name=?",
								new Object[] { uid, name });
					}
					float br_holding = jdbcTemplate
							.queryForObject(
									"select br_holding from t_broker_det where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { b_id, b_id }, Float.class);
					br_holding = br_holding + brokerfee;
					System.out.println("Broker updated holding" + br_holding);

					// incrementing balance in balance_table
					float holding9 = jdbcTemplate.queryForObject(
							"select balance from balance where uid=?",
							new Object[] { uid }, Float.class);

					float holding10 = holding9 + user_share;
					System.out.println("current holding" + holding9);
					System.out.println("New holding" + holding10);
					jdbcTemplate.update(
							"update balance set balance=? where uid=?",
							new Object[] { holding10, uid });
					int i = jdbcTemplate
							.update("update t_broker_det set br_holding=? where broker_id=? and time_stamp=(select max(time_stamp) from t_broker_det where broker_id=?)",
									new Object[] { br_holding, b_id, b_id });
					System.out.println("success" + i);

					// display transaction1_table
					list = jdbcTemplate.query(
							"select * from transaction1 where getDatetime = ?",
							new Object[] { getDatetime },// in parameter
							new TransactionRowMapper());
					jdbcTemplate
							.update("update user_screen set user_screen.balance=? where user_screen.id=?",
									new Object[] { holding10, uid });
					jdbcTemplate
							.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name )",
									new Object[] {});
				}
			}
		}

		catch (NullPointerException e) {

			// fault.printStackTrace();
			list = null;
			return list;
		} catch (Throwable fault) {
			log.info("ERROR due to no data in holding for the user : " + uid);
		}

		getAutoupdate();
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// **********************************************Most
	// Traded*****************************************************************//
	@GET
	@Path("mosttraded/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Mosttraded> getMostTraded(
			@PathParam("getDatetime") Date getDatetime) {
		List<Mosttraded> list = null;
		try {

			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate
					.query("select name,price,COUNT(*) as count FROM transaction1  GROUP BY name,price,getDatetime having getDatetime=? ORDER BY count DESC fetch first 3 rows only",
							new Object[] { getDatetime }, // in parameter
							new MosttradedRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// ********************************************************Auto
	// Update*********************************************************//
	@GET
	@Path("auto_update/{date}")
	@Produces(MediaType.APPLICATION_JSON)
	public void getAutoupdate() {

		try {
			jdbcTemplate
					.update("update holding set holding.price=(select equities.price from equities where holding.name=equities.equ_name) where security_name='Equity'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.amount_lg=(select equities.price*holding.quantity-holding.holding from equities where holding.name=equities.equ_name) where security_name='Equity'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.percentage_lg=(select ((equities.price*holding.quantity-holding.holding)/(holding.holding))*100 from equities where holding.name=equities.equ_name) where security_name='Equity'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.current_holding=(select equities.price*holding.quantity from equities where holding.name=equities.equ_name ) where security_name='Equity'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.price=(select bonds.price from bonds where holding.name=bonds.bond_name) where security_name='Bonds'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.amount_lg=(select bonds.price*holding.quantity-holding.holding from bonds where holding.name=bonds.bond_name) where security_name='Bonds'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.percentage_lg=(select ((bonds.price*holding.quantity-holding.holding)/(holding.holding))*100 from bonds where holding.name=bonds.bond_name) where security_name='Bonds'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.current_holding=(select bonds.price*holding.quantity from bonds where holding.name=bonds.bond_name ) where security_name='Bonds'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.price=(select mf.price from mf where holding.name=mf.mf_name) where security_name='MF'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.amount_lg=(select mf.price*holding.quantity-holding.holding from mf where holding.name=mf.mf_name) where security_name='MF'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.percentage_lg=(select ((mf.price*holding.quantity-holding.holding)/(holding.holding))*100 from mf where holding.name=mf.mf_name) where security_name='MF'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.current_holding=(select mf.price*holding.quantity from mf where holding.name=mf.mf_name ) where security_name='MF'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.price=(select fx.price from fx where holding.name=fx.fx_name) where security_name='FX'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.amount_lg=(select fx.price*holding.quantity-holding.holding from fx where holding.name=fx.fx_name) where security_name='FX'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.percentage_lg=(select ((fx.price*holding.quantity-holding.holding)/(holding.holding))*100 from fx where holding.name=fx.fx_name) where security_name='FX'",
							new Object[] {});
			jdbcTemplate
					.update("update holding set holding.current_holding=(select fx.price*holding.quantity from fx where holding.name=fx.fx_name ) where security_name='FX'",
							new Object[] {});
			jdbcTemplate
					.update("update user_screen set user_screen.glpercentage=(select CAST(avg(holding.percentage_lg) + 0.005 AS DECIMAL(15,2)) from holding where user_screen.id=holding.uid)",
							new Object[] {});
			jdbcTemplate
					.update("update user_screen set user_screen.portfoliovalue=(select sum(holding.current_holding) from holding where user_screen.id=holding.uid)",
							new Object[] {});
			int rank = 1;
			int[] types = new int[] { Types.INTEGER, Types.VARCHAR };
			List<Dashboard> list = null;
			list = jdbcTemplate
					.query("select id,balance+portfoliovalue total_value from user_screen where portfoliovalue is not null order by total_value desc",
							new Object[] {}, // in parameter
							new DashboardRowMapper());
			/*
			 * jdbcTemplate.execute(
			 * "create table rank_table (uid varchar(25),rank integer)");
			 */
			for (int i = 0; i < list.size(); i++) {
				String x = list.get(i).getUserid();
				jdbcTemplate.update("update user_screen set rank=? where id=?",
						new Object[] { rank, x }, types);
				rank++;
			}

		}

		catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.

	}

	// ---------------Top 5 gainers and losers ------------------------

	@GET
	@Path("gamers/{datetime}/{milliseconds}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Dashboard> getGamers() {
		List<Dashboard> list = null;
		try {
			int count = jdbcTemplate
					.queryForObject(
							"select COUNT(rank) from user_screen where rank is not null",
							new Object[] {}, // in parameter
							Integer.class);
			if (count > 10) {
				list = jdbcTemplate
						.query("select id,balance+portfoliovalue total_value from user_screen where balance+portfoliovalue > 100000  order by total_value desc fetch first 5 rows only",
								new Object[] {}, // in parameter
								new DashboardRowMapper());
			}
			// else
			// {
			// list = jdbcTemplate.query(
			// "select id,balance+portfoliovalue total_value from user_screen where portfoliovalue is not null order by total_value desc fetch first 5 rows only",
			// new Object[]{}, //in parameter
			// new TransactionRowMapper());
			// }
		} catch (Throwable fault) {
			System.out.println("Hello");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("gamer/{datetime}/{milliseconds}")
	@Produces(MediaType.APPLICATION_JSON)
	public void getGamerRank() {
		int rank = 1;
		int[] types = new int[] { Types.INTEGER, Types.VARCHAR };
		List<Dashboard> list = null;
		try {
			list = jdbcTemplate
					.query("select id,balance+portfoliovalue total_value from user_screen order by total_value desc",
							new Object[] {}, // in parameter
							new DashboardRowMapper());
			/*
			 * jdbcTemplate.execute(
			 * "create table rank_table (uid varchar(25),rank integer)");
			 */
			for (int i = 0; i < list.size(); i++) {
				String x = list.get(i).getUserid();
				jdbcTemplate.update("update user_screen set rank=? where id=?",
						new Object[] { rank, x }, types);
				rank++;
			}
		} catch (Throwable fault) {
			System.out.println("Hello");
			fault.printStackTrace();
		}
		// if we return null here, it sends back a 404. Good.
	}

	@GET
	@Path("losers/{datetime}/{milliseconds}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Dashboard> getLosers() {
		List<Dashboard> list1 = null;
		try {
			list1 = jdbcTemplate
					.query("select id,balance+portfoliovalue total_value from user_screen where balance+portfoliovalue < 100000 order by total_value fetch first 5 rows only",
							new Object[] {}, // in parameters
							new DashboardRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good.

		return list1;
	}

	@GET
	@Path("transactions")
	@Produces(MediaType.APPLICATION_JSON)
	public List<marketPrice> getLatestTransactions() {
		List<marketPrice> list = null;
		try {
			list = jdbcTemplate.query(
					"select * from transaction1 offset 20 rows",
					new Object[] {}, // in parameters
					new marketPriceRowMapper());
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@POST
	@Path("/upload")
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String uploadFile(@Multipart("fileUpload") Attachment attachment)
			throws IOException {

		try {

			String ofilename = attachment.getContentDisposition().getParameter(
					"filename");
			String filename = "Pricing.xlsx";
			if (ofilename.contains(".xlsx")) {
				System.out.println(" original file name : " + ofilename);
				System.out
						.println(" path in which the file is getting uploaded H:/Excel/"
								+ filename);
				// System.out.println(" file type :"+type);

				java.nio.file.Path path = Paths.get("H:/Excel/" + filename);
				Files.deleteIfExists(path);
				InputStream in = attachment.getObject(InputStream.class);

				Files.copy(in, path);
				System.out
						.println("done uploading, redirecting to insert service");
				// getAutoupdate();
				return "<html><script>window.location.replace(\"http://"
						+ IpAddress.getIpAddress()
						+ "/MyRestDB/cxfservlet/jaxrs-server/service/insertstock\")</script></html>";
			} else {
				return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"
						+ IpAddress.getIpAddress()
						+ "/PortfolioGame/admin.jsp\");</script></html>";
			}

		}

		catch (Exception e) {
			return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"
					+ IpAddress.getIpAddress()
					+ "/PortfolioGame/admin.jsp\");</script></html>";
		}
	}

	// *********************************upload news
	// service****************************************
	@POST
	@Path("/uploadnews")
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String uploadFileNews(
			@Multipart("fileUploadNews") Attachment attachment)
			throws IOException {

		try {

			String ofilename = attachment.getContentDisposition().getParameter(
					"filename");
			String filename = "Pricing.xlsx";
			if (ofilename.contains(".xlsx")) {
				System.out.println(" original file name : " + ofilename);
				System.out
						.println(" path in which the file is getting uploaded H:/Excel/"
								+ filename);
				// System.out.println(" file type :"+type);

				java.nio.file.Path path = Paths.get("H:/Excel/" + filename);
				Files.deleteIfExists(path);
				InputStream in = attachment.getObject(InputStream.class);

				Files.copy(in, path);
				System.out
						.println("done uploading, redirecting to insert service");
				return "<html><script>window.location.replace(\"http://"
						+ IpAddress.getIpAddress()
						+ "/MyRestDB/cxfservlet/jaxrs-server/service/insertnews\")</script></html>";
			} else {
				return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"
						+ IpAddress.getIpAddress()
						+ "/PortfolioGame/admin.jsp\");</script></html>";
			}

		}

		catch (Exception e) {
			return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"
					+ IpAddress.getIpAddress()
					+ "/PortfolioGame/admin.jsp\");</script></html>";
		}
	}

	@GET
	@Path("stocksName")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Stocks> getStocksName() {
		List<Stocks> list = null;
		try {

			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate.query(
					"select equ_name from stock order by equ_name",
					new Object[] {}, // in parameter
					new StocksRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// *****************************Transaction
	// History********************************

	@GET
	@Path("history/{uid}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<TransactionHistory> getHistory(@PathParam("uid") String uid) {
		List<TransactionHistory> obj = null;
		try {
			obj = jdbcTemplate
					.query("select * from transaction1 where uid = ? order by time_stamp desc",
							new Object[] { uid }, // in parameter
							new HistoryRowMapper());
		} catch (Throwable fault) {
			log.info(fault.getStackTrace());
		}
		// if we return null here, it sends back a 404. Good.
		return obj;
	}

	// ******************************XBBLWDM 13496 Advice code VIEW
	// ADVICE*************************************
	// Checking the news in general
	@GET
	@Path("getadvice/{bid}")
	// @Path("mosttraded/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<AdviceBean> getAdvice(@PathParam("bid") String bid) {
		List<AdviceBean> list = null;
		try {
			list = jdbcTemplate
					.query("select distinct advice from advice where bid = ? and date=(select max(date) from advice)",
							new Object[] { bid }, // in parameters
							new AdviceRowMapper());
			log.info("Advice :" + list);
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	/* ***********************BrokerName************************ */

	@GET
	@Path("getbrokername/{uid}")
	// @Path("mosttraded/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<BrokerValuesBean> getBrokername(@PathParam("uid") String uid) {
		List<BrokerValuesBean> list = null;

		try {

			list = jdbcTemplate
					.query("select distinct broker_name,broker_id from t_broker_det where broker_id = (select bid from savingbroker where uid = ?)",
							new Object[] { uid }, // in parameters
							new BrokerNameRowMapper());

			log.info("Advice :" + list);
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("getadviceuser/{uid}")
	// @Path("mosttraded/{getDatetime}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<AdviceBean> getAdviceUser(@PathParam("uid") String uid) {
		List<AdviceBean> list = null;

		try {

			list = jdbcTemplate
					.query("select distinct advice from advice where bid = (select bid from savingbroker where uid = ?) and date=(select max(date) from advice)",
							new Object[] { uid }, // in parameters
							new AdviceRowMapper());

			log.info("Advice :" + list);
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// *********************************XBBLWDM 13496 Advice code upload advice
	// function********************************

	@POST
	@Path("/uploadadvice")
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String uploadFileAdvice(
			@Multipart("fileUploadAdvice") Attachment attachment)
			throws IOException {

		try {

			String ofilename = attachment.getContentDisposition().getParameter(
					"filename");

			if (ofilename.contains(".xlsx")) {
				System.out.println(" original file name : " + ofilename);

				java.nio.file.Path path = Paths.get(excelFilePathBean
						.getExcelFilePath());

				Files.deleteIfExists(path);

				InputStream in = attachment.getObject(InputStream.class);

				Files.copy(in, path);

				return "<html><script>window.location.replace(\"http://"
						+ IpAddress.getIpAddress()
						+ "/MyRestDB/cxfservlet/jaxrs-server/service/insertadvice\")</script></html>";
			} else {
				return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://"
						+ IpAddress.getIpAddress()
						+ "/PortfolioGame/broker1.jsp\");</script></html>";
			}

		}

		catch (Exception e) {
			e.printStackTrace();
			return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://"
					+ IpAddress.getIpAddress()
					+ "/PortfolioGame/broker1.jsp\");</script></html>";
		}
	}

	// ********************************XBBLWDM 13496 Advice code insert advice
	// function ***********************************

	@GET
	@Path("insertadvice")
	// @Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_HTML)
	public String insertAdvice() {

		log.info("\nEntered inserstock service");
		ArrayList<AdviceBean> adviceBeanList = new ArrayList<AdviceBean>();
		InsertUtility.insertAdvice(adviceBeanList,
				excelFilePathBean.getExcelFilePath(), log);

		try {

			JdbcTemplate template = new JdbcTemplate(dataSource);
			int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.DATE };

			// AdviceBean adviceBean1=;
			// template.update("delete from advice");
			for (AdviceBean adviceBean : adviceBeanList) {

				template.update(
						"insert into advice values(?,?,?)",
						new Object[] { adviceBean.getAdvice(),
								adviceBean.getId(), new Date() }, types);
				System.out.println(adviceBean.getAdvice());
				System.out.println(adviceBean.getId());
				log.info("\nInserted advice values");
			}

		} catch (DuplicateKeyException e) {
			log.info(e.getStackTrace());
			e.printStackTrace();
			return "<html><script>alert(\"Update for the day is done\");window.location.replace(\"http://http://"
					+ IpAddress.getIpAddress()
					+ "/PortfolioGame/admin.jsp\");</script></html>";
		}

		catch (Throwable fault) {

			log.info(fault.getStackTrace());
			fault.printStackTrace();
			return "<html><script>alert(\"Error Inserting\");window.location.replace(\"http://"
					+ IpAddress.getIpAddress()
					+ "/PortfolioGame/admin.jsp\");</script></html>";
		}
		log.info("\nReturning after inserting advice");

		return "<html><script>alert(\"Advice Uploaded\");window.location.replace(\"http://"
				+ IpAddress.getIpAddress()
				+ "/PortfolioGame/broker1.jsp\");</script></html>";

	}

	// *****************************FORGOT
	// PASSWORD*****************************DONE BY XBBLWC8 EMP
	// ID:13490************************************************************************************************//
	@GET
	@Path("forgotPassword/{username}")
	@Produces(MediaType.APPLICATION_JSON)
	public ForgotPwdBean forgotPassword(@PathParam("username") String username) {
		ForgotPwdBean obj = null;
		try {

			obj = jdbcTemplate.queryForObject(
					"select passwd,email_id from portfolio where usrname = ?",
					new Object[] { username }, // in parameter
					new ForgotPwdRowMapper());
		} catch (Throwable fault) {

			log.info(fault.getStackTrace());

		}
		// System.out.println(obj.getEmail_id() + obj.getPassword());

		String to = obj.getEmail_id();

		// Sender's email ID needs to be mentioned
		String from = "xbblwc8@bnymellon.com";

		// Assuming you are sending email from localhost
		String host = "smtp.bnymellon.net";

		// Get system properties
		Properties properties = System.getProperties();

		// Setup mail server
		properties.setProperty("mail.smtp.host", host);

		// Get the default Session object.
		Session session = Session.getDefaultInstance(properties);

		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));

			// Set Subject: header field
			message.setSubject("Your Recovery Password");

			// Now set the actual message
			message.setText("Your Password is \t" + obj.getPassword());

			// Send message
			Transport.send(message);
			log.info("Sent message successfully....");
			return obj;
		} catch (MessagingException mex) {
			log.info(mex.getStackTrace());
			return null;
		}

	}

	// ***********************************************************************************************************************************************************

	@POST
	@Path("/uploadbonds")
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public String uploadFileBond(
			@Multipart("fileUploadBonds") Attachment attachment)
			throws IOException {

		try {

			String ofilename = attachment.getContentDisposition().getParameter(
					"filename");
			String filename = "Pricing.xlsx";
			if (ofilename.contains(".xlsx")) {
				System.out.println(" original file name : " + ofilename);
				System.out
						.println(" path in which the file is getting uploaded H:/Excel/"
								+ filename);
				// System.out.println(" file type :"+type);

				java.nio.file.Path path = Paths.get("H:/Excel/" + filename);
				Files.deleteIfExists(path);
				InputStream in = attachment.getObject(InputStream.class);

				Files.copy(in, path);
				System.out
						.println("done uploading, redirecting to insert service");
				return "<html><script>window.location.replace(\"http://172.24.19.17:9090/MyRestDB/cxfservlet/jaxrs-server/service/insertbond\")</script></html>";
			} else {
				return "<html><script>alert(\"ERROR!!!! Wrong File Type..\");window.location.replace(\"http://172.24.19.17:9090/PortfolioGame/admin.jsp\");</script></html>";
			}

		}

		catch (Exception e) {
			return "<html><script>alert(\"ERROR!!!!\");window.location.replace(\"http://172.24.19.17:9090/PortfolioGame/admin.jsp\");</script></html>";
		}
	}

	/* get bond name */

	/* upload fx */

	@GET
	@Path("MFName")
	@Produces(MediaType.APPLICATION_JSON)
	public List<MFNameBean> getMFName() {
		List<MFNameBean> list = null;
		try {

			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate.query("select mf_name from mf",
					new Object[] {}, // in parameter
					new MFNameRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("FXName")
	@Produces(MediaType.APPLICATION_JSON)
	public List<FXNameBean> getFXName() {
		List<FXNameBean> list = null;
		try {

			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate.query("select fx_name from fx",
					new Object[] {}, // in parameter
					new FXNameRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("bondsName")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Bonds> getBondsName() {
		List<Bonds> list = null;
		try {

			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate.query("select bond_name from bonds",
					new Object[] {}, // in parameter
					new BondsRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	/* end of get bond name */

	// Abishek
	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ VOLATILE STOCKS
	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	@GET
	@Path("volatile")
	@Produces(MediaType.APPLICATION_JSON)
	public List<marketPrice> getVolatileStocks() {
		List<marketPrice> list = null;
		try {
			list = jdbcTemplate
					.query("select equ_name,equ_symbl,price,beta from equities where beta>(select avg(beta) from equities)",
							new Object[] {}, // in parameters
							new marketPriceRowMapper());
			log.info("The List of V_STOCKS");
			log.info(list);
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

	@GET
	@Path("equitiesName")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Equities> getEquitiesName() {
		List<Equities> list = null;
		try {

			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate.query(
					"select equ_name from equities order by equ_name",
					new Object[] {}, // in parameter
					new EquitiesRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {

			log.info(fault.getStackTrace());

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Client report
	// Haniya 13499 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	@GET
	@Path("clientreport/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<clientreport1> getclientreport(@PathParam("name") String name) {
		List<clientreport1> list = null;
		try {
			// int[] types = new int[]
			// {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
			// Types.VARCHAR, Types.VARCHAR,Types.VARCHAR, Types.VARCHAR,
			// Types.VARCHAR,Types.VARCHAR};
			System.out.println("try started" + name);
			list = jdbcTemplate
					.query("select a.name,a.uid,a.quantity,a.price,a.status,a.netvalue,a.br_amount,a.marg_interest,a.bid from transaction1 a, savingbroker b, t_broker_det where a.uid=b.uid and b.bid = t_broker_det.broker_id and t_broker_det.broker_name= ?",
							new Object[] { name }, // in parameter
							new clientrowmapper());
			// System.out.println("update successful AAA"+list.get(0).getStatus());
		} catch (Exception e) {
			System.out.println("Update Error");
			e.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}
	

	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$lose$$$$xbblv5g
	// 13470$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	

	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Sum Broker Fee
	// Sujith- 201032 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	@GET
	@Path("sumbrokerfee/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public double getSumBrokerFee(@PathParam("name") String name) {
		double sum = 0.0;
		try {
			// int[] types = new int[]
			// {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
			// Types.VARCHAR, Types.VARCHAR,Types.VARCHAR, Types.VARCHAR,
			// Types.VARCHAR,Types.VARCHAR};
			System.out.println("try started" + name);
		    sum = jdbcTemplate.queryForObject(
					"select sum(a.br_amount) from transaction1 a, savingbroker b, t_broker_det where a.uid=b.uid and b.bid = t_broker_det.broker_id and t_broker_det.broker_name=?",
					new Object[] {  name }, Double.class);
		    System.out.println(sum);
			// System.out.println("update successful AAA"+list.get(0).getStatus());
		} catch (Exception e) {
			System.out.println("Update Error");
			e.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return sum;
	}

	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	
	// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Sum Margin Fee
		// Sujith- 201032 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		@GET
		@Path("summarginfee/{name}")
		@Produces(MediaType.APPLICATION_JSON)
		public double getSumMarginrFee(@PathParam("name") String name) {
			double sum = 0.0;
			try {
				// int[] types = new int[]
				// {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
				// Types.VARCHAR, Types.VARCHAR,Types.VARCHAR, Types.VARCHAR,
				// Types.VARCHAR,Types.VARCHAR};
				System.out.println("try started" + name);
			    sum = jdbcTemplate.queryForObject(
						"select sum(a.marg_interest) from transaction1 a, savingbroker b, t_broker_det where a.uid=b.uid and b.bid = t_broker_det.broker_id and t_broker_det.broker_name=?",
						new Object[] {  name }, Double.class);
			    System.out.println(sum);
				// System.out.println("update successful AAA"+list.get(0).getStatus());
			} catch (Exception e) {
				System.out.println("Update Error");
				e.printStackTrace();

			}
			// if we return null here, it sends back a 404. Good.
			return sum;
		}

		// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
		// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Sum Margin Fee
				// Sujith- 201032 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
				@GET
				@Path("availablebalance/{name}")
				@Produces(MediaType.APPLICATION_JSON)
				public double getAvailBalance(@PathParam("name") String name) {
					double sum = 0.0;
					try {
						// int[] types = new int[]
						// {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
						// Types.VARCHAR, Types.VARCHAR,Types.VARCHAR, Types.VARCHAR,
						// Types.VARCHAR,Types.VARCHAR};
						System.out.println("try started" + name);
					    sum = jdbcTemplate.queryForObject(
								"select br_holding from t_broker_det where broker_name=?",
								new Object[] {  name }, Double.class);
					    System.out.println(sum);
						// System.out.println("update successful AAA"+list.get(0).getStatus());
					} catch (Exception e) {
						System.out.println("Update Error");
						e.printStackTrace();

					}
					// if we return null here, it sends back a 404. Good.
					return sum;
				}

				// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
				//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	/** lose//xbblv5g **/
	@GET
	@Path("lose")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Losegain> getlose() {

		List<Losegain> list = null;
		try {

			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate
					.query("select equ_symbl,difference from equities where difference < 0",
							new Object[] {}, // in parameter
							new LosegainRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	/** gain//xbblv5g **/
	@GET
	@Path("gain")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Losegain> getgain() {

		List<Losegain> list = null;
		try {
			// xbblv5g
			// to display stock_name and stock_price of that particular date
			list = jdbcTemplate
					.query("select equ_symbl,difference from equities where difference > 0",
							new Object[] {}, // in parameter
							new LosegainRowMapper());

			// to change the market_price to the updated market_price

		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}
		// if we return null here, it sends back a 404. Good.
		return list;
	}

	@GET
	@Path("logOut")
	@Produces(MediaType.APPLICATION_JSON)
	public void loggingOut() {
		try {
			username = null;
		} catch (Throwable fault) {
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();

		}

		// if we return null here, it sends back a 404. Good
	}

	// 13484
	@GET
	@Path("checkbrokerexistence/{uid}")
	@Produces(MediaType.APPLICATION_JSON)
	public SavingBean checkBrokerExistence(@PathParam("uid") String uid) {
		SavingBean sb = null;
		try {
			sb = jdbcTemplate.queryForObject(
					"select * from savingbroker where uid=?",
					new Object[] { uid }, // in parameters
					new SavingBrokerRowMapper());

		} catch (DataAccessException dae) {

			sb = null;
			return sb;

		} catch (Exception e) {
			sb = null;

			log.info(e.getStackTrace());
			return sb;
		}
		// if we return null here, it sends back a 404. Good.
		return sb;
	}

}
