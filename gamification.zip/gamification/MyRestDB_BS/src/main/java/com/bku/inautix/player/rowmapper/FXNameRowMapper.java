package com.bku.inautix.player.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.FXNameBean;
import com.bku.inautix.model.MFNameBean;

public class FXNameRowMapper implements RowMapper<FXNameBean> {
	public FXNameBean mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		FXNameBean obj = new FXNameBean();	
		obj.setFx_name(rs.getString("fx_name"));
		return obj;

}
}