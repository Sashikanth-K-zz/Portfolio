package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;


import com.bku.inautix.model.RestBean;

public class RestRowMapper implements RowMapper<RestBean> {
	public RestBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		RestBean obj = new RestBean();		
		//obj.setId(rs.getInt("id"));
		//obj.setName(rs.getString("name"));
		obj.setUsrname(rs.getString("usrname"));
		obj.setPasswd(rs.getString("passwd"));
		obj.setName(rs.getString("name"));
		return obj;
	}
}

