$('#myCarousel').carousel({
    interval: 1000
  
});



$('#myCarousel').on('slide', function () {
    //alert("Slide Event");
    console.log('slid event');
});