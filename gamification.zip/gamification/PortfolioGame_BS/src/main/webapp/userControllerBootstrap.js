/**
 * 
 */
var ipaddress="172.24.34.90:8090";
var myApp=angular.module('myApp',[]) .config(['$provide', function($provide) {
    $provide.decorator('$locale', ['$delegate', function($delegate) {
        if($delegate.id == 'en-us') {
          $delegate.NUMBER_FORMATS.PATTERNS[1].negPre = '-\u00A4';
          $delegate.NUMBER_FORMATS.PATTERNS[1].negSuf = '';
        }
        return $delegate;
      }]);
    }]);



myApp.controller('userCtrl1',function($scope, $http) {
	$scope.upper = function()
	{
		
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname)
		.success(function(response) 
			{
				$scope.holding=response.holding; 
				
			});
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/history/"+$scope.usrname)
		.success(function(response)
			{
				$scope.transactionhistory=response.transactionhistory;
			});	
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/service/user/"+ $scope.usrname+ "/"+ $scope.getDatetime)
		.success(function(response) {
					$scope.userhomescreen = response.userhomescreen;
				});
	    

	}
	$scope.hasPendingRequests = function () {
		return $http.pendingRequests.length !== 0;
		};
	$scope.temp = function(name)
	{
		if(name ==1)
			$scope.buy();
		else
			$scope.sell();
	}
	
	$scope.sort = function(keyname){
	        $scope.sortKey = keyname;   //set the sortKey to the param passed
	        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
	}
	
	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/lose")
	.success(function(response) 
	{
			
			$scope.l=response.losegain;
	});

	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gain")

	.success(function(response) 
				{
		$scope.g=response.losegain;
		
				});

	//var data = sessionStorage.getItem('name');
	//if(data == null)
		//{
		//window.location.replace("http://172.24.34.90:8090/PortfolioGame/index-bootstrap.jsp");
		//}
	
	
	var data = localStorage.getItem('name');
  if(data == null)
{ 
	 alert('logged out');
	window.location.replace("http://172.24.34.90:8090/PortfolioGame/index-bootstrap.jsp");
 }
//	var x= document.cookie;
	//if(x=="")
		//{
		//alert("cleared yah");
	//	window.location.replace("http://172.24.34.90:8090/PortfolioGame/index-bootstrap.jsp");
		//}
	$scope.loggerout = function()
	{
		localStorage.removeKey('name');
		alert("I was here");
	}
	$scope.m_index = 0;
	 $('[data-toggle="popover"]').popover(); 
	$scope.mismatch=false;
	$scope.signupdef=false;
	$scope.logindef=false;
	$scope.logedon=true;
	$scope.getDatetime  = new Date();
	$scope.defaulter = {ratio:"50:50"};
	$scope.defaulter = {rate:"1"};
    $scope.defaulter = {fund:"1"};
    $scope.defaulter = {equities:"1"};
    $scope.defaulter = {forex:"1"};
    $scope.defaulter = {bonds:"1"};
	$scope.defaulter = {futures:"1"};
	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
	.success(function(response) 
		{
			$scope.marketPrice=response.marketPrice;
		});
	

	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
		if (response.session)
{
			$scope.uname=response.session.name;
		   $scope.usrname=response.session.id;
		   $scope.getDatetime= new Date();
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/service/auto_update/"+$scope.getDatetime)
			.success(function(response) {
					//alert("Inside auto_update");
					$scope.upper();
					});
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/getadviceuser/"+$scope.usrname).success( function(response){
			
			$scope.advicelist=response.advice;
			

		
		});
		$scope.getDatetime  = new Date();
$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/getbrokername/"+$scope.usrname).success( function(response){
			
			$scope.brokerdetails=response.viewdetails;
			

		
		});
		
		
$http.get(
		"http://"
				+ ipaddress
				+ "/MyRestDB/cxfservlet/jaxrs-server/service/user/"
				+ $scope.usrname
				+ "/"
				+ $scope.getDatetime)
.success(
		function(response) {
			$scope.userhomescreen = response.userhomescreen;
		});

		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname)
		.success(function(response) 
			{
			var total=0;
			for (i = 0; i < response.holding.length; i++) {
				total += (response.holding[i].amount_lg);
			}
				$scope.holdonvalue=total;
				if ($scope.holdonvalue < 0) {
					document
							.getElementById("holdons1").style.color = "#FF0000";
					document
							.getElementById("percent").style.color = "#FF0000";
					alert("LOSS :(");
				} else if ($scope.holdonvalue > 0) {
					document
							.getElementById("holdons1").style.color = "#00FF00";
					document
							.getElementById("percent").style.color = "#00FF00";
					alert("PROFIT :)");
				}
			});
		
		
		$scope.set_color = function (x) {
			  if (x.amount_lg > 0) {
			    return { color: "#00FF00" }
			  }
			  else if(x.amount_lg < 0){
				  return { color: "#FF0000" }
			  }
				  else
					  {}
				};
			
			$scope.set_color_per = function (x) {
				  if (x.percentage_lg > 0) {
				    return { color: "#00FF00" }
				  }
				  else if(x.percentage_lg < 0){
					  return { color: "#FF0000" }
				  }
				  else{}
				};
		
		
		
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname)
		.success(function(response) 
			{
				$scope.holding=response.holding;
			});
		
	
		
		$scope.save = function()
		{
			var bid= 1;
			bid = $('input[name=broker]:checked', '#saveform').val(); 
			var today = new Date();
			stamp= parseDate(today);
			function parseDate(d) {

			    var monthNames = [ "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" ],
			        d2 = d.getFullYear() +'-'+monthNames[d.getMonth()] +'-'+ d.getDate()+'-'+d.getHours();

			    return d2;
			} 
			
			$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/player/savebroker/"+$scope.usrname+"/"+bid+"/"+stamp)
			.success(function(response) 
					{
				$scope.savings=response.saving;
				leng = Object.keys($scope.savings).length;
				//console.log(Object.keys($scope.savings).length);
				if(leng != 0){
				//console.log($scope.savings[0].stamp);
				if($scope.savings[0].locked == "yes")
					alert("Already done for the Day!");
				else{
					alert("Successfully Updated!");
					window.location.replace("http://172.24.34.90:8090/PortfolioGame/userbootstrap.jsp");
				}
				
				}
				
				
				else{
					alert("Successfully Updated!");
					window.location.replace("http://172.24.34.90:8090/PortfolioGame/userbootstrap.jsp");
				}
				
						
		
						
					});
			
		};



	$scope.getDatetime  = new Date();
		$scope.buy = function() 	
		{
			var bid= 1;
			var flag =0;
			$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/getbrokername/"+$scope.usrname).success( function(response){
				
				$scope.bid=response.viewdetails[0].brokerId;
				//alert("Broker id"+$scope.bid);
				bid = $scope.bid;
			
			});
			
			//alert("final"+bid);
			
			var today = new Date();
			stamp= parseDate(today);
			function parseDate(d) {

			    var monthNames = [ "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" ],
			        d2 = d.getFullYear() +'-'+monthNames[d.getMonth()] +'-'+ d.getDate()+'-'+d.getHours();

			    return d2;
			} 
			if($scope.quantity==null || $scope.quantity == "")
			{
			alert("Please enter valid quantity before you proceed");
			}
		else if($scope.quantity%1!=0.0)
		{
		alert("Please enter valid integers before you proceed");
		}
		else if($scope.sec==null)
			{
			alert("Please select the security type");
			}
		else if($scope.name==null)
			{
			if($scope.sec=="Equity")
			alert("Please select the appropriate stock type");
			else if($scope.sec=="Bonds")
				alert("Please select the appropriate bond");
			else if($scope.sec=="FX")
				alert("Please select the appropriate FX");
			else
				alert("Please select the appropriate Fund");
			}
		else
			{

			if($scope.equ=="Cash")
				{
				if($scope.name.indexOf("/")>-1)
					{
					$scope.name=$scope.name.replace("/","-");
					
					}
				if($scope.name.indexOf("%")>=-1)
					{
					$scope.name=$scope.name.replace("%","-");
					}
				$http
				.get(
						"http://"
								+ ipaddress
								+ "/MyRestDB/cxfservlet/jaxrs-server/service/buy/"
								+ $scope.name + "/"
								+ $scope.price + "/"
								+ $scope.getDatetime
								+ "/" + $scope.quantity
								+ "/" + $scope.usrname+"/"+$scope.sec)
	    .success(function(response)
		    
			{
	    	
	    	if (response.transactions == null) {
	    		//alert(bid);
	    		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/player/savedbroker/"+$scope.usrname+"/"+bid+"/"+stamp)
    			.success(function(response) {
    					
    				$scope.savings=response.saving;
    				//alert("is this empty?"+$scope.savings);
    				leng = Object.keys($scope.savings).length;
    				//alert("length"+leng);
    				//console.log(Object.keys($scope.savings).length);
    				if(leng == 0){
    				//console.log($scope.savings[0].stamp);
  
    					alert("Please select a broker before making a trade");
    					flag =1;
    		
    				
    				}	
    					 
    				 });
	    		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
	    			
	    		


	    			/*$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/player/savebroker/"+$scope.usrname+"/"+bid+"/"+stamp)
	    			.success(function(response) {
	    					
	    				$scope.savings=response.saving;
	    				leng = Object.keys($scope.savings).length;
	    				alert("length"+leng);
	    				//console.log(Object.keys($scope.savings).length);
	    				if(leng != 0){
	    				//console.log($scope.savings[0].stamp);
	    					alert($scope.savings[0].locked);
	    				if($scope.savings[0].locked == "yes")
	    					alert("Please select a broker before making a trade");
	    				
	    				}			
	    					 if(response.saving==null)
	    		    			{
	    							alert("Please check your balance");
	    		    			}
	    					 
	    				 }); */
	    				 
	    			    if(response.saving==null && flag ==0)
		    			{
							alert("Please check your balance.If you still want to continue,use marginal fund");
		    			}
		    			//}if (response.session) {
		    		//		alert("Please select a broker before making a trade");
						
					/*else
						window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp"); */
	    		});
			} else {
				/*$scope.name = response.name;
				$scope.quantity = response.quantity;
				$scope.holding = response.holding;
				$scope.price = response.price;
				$scope.amount_lg = response.amount_lg;
				$scope.percentage_lg = response.percentage_lg;
				$scope.current_holding = response.current_holding; */
				$scope.upper();
				alert("Trade executed successfully!");
				//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");

			
			}
          
	    	
		
		});}
			else if($scope.sec=="Bonds")
				{
				if($scope.name.indexOf("/")>-1)
					{
					$scope.name=$scope.name.replace("/","-");
					
					}
				if($scope.name.indexOf("%")>-1)
				{
				$scope.name=$scope.name.replace("%","-");
				
				}
				$http
				.get(
						"http://"
								+ ipaddress
								+ "/MyRestDB/cxfservlet/jaxrs-server/service/buy/"
								+ $scope.name + "/"
								+ $scope.price + "/"
								+ $scope.getDatetime
								+ "/" + $scope.quantity
								+ "/" + $scope.usrname+"/"+$scope.sec)
	    .success(function(response)
		    
			{
	    	
	    	if (response.transactions == null) {
	    		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
	    			
	    			 if(response.saving==null)
		    			{
							//alert("Insufficient Balance");
	    				 alert("Please check your credentials with broker or balance");
			    			//} if (response.session) {
			    				//alert("Please select a broker before making a trade");
							}
					/*else
						window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp"); */
	    		});
			} else {
				$scope.name = response.name;
				$scope.quantity = response.quantity;
				$scope.holding = response.holding;
				$scope.price = response.price;
				$scope.amount_lg = response.amount_lg;
				$scope.percentage_lg = response.percentage_lg;
				$scope.current_holding = response.current_holding; 
				$scope.upper();
				alert("Trade executed successfully!");
				//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");

			
			}
          
	    	
		
		});} 
				
		    else if($scope.equ=="MarginFund")
			{
		    
			$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/buyequity/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname+"/"+$scope.sec+"/"+$scope.equ)

            .success(function(response)
                   {
	    //	$scope.sample=response.employee1;
	    	/*var x1 = $scope.sample[0].remaining;
	    	console.log(x1);
	    	$scope.holdonvalue -= x1;*/
	    	if(response.transactions==null)
	    	{
	    		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
	    			
	    			 if (response.session) {
							
	    				 alert("Please check your credentials with broker or balance");
	    		    		//alert("Insufficient balance to use marginal fund");
	    				//		}
	    			//if(response.saving==null)
	    			//{
		    			//alert("Please select a broker before making a trade");
		    			}
					//else
						//window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
	    		});
	    	}

	    	else
	    	{
	    		$scope.upper();
	    		alert("Trade executed successfully!");
	    		//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
                        // $scope.user1=response.user;
	    	}
            });

    		
    	}


		}
			$scope.name = null;
	}
			
		/*
		 * Selling an equity
		*/
		
		$scope.sell = function() 	
		{
			if($scope.quantity==null || $scope.quantity=="")
			{
			alert("Please enter quantity before you proceed");
			}
			else if($scope.quantity%1!=0.0)
			{
			alert("Please enter valid integers before you proceed");
			}
			else if($scope.sec==null)
				{
				alert("Please select the security type");
				}
				else if($scope.name==null)
				{if($scope.sec=="Equity")
				alert("Please select the appropriate stock type");
				else if($scope.sec=="Bonds")
					alert("Please select the appropriate bond");
				else if($scope.sec=="FX")
					alert("Please select the appropriate FX");
				else
					alert("Please select the appropriate Fund");
				}
		else
			{
			if($scope.sec=="FX")
			{
				if($scope.name.indexOf("/")>-1)
				{
				$scope.name=$scope.name.replace("/","-");
				
				}
	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/sell/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname+"/"+$scope.sec)
	.success(function(response)
	{			
		
		if(response.transactions==null)
				{
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck")
		.success(function(response) {
			if (response.session) {
				$scope.upper();
				alert("Required security not available");
				//window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
						//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
						}
						else {
							$scope.upper();
							alert("Trade executed successfully!");
							$scope.name = null;
						}
					});
			}
		else
			{
			        $scope.upper();
					alert("Trade executed successfully!");
					$scope.name = null;
					//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
				}
			});
			}
			else if($scope.sec=="Bonds")
			{
				if($scope.name.indexOf("/")>-1)
				{
				$scope.name=$scope.name.replace("/","-");
				
				}
				if($scope.name.indexOf("%")>-1)
				{
				$scope.name=$scope.name.replace("%","-");
				
				}
	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/sell/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname+"/"+$scope.sec)
	.success(function(response)
	{			
		
		if(response.transactions==null)
				{
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck")
		.success(function(response) {
			if (response.session) {
				$scope.upper();
				alert("Required security not available");
				//window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
						//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
						}
						else {
							$scope.upper();
							alert("Trade executed successfully!");
							$scope.name = null;
						}
					});
			}
		else
			{
			        $scope.upper();
					alert("Trade executed successfully!");
					$scope.name = null;
					//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
				}
			});
			}
			else if($scope.sec=="MF")
			{
				if($scope.name.indexOf("/")>-1)
				{
				$scope.name=$scope.name.replace("/","-");
				
				}
	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/sell/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname+"/"+$scope.sec)
	.success(function(response)
	{			
		
		if(response.transactions==null)
				{
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck")
		.success(function(response) {
			if (!response.session) {
						$scope.upper();
						alert("Trade executed successfully!");
						$scope.name = null;
						//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
						}
						else {
							$scope.upper();
							alert("Required security not available");
							//window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
						}
					});
			}
		else
			{
			        $scope.upper();
					alert("Trade executed successfully!");
					$scope.name = null;
					//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
				}
			});
			}
			else if($scope.equ=="Cash")
			{
			//	if($scope.name.indexOf("/")>-1)
		//		{
			//	$scope.name=$scope.name.replace("/","-");
				
		//		}
	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/equitysell1/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname+"/"+$scope.sec+"/"+"MarginFund")
	.success(function(response)
	{			
		
		if(response.transactions==null)
				{
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck")
		.success(function(response) {
			if (!response.session) {
						$scope.upper();
						alert("Trade executed successfully!");
						$scope.name = null;
						//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
						}
						else {
							$scope.upper();

							alert("Required security not available");
							//window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
						}
					});
			}
		else
			{
			        $scope.upper();
					alert("Trade executed successfully!");
					$scope.name = null;
					//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
				}
			});
			}
			else if($scope.equ=="MarginFund")
			{
			 $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/equitysell1/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname+"/"+$scope.sec+"/"+$scope.equ)
			.success(function(response)
			{
				if (response.transactions== null) {
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session) {
						
					alert("Required equities not available");
						}
						else
							
					window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
					});
				} else {
					$scope.upper();
					alert("Trade executed successfully!");
					$scope.name = null;
					//window.location.replace("http://"+ipaddress+"/PortfolioGame/userbootstrap.jsp");
				}
				
				});
			}
			}
			
			
			
			};
			
			
			

		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/history/"+$scope.usrname)
		.success(function(response)
			{
				$scope.transactionhistory=response.transactionhistory;
			});	
		
		$scope.holdingsBootstrap=true;	
		
}
		});
	
	 


	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/news/"+$scope.getDatetime,{cache:false})
	.success(function(response) 
		{
			$scope.newson=response.news;
		});


	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/gamers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
	.success(function(response) {$scope.gamers=response.gamer;});
	
	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/losers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
	.success(function(response) {$scope.gamers1=response.gamer;});
	 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/bondsName")
	    .success(function(response)
		{
	    	$scope.bonds=response.bonds;
			 please
		}); 
	 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/MFName/")
	    .success(function(response)
		{
	    	$scope.MF=response.mf;
			 
		}); 
	  $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/FXName/")
	    .success(function(response)
		{
	    	$scope.FX=response.fx;
			 
		}); 
	  $scope.getSecurity=function()
		{
		
			$scope.equ="Cash";
			if($scope.sec=="Equity"){
				
				$scope.eq=true;
				$scope.searchequity=true;
				$scope.searchbonds=false;
				$scope.searchmf=false;
				$scope.searchfx=false;
				
			}else if($scope.sec=="Bonds")
				{
				
				$scope.searchmf=false;
				$scope.searchfx=false;
				$scope.searchequity=false;
				$scope.eq=false;
				$scope.searchbonds=true;
				
				}	
			else if($scope.sec=="MF")
				{
				
				$scope.searchmf=true;
				$scope.eq=false;
				$scope.searchequity=false;
				$scope.searchfx=false;
				$scope.searchbonds=false;
				
				}
			else if($scope.sec=="FX")
			{
			
			$scope.searchmf=false;
			$scope.eq=false;
			$scope.searchequity=false;
			$scope.searchfx=true;
			$scope.searchbonds=false;

			
			}
					else{
						alert("Choose security type");
					}
			
		}
		
/*	$(document).ready(function(){
	    $('[data-toggle="tooltip"]').tooltip();   
	});*/
	 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/1")
     .success(function(response) 
            {
            /*if(response.brokeraging==null)
            {
            alert("SERVER DOWN");
            }*/
     
            $scope.icici=response.brokeraging;
            });
	 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/2")
     .success(function(response) 
            {
            /*if(response.brokeraging==null)
            {
            alert("SERVER DOWN");
            }*/
     
            $scope.hdfc=response.brokeraging;
            });
	 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/3")
     .success(function(response) 
            {
            if(response.brokeraging==null)
                  {
         	 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
                  }
            
            $scope.sharekhan=response.brokeraging;
  
            
            });

	$scope.getData = function(data)
	{
		document.getElementById('stockselect').value=data;
	    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+data)
	    .success(function(response)
		{
	    	$scope.price=response.employee.price;
		});
	}
	
	
	
	

	
	/*
	$scope.hello = function() {
		$scope.register=false;
		$scope.l1=true;		
	    $scope.employees=null;
	    $scope.flag = false;
	    $scope.stocks=false;
	    $scope.admin=false;
	};
	
	$scope.reset = function() {
		$scope.l1=false;
		$scope.register=true;
	    $scope.employees=null;
	    $scope.flag = false;
	};*/
	
	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/equitiesName")
	.success(function(response) {$scope.stocks=response.equitylist;
	$scope.list = {
	        data: [{
	          
	            name: 'Equity'
	        }, {
	           
	            name: 'Bonds'
	        },{
	           
	            name: 'MF'
	        },{
	           
	            name: 'FX'
	        }]
	    };   	})
	.error(function(response) {$scope.name="error";});
		
	$scope.flag2=false;
	/*$scope.getStock = function() 
	{
		$scope.flag2=true;
	    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+$scope.name)
	    .success(function(response)
		{
	    	$scope.employee=response.employee;
			 
		});    
	};
	
	$scope.getPrice=function()
	{
	    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/equity/"+$scope.name)
	    .success(function(response)
		{
	    	$scope.price=response.equity.price;
		});

	}
*/

	$scope.set_losecolor = function () {
		
		 return { color: "#990000" }
}
$scope.set_gaincolor = function () {
	 
		 return { color: "#006600" }
  
}

	
	$scope.getDatetime  = new Date();
	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/mosttraded/"+$scope.getDatetime)
	.success(function(response)
		{
			$scope.mosttraded=response.mosttraded;
		});	
	
		
	$scope.getEquityPrice=function()
	{
		$scope.flag2=true;
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/equity/"+$scope.name)
	    .success(function(response)
		{
	    		
											
										$scope.price=response.equity.price;
										
										
		});

	}

	
	$scope.getBondPrice=function()
	{
	
		$scope.flag2=true;
		var x=$scope.name;
		var x1=x.split("%");
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/bonds/"+x1[0])
	    .success(function(response)
		{
	    	$scope.price=response.BondPrice.bond_price;
		});
	
	};
	$scope.getMfPrice=function()
	{
		$scope.flag2=true;
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/MF/"+$scope.name)
	    .success(function(response)
		{
	    	$scope.price=response.mfp.price;
		});

	};
	
	$scope.getFxPrice=function()
	{
		$scope.flag2=true;
		var x=$scope.name;
		var x1=x.split("/");
	
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/FX/"+x1[0]+"/"+x1[1])
	    .success(function(response)
		{
	    	$scope.price=response.fxp.price;
		});
	};
	



	/*
	 * Log out for users
	*/
		$scope.logout = function()
		{
			$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/logOut")
			.success(function(response) 
					{
						alert("Successfully logged out");
						window.location.replace("http://172.24.34.90:8090/PortfolioGame/index-bootstrap.jsp");
					});
		};
});





myApp.controller('loginCtrl1',function($scope, $http) {
	
	/*	$(document).ready(function(){
		    $('[data-toggle="popover"]').popover();   
		});*/
		$scope.m_index = 0;
		 $('[data-toggle="popover"]').popover(); 
		$scope.mismatch=false;
		$scope.signupdef=true;
		$scope.logindef=true;
		$scope.getDatetime  = new Date();

		$scope.set_losecolor = function () {
			
			 return { color: "#990000" }
	}
	$scope.set_gaincolor = function () {
		 
			 return { color: "#006600" }
	  
	}
	$scope.sort = function(keyname){
	        $scope.sortKey = keyname;   //set the sortKey to the param passed
	        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }
		
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
		.success(function(response) 
			{
				$scope.marketPrice=response.marketPrice;
			});

	/*	$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/preStocks")
		.success(function(response) 
			{
				$scope.premarketPrice=response.stock;
			});*/

		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/news/"+$scope.getDatetime,{cache:false})
		.success(function(response) 
			{
				$scope.newson=response.news;
			});


		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/gamers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
		.success(function(response) {$scope.gamers=response.gamer;});
		
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/losers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
		.success(function(response) {$scope.gamers1=response.gamer;});
		 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/bondsName")
		    .success(function(response)
			{
		    	$scope.bonds=response.bonds;
				 
			}); 
		 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/MFName/")
		    .success(function(response)
			{
		    	$scope.MF=response.mf;
				 
			}); 
		  $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/FXName/")
		    .success(function(response)
			{
		    	$scope.FX=response.fx;
				 
			}); 
		  $scope.getSecurity=function()
			{
			
				$scope.equ="Cash";
				if($scope.sec=="Equity"){
					
					$scope.eq=true;
					$scope.searchequity=true;
					$scope.searchbonds=false;
					$scope.searchmf=false;
					$scope.searchfx=false;
					
				}else if($scope.sec=="Bonds")
					{
					
					$scope.searchmf=false;
					$scope.searchfx=false;
					$scope.searchequity=false;
					$scope.eq=false;
					$scope.searchbonds=true;
					
					}	
				else if($scope.sec=="MF")
					{
					
					$scope.searchmf=true;
					$scope.eq=false;
					$scope.searchequity=false;
					$scope.searchfx=false;
					$scope.searchbonds=false;
					
					}
				else if($scope.sec=="FX")
				{
				
				$scope.searchmf=false;
				$scope.eq=false;
				$scope.searchequity=false;
				$scope.searchfx=true;
				$scope.searchbonds=false;

				
				}
						else{
							alert("Choose security type");
						}
				
			}
			
	/*	$(document).ready(function(){
		    $('[data-toggle="tooltip"]').tooltip();   
		});*/
		 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/1")
	     .success(function(response) 
	            {
	            /*if(response.brokeraging==null)
	            {
	            alert("SERVER DOWN");
	            }*/
	     
	            $scope.icici=response.brokeraging;
	            });
		 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/2")
	     .success(function(response) 
	            {
	            /*if(response.brokeraging==null)
	            {
	            alert("SERVER DOWN");
	            }*/
	     
	            $scope.hdfc=response.brokeraging;
	            });
		 $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/3")
	     .success(function(response) 
	            {
	            if(response.brokeraging==null)
	                  {
	         	 
	            	window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
	                  }
	            
	            $scope.sharekhan=response.brokeraging;
	  
	            
	            });

		$scope.getData = function(data)
		{
			document.getElementById('stockselect').value=data;
		    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+data)
		    .success(function(response)
			{
		    	$scope.price=response.employee.price;
			});
		}
		
		$scope.modified = function() {
			alert("Modified by <br/> Ashwin Suresh Babu | Irudhaya Rajasekar Subramani | Sneha Sampath | Divya N Vinod | Harishkanth Shreekanth Gendikodta ");
			};
			
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.uid)
		.success(function(response) 
			{
				$scope.holding=response.holding;
			});
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/history/"+$scope.uid)
		.success(function(response)
			{
				$scope.transactionhistory=response.transactionhistory;
			});	
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/getadviceuser/"+$scope.uid).success( function(response){
			
			$scope.advicelist=response.advice;
			
	$scope.gridOptions = { data: 'marketPrice' };
		
			
		});
		$scope.getEmployee = function() {
		    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/commonservice/login/"+$scope.usrname+"/"+$scope.passwd)
			.success(function(response) {
				$scope.warningrefresher();
				$scope.session = response.session;
				var flag = 0;
                if((document.getElementById("usrname11").value == "") || (document.getElementById("passwd11").value == "") )
                	{
                	flag = 1;
                	 if((document.getElementById("usrname11").value == ""))
                		 {
                	 document.getElementById("loginuserfield").style.display = "block";
                		 }
                	 if((document.getElementById("passwd11").value == ""))
            		 {
            	 document.getElementById("loginpassfield").style.display = "block";
            		 }
                	//alert("Please fill all the empty fields");
                	}
                else if (!$scope.session) {
                	flag = 1;
                	 document.getElementById("mismatch").style.display = "block";
					//alert("Username and password mismatch!!");
				} if(flag == 0){
			 if($scope.usrname==response.session.id)
			
			  if(response.session.type=='u')
					{
			$scope.flag= false;
			alert("Welcome to Portfolio Game "+ $scope.usrname+ "!!!");
			document.getElementById('welcomeDiv').style.visibility = "visible";
			$scope.uname=response.session.name;
			//sessionStorage.setItem('name', $scope.uname);
			localStorage.setItem('name',$scope.uname);
		   // document.cookie = "username="+$scope.uname;
			//alert("Time to delete a key");
			//localStorage.removeItem('name');
			$scope.signupdef=false;
			$scope.logindef=false;
			$scope.logedon=true;
			
			window.location.replace("http://172.24.34.90:8090/PortfolioGame/userbootstrap.jsp");
			
					}
			  else if (response.session.type == 'b') {
					window.location
							.replace("http://"
									+ ipaddress
									+ "/PortfolioGame/broker1.jsp");
				}  
			  else if(response.session.type=='a')
				{
				$scope.flag= false;
				alert("Welcome Admin");		
				document.getElementById('welcomeDiv').style.visibility = "visible";
				window.location.replace("http://172.24.34.90:8090/PortfolioGame/admin.jsp");
				}
				}
			});
		    $scope.employees=null;
		};

		$scope.getEmployee1 = function(keyEvent) {
			 if (keyEvent.which === 13)
				 {
		    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/commonservice/login/"+$scope.usrname+"/"+$scope.passwd)
			.success(function(response) {
				$scope.warningrefresher();
				$scope.session = response.session;
				var flag = 0;
                if((document.getElementById("usrname11").value == "") || (document.getElementById("passwd11").value == "") )
                	{
                	flag = 1;
                	 if((document.getElementById("usrname11").value == ""))
                		 {
                	 document.getElementById("loginuserfield").style.display = "block";
                		 }
                	 if((document.getElementById("passwd11").value == ""))
            		 {
            	 document.getElementById("loginpassfield").style.display = "block";
            		 }
                	//alert("Please fill all the empty fields");
                	}
                else if (!$scope.session) {

                	flag = 1;
                	 document.getElementById("mismatch").style.display = "block";
              
					//alert("Username and password mismatch!!");
				} if(flag == 0){
			 if($scope.usrname==response.session.id)
			  if(response.session.type=='u')
					{
			$scope.flag= false;
			alert("Welcome to Portfolio Game "+ $scope.usrname + "!!!");
			document.getElementById('welcomeDiv').style.visibility = "visible";
			$scope.uname=response.session.name;
			//sessionStorage.setItem('name', $scope.uname);
			localStorage.setItem('name',$scope.uname);
		   // document.cookie = "username="+$scope.uname;
			//alert("Time to delete a key");
			//localStorage.removeItem('name');
			$scope.signupdef=false;
			$scope.logindef=false;
			$scope.logedon=true;
			
			window.location.replace("http://172.24.34.90:8090/PortfolioGame/userbootstrap.jsp");
			
					}
			  else if (response.session.type == 'b') {
					window.location
							.replace("http://"
									+ ipaddress
									+ "/PortfolioGame/broker1.jsp");
				}  
			  else if(response.session.type=='a')
				{
				$scope.flag= false;
				alert("Welcome Admin");		
				document.getElementById('welcomeDiv').style.visibility = "visible";
				window.location.replace("http://172.24.34.90:8090/PortfolioGame/admin.jsp");
				}
				}
			});
		    $scope.employees=null;
		};
		
		}
		
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/equitiesName")
		.success(function(response) {$scope.stocks=response.equitylist;
		$scope.list = {
		        data: [{
		          
		            name: 'Equity'
		        }, {
		           
		            name: 'Bonds'
		        },{
		           
		            name: 'MF'
		        },{
		           
		            name: 'FX'
		        }]
		    };   	})
		.error(function(response) {$scope.name="error";});
			
		$scope.flag2=false;
		$scope.getStock = function() 
		{
			$scope.flag2=true;
		    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+$scope.name)
		    .success(function(response)
			{
		    	$scope.employee=response.employee;
				 
			});    
		};
		
		$scope.getPrice=function()
		{
		    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/equity/"+$scope.name)
		    .success(function(response)
			{
		    	$scope.price=response.equity.price;
			});

		}

		
		
		$scope.trade = function() 
		{
		    $http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+$scope.chuma)
		    .success(function(response)
			{
		    	$scope.name1=response.employee;
			});
		};

		
		
		$scope.getDatetime  = new Date();
		$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/mosttraded/"+$scope.getDatetime)
		.success(function(response)
			{
				$scope.mosttraded=response.mosttraded;
			});	
		
			
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/service/auto_update/"+$scope.getDatetime)
		.success(function(response) {
				//alert("Inside auto_update");
			   // window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp");
				});

		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/lose")
		.success(function(response) 
		{
				
				$scope.l=response.losegain;
		});

		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gain")

		.success(function(response) 
					{
			$scope.g=response.losegain;
			
					});

    $scope.warningrefresher = function() {
    	  document.getElementById("regpass1field1").style.display = "none";
    	  document.getElementById("regpass2field1").style.display = "none";
    	  document.getElementById("reguserfield1").style.display = "none";
    	  document.getElementById("reguserfield2").style.display = "none";
    	  document.getElementById("namefield").style.display = "none";
    	  document.getElementById("emailfield").style.display = "none";
    	  document.getElementById("emailfield2").style.display = "none";
    	  document.getElementById("regpass1field2").style.display = "none";
	      document.getElementById("regpass2field2").style.display = "none";
	      document.getElementById("mismatch").style.display = "none";
	      document.getElementById("loginuserfield").style.display = "none";
	      document.getElementById("loginpassfield").style.display = "none";
    }
	$scope.registerfunction = function() {
		$scope.warningrefresher();
		$http
				.get(
						"http://"
								+ ipaddress
								+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/register/"
								+ $scope.regusrname
								+ "/"
								+ $scope.passwd1
								+ "/"
								+ $scope.regname
								+ "/"
								+ $scope.mail
								)
				.success(
						function(response) {
							$scope.session=response.session;
							 var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				             var flag = 0;
							   if((document.getElementById("passwd1").value == ""))
							   {
								   flag = 1;
								   document.getElementById("regpass1field1").style.display = "block";
							   } 
							   if((document.getElementById("passwd2").value == ""))
							   {
								   flag = 1;
								   document.getElementById("regpass2field1").style.display = "block";
							   }
							   if((document.getElementById("myin").value == ""))
							   {
								   flag = 1;
							   document.getElementById("reguserfield1").style.display = "block";
							   }
							   else if(!$scope.session) {
								   flag = 1;
								   document.getElementById("reguserfield2").style.display = "block";
							
							   }
							   if((document.getElementById("namer").value == ""))
							   {
								   flag = 1;
							   document.getElementById("namefield").style.display = "block";
							   }
							   if((document.getElementById("mailer").value == ""))
							   {
								   flag = 1;
							   document.getElementById("emailfield").style.display = "block";
							   }
							   else if(re.test(document.getElementById("mailer").value)== false)
							   { 
								   flag = 1;
								   document.getElementById("emailfield2").style.display = "block";
							   }
							   if (document
										.getElementById("passwd1").value != document
										.getElementById("passwd2").value) {
								   flag = 1;
								 document.getElementById("regpass1field2").style.display = "block";
								 document.getElementById("regpass2field2").style.display = "block";
								}
							if(flag == 0){
								alert("Welcome to Portfolio Game");
								document.getElementById('welcomeDiv').style.visibility = "visible";
								window.location.replace("http://172.24.34.90:8090/PortfolioGame/userbootstrap.jsp");
							}	
						});
	
						
		}

						
	

		$scope.registerfunction1 = function(keyEvent) {
			 if (keyEvent.which === 13)
				 {
		$scope.warningrefresher();
		$http
				.get(
						"http://"
								+ ipaddress
								+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/register/"
								+ $scope.regusrname
								+ "/"
								+ $scope.passwd1
								+ "/"
								+ $scope.regname
								+ "/"
								+ $scope.mail
								)
				.success(
						function(response) {
							$scope.session=response.session;
							 var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				             var flag = 0;
							   if((document.getElementById("passwd1").value == ""))
							   {
								   flag = 1;
								   document.getElementById("regpass1field1").style.display = "block";
							   } 
							   if((document.getElementById("passwd2").value == ""))
							   {
								   flag = 1;
								   document.getElementById("regpass2field1").style.display = "block";
							   }
							   if((document.getElementById("myin").value == ""))
							   {
								   flag = 1;
							   document.getElementById("reguserfield1").style.display = "block";
							   }
							   else if(!$scope.session) {
								   flag = 1;
								   document.getElementById("reguserfield2").style.display = "block";
							
							   }
							   if((document.getElementById("namer").value == ""))
							   {
								   flag = 1;
							   document.getElementById("namefield").style.display = "block";
							   }
							   if((document.getElementById("mailer").value == ""))
							   {
								   flag = 1;
							   document.getElementById("emailfield").style.display = "block";
							   }
							   else if(re.test(document.getElementById("mailer").value)== false)
							   { 
								   flag = 1;
								   document.getElementById("emailfield2").style.display = "block";
							   }
							   if (document
										.getElementById("passwd1").value != document
										.getElementById("passwd2").value) {
								   flag = 1;
								 document.getElementById("regpass1field2").style.display = "block";
								 document.getElementById("regpass2field2").style.display = "block";
								}
							if(flag == 0){
								alert("Welcome to Portfolio Game");
								document.getElementById('welcomeDiv').style.visibility = "visible";
								window.location.replace("http://172.24.34.90:8090/PortfolioGame/userbootstrap.jsp");
							}	
						});
	
						
		}}
		

						
									/*
									 * Log out for users
									*/
										$scope.logout = function()
										{
											
											$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/logOut")
											.success(function(response) 
													{
												        $scope.loggerout();
														alert("Successfully logged out");
														window.location.replace("http://172.24.34.90:8090/PortfolioGame/index-bootstrap.jsp");
														
													});
										};
										
								});
