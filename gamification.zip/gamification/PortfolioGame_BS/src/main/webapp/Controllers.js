/*
 * ********************************************************************************
 * User Controller
 * @Author - XBBLWSQ
 * ********************************************************************************
 * 
 */
var ipaddress="172.24.34.90:8090";
var myApp=angular.module('myApp',['ngTouch','ui.grid']);
var context = localStorage.getItem("context");
/*
 * var loginApp=an
 *gular.module('loginApp',['ngTouch','ui.grid']);
var adminApp=angular.module('adminApp',['ngTouch','ui.grid']);
var brokerApp=angular.module('brokerApp',['ngTouch','ui.grid']);
angular.bootstrap(document, ['userApp']);
//angular.bootstrap(document, ['loginApp']);
angular.bootstrap(document, ['adminApp']);
angular.bootstrap(document, ['brokerApp']);
var context = localStorage.getItem("context");
*/
myApp.controller('userCtrl',function($scope, $http) {

					/*
					 * Checking Whether user is logged in or not by hitting
					 */
				var total=0;
				$scope.getDatetime= new Date();
				$http.get("http://172.24.34.90:8090/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
				.success(function(response) 
					{
						$scope.marketPrice=response.marketPrice;
					});
			
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
					if (response.session) {
						localStorage.setItem("username",response.session.id);
							if (response.session.type == 'a') {
								window.location
										.replace("http://"
												+ ipaddress
												+ "/PortfolioGame/admin.jsp");
							}
							else if (response.session.type == 'b') {
								window.location
										.replace("http://"
												+ ipaddress
												+ "/PortfolioGame/broker1.jsp");
							}  
							else if(response.session.type=='u') {
								$scope.session = response.session;
								$scope.username=$scope.session.name;
								$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/lose")
								.success(function(response) 
								{
										
										$scope.l=response.losegain;
								});

								$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gain")

								.success(function(response) 
											{
									$scope.g=response.losegain;
									
											});
								$scope.getDatetime= new Date();
		 		   						$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/service/auto_update/"+$scope.getDatetime)
										.success(function(response) {
												alert("Inside auto_update");
												});
								$http.get(
												"http://"
														+ ipaddress
														+ "/MyRestDB/cxfservlet/jaxrs-server/service/user/"
														+ $scope.session.id
														+ "/"
														+ $scope.getDatetime)
										.success(
												function(response) {
													$scope.userhomescreen = response.userhomescreen;
													/*
													 * if($scope.user1.glpercentage <
													 * 0) {
													 * document.getElementById("percent").style.color="#FF0000"; }
													 * else
													 * if($scope.user1.glpercentage >
													 * 0) {
													 * 
													 * document.getElementById("percent").style.color="#00FF00"; }
													 */
												});
								$http
										.get(
												"http://"
														+ ipaddress
														+ "/MyRestDB/cxfservlet/jaxrs-server/service/holding/"
														+ $scope.session.id)
														
										.success(
												function(response) {

													for (i = 0; i < response.holding.length; i++) {
														total += (response.holding[i].amount_lg);
													}
													$scope.holdonvalue = total;
													if ($scope.holdonvalue < 0) {
														document
																.getElementById("holdons1").style.color = "#FF0000";
														document
																.getElementById("percent").style.color = "#FF0000";
													} else if ($scope.holdonvalue > 0) {
														document
																.getElementById("holdons1").style.color = "#00FF00";
														document
																.getElementById("percent").style.color = "#00FF00";

													}
													
												});
								if(!localStorage.getItem("context") || localStorage.getItem("context")=="home")
									{
									$scope.home();
									}
								else if (localStorage.getItem("context")=="trades")
								{
									$scope.trades();
								}
								
					else if (localStorage.getItem("context")=="holdingfunction")
					{
						$scope.holdingfunction();
					}
else if (localStorage.getItem("context")=="viewEquities")
{
$scope.viewEquities();
}
else if (localStorage.getItem("context")=="news1")
{
$scope.news1();
}

								
								
								
								
							}
						}
						else {
							
							window.location.replace("http://"+ ipaddress+"/PortfolioGame/index-bootstrap.jsp");
						}
						
					

										
										
										
									});

	

	
/*
 * initial update on the screeen once the user is logged in
*/

					$scope.set_losecolor = function () {
						
						 return { color: "#990000" }
				}
				$scope.set_gaincolor = function () {
					 
						 return { color: "#006600" }
				  
				}

				
				
				$scope.getDatetime  = new Date();
		 		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/mosttraded/"+$scope.getDatetime)
		 		.success(function(response)
		 			{
		 				$scope.mosttraded1=response.mosttraded;
		 				$scope.flag2 = true;
		 			});				
//$scope.changeUploadAction = function()
//{
	//$scope.getDatetime= new Date();
		//$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/service/auto_update/"+$scope.getDatetime)
	//.success(function(response) {
			
		//	});
	//}
$scope.init = function() 
	{
		/*	
 * Default first screen theme
 */document.getElementById("l1").style.backgroundColor = "#2980b9";
 document.getElementById("l2").style.backgroundColor = "#2D2D2D";
 document.getElementById("l3").style.backgroundColor = "#2D2D2D";
 document.getElementById("l4").style.backgroundColor = "#2D2D2D";
 document.getElementById("l5").style.backgroundColor = "#2D2D2D";
 document.getElementById("l6").style.backgroundColor = "#2D2D2D";
 document.getElementById("l7").style.backgroundColor = "#2D2D2D";
 document.getElementById("advice").style.backgroundColor = "#2D2D2D";
 document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
 
 $scope.trade1=false;
 $scope.hold=false;
 $scope.equitypage=false;
 $scope.homeScreen=true;
 $scope.visecurities=false;
 $scope.news=false;
 $scope.bonds1=false;
 $scope.broker=false;
 $scope.showVolatile=false;
 $scope.advice=false;
 $scope.MFpage=false;
	$scope.FXpage=false;
 	    
 	    
 		$scope.getDatetime  = new Date();
 		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/mosttraded/"+$scope.getDatetime)
 		.success(function(response)
 			{
 				$scope.mosttraded1=response.mosttraded;
 				$scope.flag2 = true;
 			});	
 			
 		$scope.gridOptions = { data: 'mosttraded1' };

 		/*******************************13491************************************
 		*/
 		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gamers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
 		.success(function(response) {$scope.gamers=response.gamer;});
 			
 		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/losers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
 		.success(function(response) {$scope.gamers1=response.gamer;});
 			
 		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/news/"+$scope.getDatetime,{cache:false})
 		.success(function(response) 
 			{
 				$scope.newson=response.news;
 			});
 	};
 	
	
	/*  view Securities*/
 	
 	
 	$scope.viewSecurities = function() 
 	{

 	localStorage.setItem("context","trades");
 	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/checkbrokerexistence"+"/"+$scope.session.id)
 											.success(function(response)
 											{
 																				
 												document.getElementById("l1").style.backgroundColor = "#2D2D2D";
 												document.getElementById("l2").style.backgroundColor = "#2D2D2D";
 												document.getElementById("l3").style.backgroundColor = "#2D2D2D";
 												document.getElementById("l4").style.backgroundColor = "#2980b9";
 												document.getElementById("l5").style.backgroundColor = "#2D2D2D";
 												document.getElementById("l6").style.backgroundColor = "#2D2D2D";
 												/*document.getElementById("l7").style.backgroundColor = "#2D2D2D";*/
 												document.getElementById("advice").style.backgroundColor = "#2D2D2D";
 												document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
 												
 												  $scope.trade1=false;
 												   	$scope.hold=false;
 												   	$scope.homeScreen=false;
 												   	$scope.equitypage=false;
 												   	$scope.news=false;
 												   	$scope.broker=false;
 												   	$scope.showVolatile=false;
 												   	$scope.advice=false;
 												   	$scope.visecurities=true;
 												   	$scope.bonds1=false;	
 												   	$scope.MFpage=false;
 													$scope.FXpage=false;
 													localStorage.setItem("context","trades");
 													$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
 													.success(function(response) 
 														{
 														if(response.marketPrice==null)
 														window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
 															$scope.marketPrice=response.marketPrice;
 														});
 													
 													$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/bond/"+$scope.getDatetime)
 													.success(function(response) 
 														{
 														
 																if (response.bond==null) 
 														window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp"); 
 															
 															$scope.bond=response.bond;
 														});
 													$scope.getDatetime  = new Date();
 													
 													
 													
 													$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/mutualprices/"+$scope.getDatetime)
 													.success(function(response) {
 														if(response.MF==null)
 									$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
 																
 																if (response.session==null) 
 														window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp"); 
 															});
 														$scope.MFprice=response.MF;
 													});
 													
 													$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/foreignPrices/"+$scope.getDatetime)
 													.success(function(response) {
 														if(response.FX==null)
 											$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
 																
 																if (response.session==null) 
 														window.location.replace("http://"+ipaddress+"/PortfolioGame/index-bootstrap.jsp"); 
 															});
 														$scope.FXprice=response.FX;
 													});
 													
 											/*$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/equitiesName")
 											.success(function(response) {
 																				if(!response.equitylist)
 																					window.location.replace("http://"+ipaddress+"/PortfolioGame");
 																				$scope.equitylist = response.equitylist;*/
 											$scope.list = {
 												        data: [{
 												          
 												            name: 'Equity'
 												        }, {
 												           
 												            name: 'Bonds'
 												        },{
 												           
 												            name: 'MF'
 												        },{
 												           
 												            name: 'FX'
 												        },{
 												        	name: 'view all'
 												        }]
 												    };   	
 												/*})*/
 												/*.error(function(response) {$scope.name="error";});
 												  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/bondsName/")
 												    .success(function(response)
 													{
 												    	if(response.bonds==null)
 												    	window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
 												    	$scope.bonds=response.bonds;
 														 
 													}); 
 												  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/MFName/")
 												    .success(function(response)
 													{
 												    	$scope.MF=response.mf;
 														 
 													}); 
 												  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/FXName/")
 												    .success(function(response)
 													{
 												    	$scope.FX=response.fx;
 														 
 													}); 
 											*/	
 													
 												$scope.flag2=false;
 												
 												}
 										);

 	}


 	$scope.getviewSecurity=function()
 	{
 	$scope.equ="Cash";
 	if($scope.sec=="Equity"){

 	$scope.equitypage=true;
 	$scope.FXpage=false;
 	$scope.MFpage=false;
 	$scope.bonds1=false;

 	}else if($scope.sec=="Bonds")
 	{

 	$scope.MFpage=false;
 	$scope.FXpage=false;
 	$scope.equitypage=false;
 	/*$scope.eq=false;*/
 	$scope.bonds1=true;

 	}	
 	else if($scope.sec=="MF")
 	{

 	$scope.MFpage=true;
 	/*$scope.eq=false;*/
 	$scope.equitypage=false;
 	$scope.bonds1=false;
 	$scope.FXpage=false;

 	}
 	else if($scope.sec=="FX")
 	{

 	$scope.bonds1=false;
 	/*$scope.eq=false;*/
 	$scope.MFpage=false;
 	$scope.FXpage=true;
 	$scope.equitypage=false;


 	}
 	else if($scope.sec=="view all")
 	{
 		$scope.equitypage=true;
 	$scope.bonds1=true;
 	/*$scope.eq=false;*/
 	$scope.MFpage=true;
 	$scope.FXpage=true;

 	}

 	else{
 	alert("Choose security type");
 	}

 	}

 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
	
	
	$scope.brokerage = function() 
	{
		document.getElementById("l1").style.backgroundColor = "#2980b9";
		document.getElementById("l2").style.backgroundColor = "#2D2D2D";
		document.getElementById("l3").style.backgroundColor = "#2D2D2D";
		document.getElementById("l4").style.backgroundColor = "#2D2D2D";
		document.getElementById("l5").style.backgroundColor = "#2D2D2D";
		document.getElementById("l6").style.backgroundColor = "#2D2D2D";
		document.getElementById("l7").style.backgroundColor = "#2D2D2D";
		document.getElementById("advice").style.backgroundColor = "#2D2D2D";
		  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
		$scope.homeScreen=true;
		$scope.hold=false;
		$scope.equitypage=false;
		$scope.visecurities=false;
		$scope.trade1=false;	
		$scope.news=false;
		$scope.showVolatile=false;
		$scope.advice=false;
		$scope.broker=false;
		$scope.bonds1=false;
		$scope.MFpage=false;
			$scope.FXpage=false;
		alert("Your details has been saved!!");
		
	};
	
	/*	
	 * View Bonds price for the current date
	*/
	$scope.viewBonds = function() {
		document.getElementById("l1").style.backgroundColor = "#2D2D2D";
		document.getElementById("l2").style.backgroundColor = "#2D2D2D";
		document.getElementById("l3").style.backgroundColor = "#2D2D2D";
		document.getElementById("l4").style.backgroundColor = "#2D2D2D";
		document.getElementById("l5").style.backgroundColor = "#2D2D2D";
		document.getElementById("l6").style.backgroundColor = "#2D2D2D";
		document.getElementById("l7").style.backgroundColor = "#2980b9";
		document.getElementById("advice").style.backgroundColor = "#2D2D2D";
		  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
		  $scope.trade1=false;
		   	$scope.hold=false;
		   	$scope.homeScreen=false;
		   	$scope.equitypage=false;
		   	$scope.visecurities=false;
		   	$scope.news=false;
		   	$scope.broker=false;
		   	$scope.showVolatile=false;
		   	$scope.advice=false;
		   	$scope.bonds1=true;
		   	$scope.MFpage=false;
				$scope.FXpage=false;
		$scope.getDatetime  = new Date();
	
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/bond/"+$scope.getDatetime)
		.success(function(response) 
			{
			
					if (response.bond==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				
				$scope.bond=response.bond;
			});
		};
/*	
 * Make a Trade window		
*/	
	
$scope.trades = function() 
{
	
	localStorage.setItem("context","trades");
	$http
									.get(
											"http://"
													+ ipaddress
													+ "/MyRestDB/cxfservlet/jaxrs-server/service/checkbrokerexistence"+"/"+$scope.session.id).success(function(response)
															{
													
														if(response.saving==null)
															{
															alert("Please select a broker before making a trade");
															$scope.selectBroker();
															
															}
														else
															{
															document.getElementById("l1").style.backgroundColor = "#2D2D2D";
															document.getElementById("l2").style.backgroundColor = "#2980b9";
															document.getElementById("l3").style.backgroundColor = "#2D2D2D";
															document.getElementById("l4").style.backgroundColor = "#2D2D2D";
															document.getElementById("l5").style.backgroundColor = "#2D2D2D";
															document.getElementById("l6").style.backgroundColor = "#2D2D2D";
															document.getElementById("l7").style.backgroundColor = "#2D2D2D";
															document.getElementById("advice").style.backgroundColor = "#2D2D2D";
															  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
															
															  $scope.trade1=true;
															   	$scope.hold=false;
															   	$scope.homeScreen=false;
															   	$scope.equitypage=false;
															   	$scope.news=false;
															   	$scope.broker=false;
															   	$scope.visecurities=false;
															   	$scope.showVolatile=false;
															   	$scope.advice=false;
															   	$scope.bonds1=false;	
															   	$scope.MFpage=false;
			 													$scope.FXpage=false;
																localStorage.setItem("context","trades");
														$http
																						.get(
																								"http://"
																										+ ipaddress
																										+ "/MyRestDB/cxfservlet/jaxrs-server/service/equitiesName")
																						.success(function(response) {
																							if(!response.equitylist)
																								window.location.replace("http://"+ipaddress+"/PortfolioGame");
																							$scope.equitylist = response.equitylist;
														$scope.list = {
															        data: [{
															          
															            name: 'Equity'
															        }, {
															           
															            name: 'Bonds'
															        },{
															           
															            name: 'MF'
															        },{
															           
															            name: 'FX'
															        }]
															    };   	
															})
															.error(function(response) {$scope.name="error";});
															  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/bondsName/")
															    .success(function(response)
																{
															    	if(response.bonds==null)
															    	window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
															    	$scope.bonds=response.bonds;
																	 
																}); 
															  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/MFName/")
															    .success(function(response)
																{
															    	$scope.MF=response.mf;
																	 
																}); 
															  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/FXName/")
															    .success(function(response)
																{
															    	$scope.FX=response.fx;
																	 
																}); 
															
																
															$scope.flag2=false;
															}
															}
													);
	
}
	$scope.getSecurity=function()
	{
		$scope.equ="Cash";
		if($scope.sec=="Equity"){
			
			$scope.eq=true;
			$scope.searchequity=true;
			$scope.searchbond=false;
			$scope.searchmf=false;
			$scope.searchfx=false;
			
		}else if($scope.sec=="Bonds")
			{
			
			$scope.searchmf=false;
			$scope.searchfx=false;
			$scope.searchequity=false;
			$scope.eq=false;
			$scope.searchbond=true;
			
			}	
		else if($scope.sec=="MF")
			{
			
			$scope.searchmf=true;
			$scope.eq=false;
			$scope.searchequity=false;
			$scope.searchfx=false;
			$scope.searchbond=false;
			
			}
		else if($scope.sec=="FX")
		{
		
		$scope.searchmf=false;
		$scope.eq=false;
		$scope.searchequity=false;
		$scope.searchfx=true;
		$scope.searchbond=false;

		
		}
				else{
					alert("Choose security type");
				}
		
	}
	
	

	$scope.getDatetime  = new Date();
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/mosttraded/"+$scope.getDatetime)
		.success(function(response)
			{
				$scope.mosttraded1=response.mosttraded;
				
			});	
			
		$scope.gridOptions = { data: 'mosttraded1' };
		

	

$scope.getEquityPrice=function()
	{
		$scope.flag2=true;
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/equity/"+$scope.name)
	    .success(function(response)
		{
	    		if(!response.equity)
											window.location.replace("http://"+ipaddress+"/PortfolioGame");
										//$scope.equity = response.equity;
										$scope.price=response.equity.price;
										
										
		});

	}

	
	$scope.getBondPrice=function()
	{
	
		$scope.flag2=true;
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/bonds/"+$scope.name)
	    .success(function(response)
		{
	    	$scope.price=response.BondPrice.bond_price;
		});
	
	};
	$scope.getMfPrice=function()
	{
		$scope.flag2=true;
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/MF/"+$scope.name)
	    .success(function(response)
		{
	    	$scope.price=response.mfp.price;
		});

	};
	
	$scope.getFxPrice=function()
	{
		$scope.flag2=true;
		var x=$scope.name;
		var x1=x.split("/");
	
	    $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/FX/"+x1[0]+"/"+x1[1])
	    .success(function(response)
		{
	    	$scope.price=response.fxp.price;
		});
	};
	
	
	
	
	/*
	 * Buying an equity
	*/
	
	$scope.getDatetime  = new Date();
	$scope.buy = function() 	
	{
		if($scope.quantity==null)
		{
		alert("Please enter valid quantity before you proceed");
		}
	else if($scope.quantity%1!=0.0)
	{
	alert("Please enter valid integers before you proceed");
	}
	else if($scope.sec==null)
		{
		alert("Please select the security type");
		}
	else
		{

		if($scope.equ=="Cash")
			{
			if($scope.name.indexOf("/")>-1)
				{
				$scope.name=$scope.name.replace("/","-");
				
				}
			$http
			.get(
					"http://"
							+ ipaddress
							+ "/MyRestDB/cxfservlet/jaxrs-server/service/buy/"
							+ $scope.name + "/"
							+ $scope.price + "/"
							+ $scope.getDatetime
							+ "/" + $scope.quantity
							+ "/" + $scope.session.id+"/"+$scope.sec)
    .success(function(response)
	    
		{
    	if (response.transactions == null) {
    		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
				
				if (response.session) {
					
    		alert("Insufficient Balance");
				}
				else
    		window.location.replace("http://"+ipaddress+"/PortfolioGame");
    		});
		} else {
			alert("Trade executed successfully!");

			/*
			 * $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.session.id+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
			 * .success(function(response) {
			 * $scope.holdon=response.holding;
			 * });
			 * 
			 * $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/history/"+$scope.session.id+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
			 * .success(function(response) {
			 * $scope.transactions=response.transaction;
			 * });
			 */
		}

	
	});}else if($scope.equ=="MarginFund")
		{
	    	
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/buyequity/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.session.id+"/"+$scope.sec+"/"+$scope.equ)

                .success(function(response)
                       {
		    //	$scope.sample=response.employee1;
		    	/*var x1 = $scope.sample[0].remaining;
		    	console.log(x1);
		    	$scope.holdonvalue -= x1;*/
		    	if(response.transactions==null)
		    	{
		    		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session) {
							
							
		    		alert("Insufficient balance to use marginal fund");
						}
						else
		    		window.location.replace("http://"+ipaddress+"/PortfolioGame");
		    		});
		    	}

		    	else
		    	{
		    		alert("Trade executed successfully!");
                       
                            // $scope.user1=response.user;
		    	}
                });

	    		
	    	}


			}
		}

		
	/*
	 * Selling an equity
	*/
	
	$scope.sell = function() 	
	{
		if($scope.quantity==null || $scope.quantity=="")
		{
		alert("Please enter quantity before you proceed");
		}
		else if($scope.quantity%1!=0.0)
		{
		alert("Please enter valid integers before you proceed");
		}
		else if($scope.sec==null)
			{
			alert("Please select the security type");
			}
	else
		{
		if($scope.equ=="Cash")
		{
			if($scope.name.indexOf("/")>-1)
			{
			$scope.name=$scope.name.replace("/","-");
			
			}
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/sell/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.session.id+"/"+$scope.sec)
		.success(function(response)
		{
		 
			if(response.transactions==null)
			{
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session) {
						
				alert("Required security not available");
					}
					else
				window.location.replace("http://"+ipaddress+"/PortfolioGame");
				});
			}
	else
		{
				alert("Trade executed successfully!");
			}
		});
		}
		else if($scope.equ=="MarginFund")
		{
		 $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/equitysell/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.session.id+"/"+$scope.sec+"/"+$scope.equ)
		.success(function(response)
		{
			if (response.transactions== null) {
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session) {
					
				alert("Required equities not available");
					}
					else
						
				window.location.replace("http://"+ipaddress+"/PortfolioGame");
				});
			} else {
				alert("Trade executed successfully!");
			}
			
			});
		}
		}
		};
	

				
				
                
/* holding to trade screen 
 * 
 */
$scope.tradestask = function(name) 
{
       document.getElementById("l1").style.backgroundColor = "#2D2D2D";
       document.getElementById("l2").style.backgroundColor = "#2980b9";
       document.getElementById("l3").style.backgroundColor = "#2D2D2D";
       document.getElementById("l4").style.backgroundColor = "#2D2D2D";
       document.getElementById("l5").style.backgroundColor = "#2D2D2D";
       document.getElementById("l6").style.backgroundColor = "#2D2D2D";
       document.getElementById("l7").style.backgroundColor = "#2D2D2D";
       document.getElementById("advice").style.backgroundColor = "#2D2D2D";
       document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
       $scope.trade1=true;
   	$scope.hold=false;
   	$scope.homeScreen=false;
   	$scope.equitypage=false;
   	$scope.news=false;
   	$scope.broker=false;
   	$scope.showVolatile=false;
   	$scope.visecurities=false;
   	$scope.advice=false;
   	$scope.bonds1=false;
   	$scope.MFpage=false;
		$scope.FXpage=false;
   
	
};

$scope.designed = function() {
	alert("Designed by <br/> Vishal Srinivasan | Manju Parkavi | Ajjunesh | Prem Kumar | Sashmitha | Balaji | Revathi | Hemavathi");
	};

/*	
 * View Stock price for the current date
*/

 $scope.viewEquities = function() {
	document.getElementById("l1").style.backgroundColor = "#2D2D2D";
	document.getElementById("l2").style.backgroundColor = "#2D2D2D";
	document.getElementById("l3").style.backgroundColor = "#2D2D2D";
	document.getElementById("l4").style.backgroundColor = "#2980b9";
	document.getElementById("l5").style.backgroundColor = "#2D2D2D";
	document.getElementById("l6").style.backgroundColor = "#2D2D2D";
	document.getElementById("l7").style.backgroundColor = "#2D2D2D";
	document.getElementById("advice").style.backgroundColor = "#2D2D2D";
	  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
	  
	localStorage.setItem("context","viewEquities");
	$scope.trade1=false;
	$scope.hold=false;
	$scope.homeScreen=false;
	$scope.equitypage=true;
	$scope.news=false;
	$scope.broker=false;
	$scope.showVolatile=false;
	$scope.advice=false;
	$scope.bonds1=false;
	$scope.MFpage=false;
	$scope.FXpage=false;
	$scope.getDatetime  = new Date();
	/******************************************13492*************************
	*/
	$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
	.success(function(response) 
		{
		if(response.marketPrice==null)
		window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
			$scope.marketPrice=response.marketPrice;
		});
	}; 

	
	
	$scope.advicedisplay=function()
	{
		document.getElementById("l1").style.backgroundColor = "#2D2D2D";
		document.getElementById("l2").style.backgroundColor = "#2D2D2D";
		document.getElementById("l3").style.backgroundColor = "#2D2D2D";
		document.getElementById("l4").style.backgroundColor = "#2D2D2D";
		document.getElementById("l5").style.backgroundColor = "#2D2D2D";
		document.getElementById("l6").style.backgroundColor = "#2D2D2D";
		 document.getElementById("l7").style.backgroundColor = "#2D2D2D";
		document.getElementById("advice").style.backgroundColor = "#2980b9";
		  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
		  
		$scope.homeScreen=false;
		$scope.hold=false;
		$scope.equitypage=false;
		$scope.trade1=false;	
		$scope.news=false;
		$scope.bonds1=false;
		$scope.broker=false;
		$scope.visecurities=false;
		$scope.showVolatile=false;
		$scope.advice=true;
		$scope.MFpage=false;
			$scope.FXpage=false;
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/getadviceuser/"+$scope.session.id).success( function(response){
			if(response.advice==null)

			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
			
			$scope.advicelist=response.advice;
			
	/*$scope.gridOptions = { data: 'marketPrice' };*/
		
			
		});
	};
	/******************************************13492*************************
	*/
	
	
/*
 * Home Screen for the user
*/
	
	$scope.home = function() 
	{
		document.getElementById("l1").style.backgroundColor = "#2980b9";
		document.getElementById("l2").style.backgroundColor = "#2D2D2D";
		document.getElementById("l3").style.backgroundColor = "#2D2D2D";
		document.getElementById("l4").style.backgroundColor = "#2D2D2D";
		document.getElementById("l5").style.backgroundColor = "#2D2D2D";
		document.getElementById("l6").style.backgroundColor = "#2D2D2D";
		document.getElementById("l7").style.backgroundColor = "#2D2D2D";
		document.getElementById("advice").style.backgroundColor = "#2D2D2D";
        
		var total=0;
		var i=0;
		$scope.trade1=false;
		$scope.hold=false;
		$scope.equitypage=false;
		$scope.homeScreen=true;
		$scope.news=false;
		$scope.visecurities=false;
		$scope.bonds1=false;
		$scope.broker=false;
		$scope.showVolatile=false;
		$scope.advice=false;
		$scope.MFpage=false;
			$scope.FXpage=false;
		$scope.getDatetime  = new Date();
	
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/user/"+$scope.session.id+"/"+$scope.getDatetime)
		.success(function(response)
			{
			if(response.userhomescreen==null)
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
			
			$scope.userhomescreen = response.userhomescreen;
/*					if($scope.user1.glpercentage < 0)
						{
						document.getElementById("percent").style.color="#FF0000";
						}
					else if($scope.user1.glpercentage > 0)
						{
						
						document.getElementById("percent").style.color="#00FF00";
						}*/
			});
		
		
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.session.id)
		.success(function(response) 
			{
			    
				for(i = 0; i < response.holding.length; i++)
				{
							total += (response.holding[i].amount_lg);
			    }
				
				$scope.holdonvalue=total;
					if($scope.holdonvalue < 0)
					{
					document.getElementById("holdons1").style.color="#FF0000";
					document.getElementById("percent").style.color="#FF0000";
					}
				else if($scope.holdonvalue > 0)
					{
					document.getElementById("holdons1").style.color="#00FF00";
					document.getElementById("percent").style.color="#00FF00";
					}
			});
		localStorage.setItem("context","home");

		
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/news/"+$scope.getDatetime)
		.success(function(response) 
			{
				$scope.newson=response.news;
			});
		
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gamers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
		.success(function(response) {$scope.gamers=response.gamer;});
		
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/losers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
		.success(function(response) {$scope.gamers1=response.gamer;});
	};

/*
 * 	News Tab
*/
	
	$scope.news1 = function()
	{
		document.getElementById("l1").style.backgroundColor = "#2D2D2D";
		document.getElementById("l2").style.backgroundColor = "#2D2D2D";
		document.getElementById("l3").style.backgroundColor = "#2D2D2D";
		document.getElementById("l4").style.backgroundColor = "#2D2D2D";
		document.getElementById("l5").style.backgroundColor = "#2980b9";
		document.getElementById("l6").style.backgroundColor = "#2D2D2D";
		document.getElementById("l7").style.backgroundColor = "#2D2D2D";
		document.getElementById("advice").style.backgroundColor = "#2D2D2D";
		  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
		
		$scope.trade1=false;
		$scope.homeScreen=false;
		$scope.equitypage=false;
		$scope.hold=false;
		$scope.news=true;
		$scope.visecurities=false;
		$scope.broker=false;
		$scope.bonds1=false;
		$scope.showVolatile=false;
		$scope.advice=false;
		$scope.MFpage=false;
			$scope.FXpage=false;
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/news/"+$scope.getDatetime,{cache:false})
		.success(function(response) 
			{
			if(response.news==null)

			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				$scope.newson=response.news;
			});
	};
	
	
	
	
/*	
 * Holding Screen for users
*/

	$scope.holdingfunction = function()
	{
		document.getElementById("l1").style.backgroundColor = "#2D2D2D";
		document.getElementById("l2").style.backgroundColor = "#2D2D2D";
		document.getElementById("l3").style.backgroundColor = "#2980b9";
		document.getElementById("l4").style.backgroundColor = "#2D2D2D";
		document.getElementById("l5").style.backgroundColor = "#2D2D2D";
		document.getElementById("l6").style.backgroundColor = "#2D2D2D";
		document.getElementById("l7").style.backgroundColor = "#2D2D2D";
		document.getElementById("advice").style.backgroundColor = "#2D2D2D";
		  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
	
		$scope.trade1=false;
		$scope.homeScreen=false;
		$scope.equitypage=false;
		$scope.hold=true;
		$scope.visecurities=false;
		$scope.news=false;
		$scope.broker=false;
		$scope.showVolatile=false;
		$scope.advice=false;
		$scope.bonds1=false;
		$scope.MFpage=false;
			$scope.FXpage=false;
		localStorage.setItem("context","holdingfunction");
		
		//console.log(usrn);
		
	
			$scope.getDatetime = new Date();
	
$http.get(
				"http://"
						+ ipaddress
						+ "/MyRestDB/cxfservlet/jaxrs-server/service/user/"
						+ $scope.session.id
						+ "/"
						+ $scope.getDatetime)
		.success(
				function(response) {
					$scope.userhomescreen = response.userhomescreen;
					
				});
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.session.id)
		.success(function(response) 
			{
			if(response.holding==null)
				{
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				
				});
				}
				$scope.holding=response.holding;
			});
		
		
			
		/*********************************13486**********************************/
			
			$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/history/"+$scope.session.id)
			.success(function(response)
				{
					$scope.transactionhistory=response.transactionhistory;
				});	
		
			
		/*********************************13486**********************************/
		

		
	};
	
	$scope.set_color = function (x) {
		  if (x.amount_lg > 0) {
		    return { color: "#00FF00" }
		  }
		  else if(x.amount_lg < 0){
			  return { color: "#FF0000" }
		  }
			  else
				  {}
			};
		
		$scope.set_color_per = function (x) {
			  if (x.percentage_lg > 0) {
			    return { color: "#00FF00" }
			  }
			  else if(x.percentage_lg < 0){
				  return { color: "#FF0000" }
			  }
			  else{}
			};
/*
 * Log out for users
*/
	$scope.logout = function()
	{
		localStorage.clear();
		$http
				.get(
						"http://"
								+ ipaddress
								+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/logout")
				.success(
						function(response) {

							
							window.location.replace("http://"
									+ ipaddress
									+ "/PortfolioGame/index-bootstrap.jsp");

						});
	};
	
	
	/*
	 * Selecting broker 
	 */
	
	
	$scope.selectBroker = function() {
        document.getElementById("l1").style.backgroundColor = "#2D2D2D";
        document.getElementById("l2").style.backgroundColor = "#2D2D2D";
        document.getElementById("l3").style.backgroundColor = "#2D2D2D";
        document.getElementById("l4").style.backgroundColor = "#2D2D2D";
        document.getElementById("l5").style.backgroundColor = "#2D2D2D";
        document.getElementById("l6").style.backgroundColor = "#2D2D2D";
        document.getElementById("l7").style.backgroundColor = "#2D2D2D";
        document.getElementById("advice").style.backgroundColor = "#2D2D2D";
        document.getElementById("brokeru").style.backgroundColor = "#2980b9";
      

        $scope.trade1=false;
		$scope.homeScreen=false;
		$scope.equitypage=false;
		$scope.hold=false;
		$scope.news=false;
		$scope.visecurities=false;
		$scope.broker=true;
		$scope.showVolatile=false;
		$scope.advice=false;
		$scope.bonds1=false;
		$scope.MFpage=false;
			$scope.FXpage=false;
        $scope.getDatetime  = new Date();
        
        
        $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/3")
        .success(function(response) 
               {
               if(response.brokeraging==null)
                     {
            	 
   			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
                     }
               
               $scope.sharekhan=response.brokeraging;
     
               
               });
   /*     $scope.gridOptions = { data: 'sharekhan' };*/
        $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/1")
        .success(function(response) 
               {
               /*if(response.brokeraging==null)
               {
               alert("SERVER DOWN");
               }*/
        
               $scope.icici=response.brokeraging;
               });
       /* $scope.gridOptions = { data: 'icici' };*/
        $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/player/brokeraging/2")
        .success(function(response) 
               {
               /*if(response.brokeraging==null)
               {
               alert("SERVER DOWN");
               }*/
        
               $scope.hdfc=response.brokeraging;
               });
        /*$scope.gridOptions = { data: 'hdfc' };*/
        };
        
        
        
	
	
	/* Save State EMP ID = 13487 */
	
	$scope.savestate = function()
	{
		var bid= 1;
		bid = $('input[name=broker]:checked', '#saveform').val(); 
		var today = new Date();
		stamp= parseDate(today);
		function parseDate(d) {

		    var monthNames = [ "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" ],
		        d2 = d.getFullYear() +'-'+monthNames[d.getMonth()] +'-'+ d.getDate()+'-'+d.getHours();

		    return d2;
		} 
		
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/player/savebroker/"+$scope.session.id+"/"+bid+"/"+stamp)
		.success(function(response) 
				{
			$scope.savings=response.saving;
			leng = Object.keys($scope.savings).length;
			//console.log(Object.keys($scope.savings).length);
			if(leng != 0){
			//console.log($scope.savings[0].stamp);
			if($scope.savings[0].locked == "yes")
				alert("Already done for the Day!");
			else{
				alert("Successfully Updated!");
			}
			
			}
			
			
			else{
				alert("Successfully Updated!");
			}
			
					
	
					
				});
		
	};
	
	/* User only --Sanjay*/
	/*var hashu = document.URL.substr(document.URL.indexOf('#')+1);
	//var storage = window.localStorage;
	//console.log("The current Hash: " + hashu);
	//console.log("From IE" + hash);
	if(hashu=="homepu"){
		localStorage.setItem(hashu,true);
		localStorage.setItem("tradewu",false);
		localStorage.setItem("vnewsu",false);
		localStorage.setItem("holdngu",false);
		localStorage.setItem("vstocku",false);
		localStorage.setItem("brokeru",false);
	}
	else if(hashu=="tradewu"){
		localStorage.setItem(hashu,true);
		localStorage.setItem("homepu",false);
		localStorage.setItem("vnewsu",false);
		localStorage.setItem("holdngu",false);
		localStorage.setItem("vstocku",false);	
		localStorage.setItem("brokeru",false);

	}
	else if(hashu=="vnewsu"){
		localStorage.setItem(hashu,true);
		localStorage.setItem("tradewu",false);
		localStorage.setItem("homepu",false);
		localStorage.setItem("holdngu",false);
		localStorage.setItem("vstocku",false);	
		localStorage.setItem("brokeru",false);

	}
	else if(hashu=="holdngu"){
		localStorage.setItem(hashu,true);
		localStorage.setItem("homepu",false);
		localStorage.setItem("tradewu",false);
		localStorage.setItem("vnewsu",false);
		localStorage.setItem("vstocku",false);	
		localStorage.setItem("brokeru",false);

	}
	else if(hashu=="brokeru"){
		localStorage.setItem(hashu,true);
		localStorage.setItem("homepu",false);
		localStorage.setItem("tradewu",false);
		localStorage.setItem("holdngu",false);
		localStorage.setItem("vnewsu",false);
		localStorage.setItem("vstocku",false);	
	}
	else if(hashu=="vstocku"){
		localStorage.setItem(hashu,true);
		localStorage.setItem("tradewu",false);
		localStorage.setItem("vnewsu",false);
		localStorage.setItem("holdngu",false);
		localStorage.setItem("homepu",false);	
		localStorage.setItem("brokeru",false);
	}
	else
	{
	//console.log("From the Else Block");
	localStorage.setItem("homepu",true);
	localStorage.setItem("tradewu",false);
	localStorage.setItem("vnewsu",false);
	localStorage.setItem("vstocku",false);
	localStorage.setItem("holdngu",false);
	localStorage.setItem("brokeru",false);

	}
		
	
	if(localStorage.getItem("homepu") == "true")
	{
	//console.log("Home Page is true");
		
		$scope.home();
	
	}
	else if(localStorage.getItem("tradewu") == "true")
	{
	//console.log("Uploading News is true");
	
	$scope.trades();
	}
	else if(localStorage.getItem("vnewsu") == "true")
	{
	//console.log("Vnews is true");
		
	$scope.news1();
	}
	else if(localStorage.getItem("holdngu") == "true")
	{
	//console.log("Uploading Stocks is true");
		
		
		$scope.holding();
		
	}
	else if(localStorage.getItem("brokeru") == "true")
	{
	//console.log("Uploading Stocks is true");
		
		
		$scope.selectBroker();
		
	}
	else if(localStorage.getItem("vstocku") == "true")
	{
	//console.log("View Stock is true");
		
	$scope.viewStocks();
	}
	else
		{}
		//console.log("Nothing Here!");


	
	/* User edit Ends Here! --Sanjay */

	//Abishek
	//$$$$$$$$$$$$$$$$$  volatile stocks  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	
	
	$scope.volatileStocks = function() 

	{
		document.getElementById("l1").style.backgroundColor = "#2D2D2D";
		document.getElementById("l2").style.backgroundColor = "#2D2D2D";
		document.getElementById("l3").style.backgroundColor = "#2D2D2D";
		document.getElementById("l4").style.backgroundColor = "#2D2D2D";
		document.getElementById("l5").style.backgroundColor = "#2D2D2D";
		document.getElementById("l6").style.backgroundColor = "#2980b9";
		document.getElementById("l7").style.backgroundColor = "#2D2D2D";
		 document.getElementById("advice").style.backgroundColor = "#2D2D2D";
		  document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
		  
		$scope.eq=false;
		$scope.trade1=false;
		$scope.homeScreen=false;
		$scope.equitypage=false;
		$scope.hold=false;
		$scope.visecurities=false;
		$scope.news=false;
		$scope.broker=false;
		$scope.showVolatile=true;
		$scope.advice=false;
		$scope.bonds1=false;
		$scope.MFpage=false;
			$scope.FXpage=false;
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/volatile")
		.success(function(response) 
			{
			if(response.marketPrice==null)
				{
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
				}
			$scope.volatileS=response.marketPrice;
			});
		};
		
     //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

});

/*
 * ************************************************************************
 * Login Controller
 * @Author - XBBLWSQ
 * ************************************************************************
 */

 

myApp.controller('loginCtrl', function($scope, $http) 
{
	
	//localStorage.setItem("context","loginpage");
	//********************************************FORGOT PASSWORD XBBLWC8 EMP ID:13490*********************************************************************//
	$scope.forgotpassword = function()
	{
	
		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/forgotPassword/"+$scope.username)
		.success(function(response) {
			alert("password has been sent to your email");
			setTimeout(function(){ 

				window.location.replace("http://"+ipaddress+"/PortfolioGame/index.jsp"); 
		    }, 1000);  
		
		})
		.error(function(response) {alert("username doesnot exist");});
		
		}
	
//****************************************************************************************************************************************//
	

	$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
		
		if (response.session) {
				if (response.session.type == 'u') {
					window.location
							.replace("http://"
									+ ipaddress
									+ "/PortfolioGame/user.jsp");
				} else if(response.session.type=='a') {
					
					window.location
					.replace("http://"
							+ ipaddress
							+ "/PortfolioGame/admin.jsp");
							
					
			}
		}
			else {
				
				
		if(!localStorage.getItem("context")||localStorage.getItem("context")=="loginpage" )
			{
			$scope.loginpage();
			}
		else if(localStorage.getItem("context")=="signup")
				{
				$scope.signup();
				}
		else
			{
			$scope.loginpage();
			alert("You have been logged out. Please login again!");
			}
			}
							
		});
		/*******************************************************************************/
	$scope.myFunc = function() {
		$scope.login();
	};
		
	
							$scope.login = function() {

			$http
					.get(
							"http://"
									+ ipaddress
									+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/login/"
									+ $scope.usrname + "/"
									+ $scope.passwd)
					.success(
							function(response) {
								
								$scope.session = response.session;

								if (!$scope.session) {
									alert("Username and password mismatch!!");
								} else {

									if ($scope.session.type == 'u') {
										localStorage.clear();	
										//alert("Welcome to Portfolio Game");
										window.location
												.replace("http://"
														+ ipaddress
														+ "/PortfolioGame/user.jsp");
									} else if ($scope.session.type == 'a') {
										localStorage.clear();	
										//alert("Welcome Admin");

										window.location
												.replace("http://"
														+ ipaddress
														+ "/PortfolioGame/admin.jsp");
									}
									else if ($scope.session.type == 'b') {
										localStorage.clear();	
										//alert("Welcome Admin");

										window.location
												.replace("http://"
														+ ipaddress
														+ "/PortfolioGame/broker1.jsp");
									}
								}
							}).error(function() {
						alert("error");

					});

		};

		$scope.registerfunction = function() {
			if (document
					.getElementById("passwd1").value == document
					.getElementById("passwd2").value) {
				

			$http
					.get(
							"http://"
									+ ipaddress
									+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/register/"
									+ $scope.regusrname
									+ "/"
									+ $scope.passwd1
									+ "/"
									+ $scope.regname
									+ "/"
									+ $scope.mail
									)
					.success(
							function(response) {
								$scope.session=response.session;
							
									if (!$scope.session) {
									alert("Sorry username already exists!");
								
								}
								else{
														localStorage.clear();	
						
														
									window.location
									.replace("http://"
											+ ipaddress
											+ "/PortfolioGame/user.jsp");
								}	
							});
							}
							else
								{
								alert("Passwords mismatch!");
								}
			}

		
		$scope.loginpage = function() {
			$scope.register = false;
			$scope.l1 = true;
			$scope.employees = null;
			$scope.flag = false;
			$scope.equities = false;
			$scope.admin = false;
		localStorage.setItem("context","loginpage");
		};

		$scope.signup = function() {
			$scope.l1 = false;
			$scope.register = true;
			$scope.employees = null;
			$scope.flag = false;
			localStorage.setItem("context","signup");
		};
});


/*
 * ****************************************************************************************
 * Admin Controller
 * @Author - XBBLWSQ
 * ****************************************************************************************
 */

myApp.controller('adminCtrl', function($scope, $http) 
		{
	
			$scope.getDatetime  = new Date();
			$scope.init = function() {
			$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
				
				if (response.session) {
						if (response.session.type == 'u') {
							window.location
									.replace("http://"
											+ ipaddress
											+ "/PortfolioGame/user.jsp");
						}else if (response.session.type == 'b') {
							window.location
							.replace("http://"
									+ ipaddress
									+ "/PortfolioGame/broker1.jsp");
				}  
						else if(response.session.type=='a') {
							$scope.session = response.session;
							$scope.username=$scope.session.name;
							$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/lose")
							.success(function(response) 
							{
									
									$scope.l=response.losegain;
							});

							$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gain")

							.success(function(response) 
										{
								$scope.g=response.losegain;
								
										});


									
							if(!localStorage.getItem("context") || localStorage.getItem("context")=="homePage")
								$scope.homePage();
							else if(localStorage.getItem("context")=="uploadNews")
								{
								$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/adminservice/check").
								success(function(response) {
									if(response.check.check==1)
										$scope.getNews();
									else if(response.check.check==0)
										$scope.uploadNews();
								});
								}
								
							else if(localStorage.getItem("context")=="getNews")
							{
							$scope.getNews();
							}
							else if(localStorage.getItem("context")=="uploadEquities")
							{
								$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/adminservice/check").
								success(function(response) {
									if(response.check.check==1)
										$scope.viewEquities();
									else if(response.check.check==0)
										$scope.uploadSecurities();
								});
							}
							else if(localStorage.getItem("context")=="viewEquities")
							{
							$scope.viewEquities();
							}
							else if(localStorage.getItem("context")=="makeAdmin")
							{
							$scope.makeAdmin();
							}
						}
				}
					

					else {
					
						window.location.replace("http://"+ ipaddress+"/PortfolioGame");
					}
				
					
				});
			}
			$scope.set_losecolor = function () {
				
				 return { color: "#990000" }
		}
		$scope.set_gaincolor = function () {
			 
				 return { color: "#006600" }
		  
		}
			$scope.hello = function() {
				$scope.register=false;
				$scope.l1=true;		
			    $scope.employees=null;
			    $scope.flag = false;
			    $scope.stocks=false;
			    $scope.admin=false;
				$scope.homeData=false;
				$scope.approve=false;
				$scope.view=false;
				$scope.brokerview=false;
				$scope.viewrejected=false;
				$scope.viewpublished=false;
				$scope.viewapproval=false;
				$scope.viewapproved=false;
				
			};
			
			$scope.uploadBond=function()
			{
				 $scope.hideOtherTabsad();
					document.getElementById("uploadbond").style.backgroundColor = "#2980b9";
					$scope.uploadBond1= true;
			}
			$scope.uploadmf=function()
			{
				 $scope.hideOtherTabsad();
					document.getElementById("uploadmf").style.backgroundColor = "#2980b9";
					$scope.uploadMF1= true;
			}
			$scope.uploadfx=function()
			{
				 $scope.hideOtherTabsad();
					document.getElementById("uploadfx").style.backgroundColor = "#2980b9";
					$scope.uploadFX1= true;
			}
            $scope.hideOtherTabsad = function()
            {
                document.getElementById("l1").style.backgroundColor = "#2D2D2D";
               // document.getElementById("l2").style.backgroundColor = "#2D2D2D";
                document.getElementById("l3").style.backgroundColor = "#2D2D2D";
                document.getElementById("l4").style.backgroundColor = "#2D2D2D";
                document.getElementById("l5").style.backgroundColor = "#2D2D2D";
                document.getElementById("l6").style.backgroundColor = "#2D2D2D";
                document.getElementById("l7").style.backgroundColor = "#2D2D2D";
                document.getElementById("l8").style.backgroundColor = "#2D2D2D";
                document.getElementById("l9").style.backgroundColor = "#2D2D2D";
              //  document.getElementById("uploadbond").style.backgroundColor = "#2D2D2D";
              //  document.getElementById("uploadfx").style.backgroundColor = "#2D2D2D";
               // document.getElementById("uploadmf").style.backgroundColor = "#2D2D2D";
        	
        		$scope.uploadnewspage=false;

	$scope.uploadBond1=false;
				$scope.news=false;
				$scope.admin=false;
				$scope.equitypage=false;
				$scope.homeData=false;
				$scope.uploadequitiespage=false;
					$scope.uploadMF1=false;
				$scope.uploadFX1=false;
				$scope.MFpage=false;
				$scope.FXpage=false;
				$scope.approve=false;
				$scope.view=false;
				$scope.viewsecurities=false;
				$scope.brokerview=false;
				$scope.viewrejected=false;
				$scope.viewpublished=false;
				$scope.viewapproval=false;
				$scope.viewapproved=false;
				$scope.showAdmin=false;
				$scope.bonds=false;
				$scope.bond_rate_change=false;
               
            };


            
          //view securities//
            $scope.viewSecuritiesad = function() 
            {

            localStorage.setItem("context","trades");
            $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/checkbrokerexistence"+"/"+$scope.session.id)
            										.success(function(response)
            										{
            																			
            											document.getElementById("l1").style.backgroundColor = "#2D2D2D";
            											//document.getElementById("l2").style.backgroundColor = "#2D2D2D";
            											document.getElementById("l3").style.backgroundColor = "#2D2D2D";
            											document.getElementById("l4").style.backgroundColor = "#2D2D2D";
            											
            											document.getElementById("l6").style.backgroundColor = "#2D2D2D";
            											document.getElementById("l7").style.backgroundColor = "#2D2D2D";
            											document.getElementById("l8").style.backgroundColor = "#2D2D2D";
            											//document.getElementById("advice").style.backgroundColor = "#2D2D2D";
            											  //document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
            											
            												$scope.hideOtherTabsad();
            												document.getElementById("l5").style.backgroundColor = "#2980b9";
            											  $scope.trade1=false;
            											   	$scope.hold=false;
            											   	$scope.homeScreen=false;
            											   	$scope.equitypage=false;
            											   	$scope.news=false;
            											   	$scope.broker=false;
            											   	$scope.showVolatile=false;
            											   	$scope.advice=false;
            											   	$scope.viewsecurities=true;
            											   	$scope.bonds=false;	
            											   	$scope.MFpage=false;
            												$scope.FXpage=false;
            												localStorage.setItem("context","trades");
            												$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
            												.success(function(response) 
            													{
            													if(response.marketPrice==null)
            													window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
            														$scope.marketPrice=response.marketPrice;
            													});
            												
            												$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/bond/"+$scope.getDatetime)
            												.success(function(response) 
            													{
            													
            															if (response.bond==null) 
            													window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
            														
            														$scope.bond=response.bond;
            													});
            												$scope.getDatetime  = new Date();
            												
            												
            												
            												$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/mutualprices/"+$scope.getDatetime)
            												.success(function(response) {
            													if(response.MF==null)
            								$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
            															
            															if (response.session==null) 
            													window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
            														});
            													$scope.MF=response.MF;
            												});
            												
            												$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/foreignPrices/"+$scope.getDatetime)
            												.success(function(response) {
            													if(response.FX==null)
            										$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
            															
            															if (response.session==null) 
            													window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
            														});
            													$scope.FXprice=response.FX;
            												});
            												
            										/*$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/equitiesName")
            										.success(function(response) {
            																			if(!response.equitylist)
            																				window.location.replace("http://"+ipaddress+"/PortfolioGame");
            																			$scope.equitylist = response.equitylist;*/
            										$scope.list = {
            											        data: [{
            											          
            											            name: 'Equity'
            											        }, {
            											           
            											            name: 'Bonds'
            											        },{
            											           
            											            name: 'MF'
            											        },{
            											           
            											            name: 'FX'
            											        },{
            											        	name: 'view all'
            											        }]
            											    };   	
            											/*})*/
            											/*.error(function(response) {$scope.name="error";});
            											  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/bondsName/")
            											    .success(function(response)
            												{
            											    	if(response.bonds==null)
            											    	window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
            											    	$scope.bonds=response.bonds;
            													 
            												}); 
            											  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/MFName/")
            											    .success(function(response)
            												{
            											    	$scope.MF=response.mf;
            													 
            												}); 
            											  $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/FXName/")
            											    .success(function(response)
            												{
            											    	$scope.FX=response.fx;
            													 
            												}); 
            										*/	
            												
            											$scope.flag2=false;
            											
            											}
            									);

            }


            $scope.getviewSecurity=function()
            {
            $scope.equ="Cash";
            if($scope.sec=="Equity"){

            $scope.equitypage=true;
            $scope.FXpage=false;
            $scope.MFpage=false;
            $scope.bonds=false;

            }else if($scope.sec=="Bonds")
            {

            $scope.MFpage=false;
            $scope.FXpage=false;
            $scope.equitypage=false;
            /*$scope.eq=false;*/
            $scope.bonds=true;

            }	
            else if($scope.sec=="MF")
            {

            $scope.MFpage=true;
            /*$scope.eq=false;*/
            $scope.equitypage=false;
            $scope.bonds=false;
            $scope.FXpage=false;

            }
            else if($scope.sec=="FX")
            {

            $scope.bonds=false;
            /*$scope.eq=false;*/
            $scope.MFpage=false;
            $scope.FXpage=true;
            $scope.equitypage=false;


            }
            else if($scope.sec=="view all")
            {

            $scope.bonds=true;
            /*$scope.eq=false;*/
            $scope.MFpage=true;
            $scope.FXpage=true;
            $scope.equitypage=true;


            }

            else{
            alert("Choose security type");
            }

            }


            
            /*Mutual funds*/
        	
        	$scope.viewMF = function() {
        					
        					
        					$scope.hideOtherTabsad();
        					
        					
        					document.getElementById("l10").style.backgroundColor = "#2980b9";
        					
        					$scope.getDatetime  = new Date();
        					
        					$scope.MFpage=true;
        					
        					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/mutualprices/"+$scope.getDatetime)
        					.success(function(response) {
        						if(response.MF==null)
        	$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
        								
        								if (response.session==null) 
        						window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
        							});
        						$scope.MF=response.MF;
        					});
        				};
        	
			//foreign exchange************************
			$scope.viewFX = function() {
							
							
							$scope.hideOtherTabsad();
							
							
							document.getElementById("l11").style.backgroundColor = "#2980b9";
							
							$scope.getDatetime  = new Date();
							
							$scope.FXpage=true;
							
							$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/foreignPrices/"+$scope.getDatetime)
							.success(function(response) {
								if(response.FX==null)
			$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
										
										if (response.session==null) 
								window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
									});
								$scope.FXprice=response.FX;
							});
						};
        
            

            $scope.changeinterest = function() {
            	$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
            				$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/changeInterest/"+$scope.bond_interest)
            				.success(function(response) 
            						{
            					//alert("Interest rate updated !!");
            				$scope.manageBonds();
            				$scope.bond_interest="";
            				});
            			};

            			$scope.showbond=function()
            			{
            				$scope.bond_rate_change=true;
            				
            			};


            			$scope.manageBonds = function() {
            				$scope.hideOtherTabsad();
            				document.getElementById("l9").style.backgroundColor = "#2980b9";
            				
            				$scope.getDatetime  = new Date();          				
            				
            				$scope.bonds=true;
            				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
    							
    							if (response.session==null) 
    					window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
    						});
            				$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/bond"+"/"+$scope.getDatetime)
            				.success(function(response) {$scope.bond=response.bond;}
            				);
            				
            			};

			$scope.uploadSecurities= function() {
				 $scope.hideOtherTabsad();
				document.getElementById("l4").style.backgroundColor = "#2980b9";
				$scope.uploadequitiespage = true;
				localStorage.setItem("context","uploadEquities");
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
			};
			
			$scope.homePage = function() {
				
				$scope.getDatetime  = new Date();
				$scope.hideOtherTabsad();
				
				document.getElementById("l1").style.backgroundColor = "#2980b9";
				
				$scope.homeData=true;
				localStorage.setItem("context","homePage");
				
		   		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/users")
				.success(function(response) {
					
					if(response.userhomescreen==null)
						$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
							
							if (response.session==null) 
					window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
						});
					$scope.users=response.userhomescreen;
				});
		   		
		   		$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gamers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
				.success(function(response) {$scope.gamers=response.gamer;});
				
				$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/losers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
				.success(function(response) {$scope.gamers1=response.gamer;});
				
			};
			
			$scope.uploadNews = function() {
				$scope.hideOtherTabsad();
				
				//document.getElementById("l2").style.backgroundColor = "#2980b9";
				localStorage.setItem("context", "uploadNews");
				$scope.uploadnewspage=true;
				localStorage.setItem("context", "uploadNews");
				
			};
			
			
			$scope.getNews = function() {
				$scope.hideOtherTabsad();
				
				document.getElementById("l3").style.backgroundColor = "#2980b9";
				
				$scope.getDatetime  = new Date();
			    $scope.news=true;
			    localStorage.setItem("context","getNews");
							
			
				$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/news/"+$scope.getDatetime)///"+$scope.getDatetime
				.success(function(response) {
					if(response.news==null)
	$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
							
							if (response.session==null) 
					window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
						});
					$scope.newson=response.news;
				});
			};
			
			
			$scope.viewEquities = function() {
				document.getElementById("l1").style.backgroundColor = "#2D2D2D";
				//document.getElementById("l2").style.backgroundColor = "#2D2D2D";
				document.getElementById("l3").style.backgroundColor = "#2D2D2D";
				document.getElementById("l4").style.backgroundColor = "#2980b9";
				document.getElementById("l5").style.backgroundColor = "#2D2D2D";
				document.getElementById("l6").style.backgroundColor = "#2D2D2D";
				document.getElementById("l7").style.backgroundColor = "#2D2D2D";
				document.getElementById("l8").style.backgroundColor = "#2D2D2D";
				//document.getElementById("advice").style.backgroundColor = "#2D2D2D";
				  //document.getElementById("brokeru").style.backgroundColor = "#2D2D2D";
				  
				localStorage.setItem("context","viewEquities");
				$scope.trade1=false;
				$scope.hold=false;
				$scope.homeScreen=false;
				$scope.equitypage=true;
				$scope.news=false;
				$scope.broker=false;
				$scope.showVolatile=false;
				$scope.advice=false;
				$scope.bonds=false;
				$scope.getDatetime  = new Date();
				/******************************************13492*************************
				*/
				$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
				.success(function(response) 
					{
					if(response.marketPrice==null)
					window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
						$scope.marketPrice=response.marketPrice;
					});
				};

			
			$scope.manage = function() {
				$scope.hideOtherTabsad();
				document.getElementById("l6").style.backgroundColor = "#2980b9";
				$scope.admin=true;
				$scope.makeAdmins = function() {
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
				$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/makeAdmin/"+$scope.com_id)
				.success(function(response) {
					alert(response);
					$scope.com_id="";
				});
				}
				
				$scope.manageUsers = function() {
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/removeUsers/"+$scope.usr_id)
					.success(function(response) {
						alert(response);
						$scope.usr_id="";
					});
					}
				
				$scope.makeUsers = function() {
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/makeUsers/"+$scope.adm_id)
					.success(function(response) {
						alert(response);
						$scope.adm_id="";
					});
					}
			};
						
			$scope.approveBroker = function() {
				$scope.hideOtherTabsad();
				
				
				document.getElementById("l7").style.backgroundColor = "#2980b9";
				
				$scope.getDatetime  = new Date();
				
				
				$scope.approve=true;
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
				$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/view/brokerdetails")
				.success(function(response) {
					$scope.viewbrokers=response.viewbrokers;
					 if($scope.viewbrokers.length!=0)
            		 {
						 $scope.noentries=false;
                		 $scope.approve=true;
                		            		 }
                	 else
                		 {
                		 
                		 
                		 $scope.noentries=true;
                		 
                		 }
				});
				
				
			
			};
			
			$scope.brokerStatus = function() {
				
				$scope.hideOtherTabsad();
				
				document.getElementById("l8").style.backgroundColor = "#2980b9";
				$scope.getDatetime  = new Date();
				
				$scope.brokerview=true;
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
				
			
			};
			
			

			$scope.rejectedBrokers = function() {
             
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
				$scope.hideOtherTabsad();
				
				
				document.getElementById("l8").style.backgroundColor = "#2980b9";
				$scope.getDatetime  = new Date();
				
				$scope.viewrejected=true;
				
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/view/rejectedrates")///"+$scope.getDatetime
                 .success(function(response) 
                		 {
                	 $scope.rejectedbrokers=response.rejectedbrokers;
                	 
                	 if(response.rejectedbrokers.length!=0)
            		 {
                		 $scope.rejectedtable=true;
                		 
                		 
            		 }
                	 else
                		 {
                		 
                		 $scope.rejectedtable=false;
                		 window.alert("No Entries Found");
                		 $scope.brokerStatus();
                		 }

                	
                	 
                });

				
			
			};
			
			
$scope.viewUsers = function() {
             
				
				$scope.hideOtherTabsad();
				
				
				document.getElementById("l10").style.backgroundColor = "#2980b9";
				$scope.getDatetime  = new Date();
				
				$scope.viewrejected=true;
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/view/rejectedrates")///"+$scope.getDatetime
                 .success(function(response) 
                		 {
                	 $scope.rejectedbrokers=response.rejectedbrokers;
                	 
                	 if(response.rejectedbrokers.length!=0)
            		 {
                		 $scope.rejectedtable=true;
                		 
                		 
            		 }
                	 else
                		 {
                		 
                		 $scope.rejectedtable=false;
                		 window.alert("No Entries Found");
                		 $scope.brokerStatus();
                		 }

                	
                	 
                });

				
			
			};
			
			
			
			
			$scope.approvedBrokers1 = function() {
	            
				$scope.hideOtherTabsad();
				
				
				document.getElementById("l8").style.backgroundColor = "#2980b9";
				$scope.getDatetime  = new Date();
				
				$scope.viewapproved=true;
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/view/approvedrates")///"+$scope.getDatetime
                 .success(function(response) {
                	 
                	 $scope.approvedbrokers=response.approvedbrokers;
                	 

                	 if(response.approvedbrokers.length!=0)
            		 {
                		 $scope.approvedtable=true;
                		 
                		 
            		 }
                	 else
                		 {
                		 
                		 $scope.approvedtable=false;
                		 window.alert("No Entries Found");
                		 $scope.brokerStatus();
                		 }

                	
                	 
                });

				
			
			};
			
			
			$scope.publishedBrokers = function() {
	             
				$scope.hideOtherTabsad();
				
				
				
				document.getElementById("l8").style.backgroundColor = "#2980b9";
				$scope.getDatetime  = new Date();
				
				$scope.viewpublished=true;
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/view/publishedrates")///"+$scope.getDatetime
                 .success(function(response) {
                	 
                	 $scope.publishedbrokers=response.publishedbrokers;

                	 if(response.publishedbrokers.length!=0)
            		 {
                		 $scope.publishedtable=true;
                		 
                		 
            		 }
                	 else
                		 {
                		 
                		 $scope.publishedtable=false;
                		 window.alert("No Entries Found");
                		 $scope.brokerStatus();
                		 }
                	
                	 

                	
                	 
                });

				
			
			};
			
			
			$scope.ratestoapprove = function() {
				$scope.hideOtherTabsad();
				
				document.getElementById("l8").style.backgroundColor = "#2980b9";
				$scope.getDatetime  = new Date();
				
				
				$scope.viewapproval=true;
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/view/approvalrates")///"+$scope.getDatetime
                 .success(function(response) {
                	 
                	 $scope.ratesforapproval=response.ratesforapproval;
                	
                	 if(response.ratesforapproval.length!=0)
            		 {
                		 $scope.approvaltable=true;
                		 
                		 
            		 }
                	 else
                		 {
                		 
                		 $scope.approvaltable=false;
                		 window.alert("No Entries Found");
                		 $scope.brokerStatus();
                		 }
                	
                	 
                });

				
			
			};
			
			
			
			$scope.approvebutton = function(nam) {
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
             
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/rates/approvebroker/"+nam)///"+$scope.getDatetime
                .success(function(response) {
               	 
               	 
               	 window.alert(nam+" details approved");
           
			
               	$scope.approveBroker();
               	
               	
               	 
               });
               
            //   $scope.approveBroker();
			
			};
			
			
			$scope.publishbutton = function(nam) {
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/rates/publishbroker/"+nam)///"+$scope.getDatetime
                 .success(function(response) {
                	 
                	 
                	 window.alert(nam+" details published");
                
                	   $scope.approveBroker();
                	 
                });
                
             
			
			};
			
			
			
$scope.rejectbutton = function(nam) {
	$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
		
		if (response.session==null) 
window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
	});
                $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/adminservice/admin/rates/rejectbroker/"+nam)///"+$scope.getDatetime
                 .success(function(response) {
        
                	 window.alert(nam+" details Rejected");
                	 $scope.approveBroker();
                	
                	 
                });

           
			
			};
			
			
			$scope.backButton = function() {
	             
                
                	 $scope.brokerStatus();
                	
                	 
            

				
			
			};
			
			
			$scope.viewTable = function(nam) {
				$scope.hideOtherTabsad();
				document.getElementById("l7").style.backgroundColor = "#2980b9";


				$scope.getDatetime  = new Date();
				
				$scope.view=true;
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
				});
				   $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/admin/view/brokerreport/"+nam)///"+$scope.getDatetime
	                 .success(function(response) {
	        
	                	
	                	 $scope.brokersreport=response.brokersreport;
	                });

				
			
			};
			
						
			
			$scope.logout = function() {
				localStorage.clear();
				$http
						.get(
								"http://"
										+ ipaddress
										+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/logout")
						.success(
								function(response) {
									
									window.location.replace("http://"
											+ ipaddress
											+ "/PortfolioGame/index-bootstrap.jsp");
								});
			};

			
			
			$scope.reset = function() {
				$scope.l1=false;
				$scope.register=true;
			    $scope.employees=null;
			    $scope.flag = false;
			};
		});

/**
 * 
 */


myApp.controller('brokerCtrl',function($scope, $http) 
		{
	

	$scope.init = function() {
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
			
			if (response.session) {
					if (response.session.type == 'u') {
						window.location
								.replace("http://"
										+ ipaddress
										+ "/PortfolioGame/user.jsp");
					}else if (response.session.type == 'a') {
						window.location
						.replace("http://"
								+ ipaddress
								+ "/PortfolioGame/admin.jsp");
			}  
					else if(response.session.type=='b') {
						$scope.session = response.session;
						if(!localStorage.getItem("context") || localStorage.getItem("context")=="broker")
							$scope.broker();
						else if(localStorage.getItem("context")=="client")
							{
						
						$scope.client();
							}
						else if(localStorage.getItem("context")=="statusfunction")
						{
					
					$scope.statusfunction();
						}
						else if(localStorage.getItem("context")=="brokeradviceu")
						{
					
					$scope.brokeradviceu();
						}
						else if(localStorage.getItem("context")=="advicedisplay1")
						{
					
					$scope.advicedisplay1();
						}
						
			}
			}

				else {
				
					window.location.replace("http://"+ ipaddress+"/PortfolioGame");
				}
		});
				
			
		}
		
			

//****************************default Code *****************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
	
			$scope.hideOtherTabs = function()
            {
				document.getElementById("broker1").style.backgroundColor = "#2D2D2D";
		document.getElementById("client1").style.backgroundColor = "#2D2D2D";
				document.getElementById("statuss").style.backgroundColor = "#2D2D2D";
				document.getElementById("brokeradvice1").style.backgroundColor = "#2D2D2D";
				document.getElementById("broker2").style.backgroundColor = "#2D2D2D";
				document.getElementById("advice1").style.backgroundColor = "#2D2D2D";
				$scope.brokers=false;
				$scope.clients=false;
				//$scope.statuss=false;
				$scope.brokeradvice=false;
				$scope.statusbar=false;
				$scope.viewdetails1=false;
				$scope.viewalldetails1=false;
				$scope.viewpublishdetails1=false; 
				$scope.uploadBrokerAdvice=false;
				$scope.advice1=false;
				$scope.brokerssss=false;
				$scope.brokers1=false;
            }
//****************************Brokerage Code *****************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
					
		$scope.broker = function() 
		{
			
			$scope.hideOtherTabs();
			document.getElementById("broker1").style.backgroundColor = "#2980b9";
		$scope.brokers=true;
		localStorage.setItem("context","broker");
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
			
			if (response.session==null) 
	window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
		});
		};
		
		//****************************Cash Balance Code *****************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
		
		$scope.holding1 = function() 
		{
			
			$scope.hideOtherTabs();
			document.getElementById("broker2").style.backgroundColor = "#2980b9";
		$scope.brokers1=true;
		$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
			
			if (response.session==null) 
	window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
		});
		};
			
//****************************Client Code *****************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
			
		$scope.client = function() 
		{
				$scope.hideOtherTabs();
				document.getElementById("client1").style.backgroundColor = "#2980b9";
				$scope.clients=true;
				localStorage.setItem("context","client");
				$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
					
					if (response.session==null) 
			            window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					var name = response.session.name;
			
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/clientreport/"+name)
	                
	                .success(function(response)
	             {
	                	
	                	$scope.clientreport1=response.clientreport;
	                	
	                	$scope.gridOptions={data:'clientreport1'};
	             })
	             $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/sumbrokerfee/"+name)
	                
	                .success(function(response)
	             {
	                	
	                	$scope.bfee=response;

	             })
	               $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/summarginfee/"+name)
	                
	                .success(function(response)
	             {
	                	
	                	$scope.mfee=response;

	             })
	                 $http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/availablebalance/"+name)
	                
	                .success(function(response)
	             {
	                	
	                	$scope.availbal=response;

	             })
				});
				
			
             
		};
				
		
//**************************** Status Code *****************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
		$scope.statusfunction = function() 
		{
					$scope.hideOtherTabs();
					document.getElementById("statuss").style.backgroundColor = "#2980b9";
					//$scope.statuss=true;
					$scope.statusbar=true;
					localStorage.setItem("context","statusfunction");
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
		};
		
//****************************View Status Code *****************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
		$scope.viewdetailsfunction=function()
		{$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
			
			if (response.session==null) 
	window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
		});
					$scope.hideOtherTabs();
					document.getElementById("statuss").style.backgroundColor = "#2980b9";
					$scope.status="bs";
					$scope.statusbar=true;
					$scope.viewdetails1=true;
					if($scope.session.id=="icici")
						$scope.broker_id=1;
					else if($scope.session.id=="hdfc")
						$scope.broker_id=2;
					else if($scope.session.id=="sharekhan")
						$scope.broker_id=3;
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/brokerservice/viewpublishdetails/"+$scope.broker_id+"/"+$scope.status)
		.success(function(response) 
 				{
						$scope.viewdetails=response.viewdetails;
						$scope.gridOptions={data:'viewdetails'};
			

							})
					
		}
//*****************viewall details******************************************************************************************************************************
		
				$scope.viewalldetailsfunction=function()
				{
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					$scope.hideOtherTabs();
					document.getElementById("statuss").style.backgroundColor = "#2980b9";
					//$scope.status="S";
					$scope.statusbar=true;
					$scope.viewalldetails1=true;
					if($scope.session.id=="icici")
						$scope.broker_id=1;
					else if($scope.session.id=="hdfc")
						$scope.broker_id=2;
					else if($scope.session.id=="sharekhan")
						$scope.broker_id=3;
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/brokerservice/viewalldetails/"+$scope.broker_id)
					.success(function(response)
							{
						$scope.viewalldetails=response.viewdetails;
						$scope.gridOptions={data:'viewalldetails'};
					
					 
							})
				  
				}
					
//*****************view publish details******************************************************************************************************************************
					
				$scope.viewpublishdetailsfunction=function()
				{
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					$scope.hideOtherTabs();
					document.getElementById("statuss").style.backgroundColor = "#2980b9";
					$scope.status="s";
					$scope.statusbar=true;
					$scope.viewpublishdetails1=true;
					if($scope.session.id=="icici")
						$scope.broker_id=1;
					else if($scope.session.id=="hdfc")
						$scope.broker_id=2;
					else if($scope.session.id=="sharekhan")
						$scope.broker_id=3;
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/brokerservice/viewpublishdetails/"+$scope.broker_id+"/"+$scope.status)
					.success(function(response)
							{
						$scope.viewpublishdetails=response.viewdetails;
						$scope.gridOptions={data:'viewpublishdetails'};
					
					
							})
		
				}

//****************************Publish Status Code *****************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
		
				$scope.publishdetails=function()
		{
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					$scope.hideOtherTabs();
			document.getElementById("broker1").style.backgroundColor = "#2980b9";
					$scope.brokers=true;
					$scope.getDatetime  = new Date();
					if($scope.session.id=="icici")
						$scope.broker_id=1;
					else if($scope.session.id=="hdfc")
						$scope.broker_id=2;
					else if($scope.session.id=="sharekhan")
						$scope.broker_id=3;
					//alert($scope.broker_id);
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/brokerservice/publishdetails/"+$scope.broker_id)
					.success(function(response)
							{  
							if(response.statusbean.status)
						    	alert("Published to admin!");
							else
								alert("No latest saved record available to be published!")
						    	
							}).error(function(){alert("unsuccessful");});
						
				}
//*******************************Save Status Code******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
				$scope.savedetails=function()
				{
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					$scope.hideOtherTabs();
					document.getElementById("broker1").style.backgroundColor = "#2980b9";
			$scope.brokers=true;
					$scope.getDatetime  = new Date();
					if($scope.session.id=="icici")
						$scope.broker_id=1;
					else if($scope.session.id=="hdfc")
						$scope.broker_id=2;
					else if($scope.session.id=="sharekhan")
						$scope.broker_id=3;
					//$scope.margin_fund_rate=$scope.margin_fund_rate.substring(0,$scope.margin_fund_rate.length-1);
					//$scope.margin_fund_ratio=$scope.margin_fund_ratio.replace(":","colon");
					$scope.colonpos=$scope.margin_fund_ratio.indexOf(":");
					$scope.firstvalue=$scope.margin_fund_ratio.substring(0,$scope.colonpos);
					$scope.secondvalue=$scope.margin_fund_ratio.substring($scope.colonpos+1,$scope.margin_fund_ratio.length)
					var firstval = parseInt($scope.firstvalue);
					var secondval= parseInt($scope.secondvalue);
					if((firstval + secondval)==100)
						{
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/brokerservice/savedetails/"+$scope.broker_id+"/"+$scope.session.name+"/"+$scope.futures+"/"+$scope.mutual_funds+"/"+$scope.equity+"/"+$scope.foreign_exchange+"/"+$scope.bonds+"/"+$scope.margin_fund_ratio+"/"+$scope.margin_fund_rate)
			
					.success(function(response)
							{  
						if(response.statusbean.status)
						    	alert("Data Saved successfully");
						else
							alert("Error! Data not saved");
			
			  			})
					.error(function()
							{
							alert("unsuccessful");
							});
			
							
				}
					else
					{
						alert("Margin fund ratio not equals 100");
					}
				}

				//*******************************Save Cash Balance******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************				
				$scope.savebalance=function()
				{
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					$scope.hideOtherTabs();
					document.getElementById("broker2").style.backgroundColor = "#2980b9";
			$scope.brokers1=true;
					$scope.getDatetime  = new Date();
					if($scope.session.id=="icici")
						$scope.broker_id=1;
					else if($scope.session.id=="hdfc")
						$scope.broker_id=2;
					else if($scope.session.id=="sharekhan")
						$scope.broker_id=3;
				
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/brokerservice/savebalance/"+$scope.broker_id+"/"+$scope.balance)
					
					.success(function(response)
							{  
						if(response.statusbean.status)
						    	alert("Data Saved successfully");
						else
							alert("Error! Data not saved");
			
			  			})
			  			
				}
			  			

//**********************XBBLWDM 13496 Advice code****************************************************************
				$scope.brokeradvice1=function()
				{
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					document.getElementById("brokeradvice1").style.backgroundColor = "#2980b9";
			
				
					$scope.hideOtherTabs();
					$scope.brokerssss=true;
				};
				
				
//**********************XBBLWDM 13496 Advice code****************************************************************************************************				
				
				$scope.advicedisplay1=function()
				{
					
					
					$scope.hideOtherTabs();
					document.getElementById("advice1").style.backgroundColor = "#2980b9";
					$scope.advice1=true;
					localStorage.setItem("context","advicedisplay1");
					if($scope.session.id=="icici")
						$scope.broker_id=1;
					else if($scope.session.id=="hdfc")
						$scope.broker_id=2;
					else if($scope.session.id=="sharekhan")
						$scope.broker_id=3;
					$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/getadvice/"+$scope.broker_id).success( function(response){
						
						
						$scope.advicelist1=response.advice;
						
				
					
						
					});
					
					
			};
				
				
				
				
				
				
				
				$scope.brokeradviceu=function()
				{
					$http.get("http://"+ ipaddress+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/sessioncheck").success(function(response) {
						
						if (response.session==null) 
				window.location.replace("http://"+ipaddress+"/PortfolioGame"); 
					});
					
					$scope.hideOtherTabs();
					document.getElementById("brokeradvice1").style.backgroundColor = "#2980b9";
					$scope.uploadBrokerAdvice=true;
					localStorage.setItem("context","brokeradviceu");
/*					$scope.advice=false;
*/				};
//vasu start
$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/lose")
.success(function(response) 
{
		
		$scope.l=response.losegain;
});

$http.get("http://"+ipaddress+"/MyRestDB/cxfservlet/jaxrs-server/service/gain")

.success(function(response) 
			{
	$scope.g=response.losegain;
	
			});


		$scope.set_losecolor = function () {
			
				 return { color: "#990000" }
		}
		$scope.set_gaincolor = function () {
			 
				 return { color: "#006600" }
		  
		}
//vasu end

$scope.logout = function() {
	localStorage.clear();
	$http
			.get(
					"http://"
							+ ipaddress
							+ "/MyRestDB/cxfservlet/jaxrs-server/commonservice/logout")
			.success(
					function(response) {
						
						window.location.replace("http://"
								+ ipaddress
								+ "/PortfolioGame/index-bootstrap.jsp");
					});
};

	
		});